module.exports = {
    '^/jinjiang/.*': {
        target: 'http://192.168.10.25:9910',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/jinjiang/, '/jinjiang'),
    },
}
