import {
    findCityOptions,
    findCountyOptions,
    findStreetOptions,
    findCommunityOptions,
    findGridOptions,
    findBuildOptions,
    findUserOptions,
    findCommonDict,
} from '@/api/common.js'

const accessToken =
    'pk.eyJ1IjoiZ29uZ2hvbmciLCJhIjoiY2xldzlwejZtMGVsZTN5bzRubG4zcW9jaiJ9.-PFq0wi1dlAln8cDpqEySg'
/**
 *获取字典信息
 * @export
 * @param {*} dictCode
 * @return {*}
 */
export const getGlobalDict = (dictCode) => findCommonDict(dictCode).then((res) => res || [])

export function getCityList() {
    return new Promise((resolve, reject) => {
        findCityOptions()
            .then((res) => {
                resolve(res)
            })
            .catch(() => {
                reject([])
            })
    })
}

export function getCityListInit(cityList) {
    getCityList().then((res) => {
        if (res.code === 200) {
            cityList = res.data
        }
    })
}

/**
 *获取区域信息
 *
 * @export
 * @param {*} cityId
 * @return {*}
 */
export function getCountyList(cityId) {
    return new Promise((resolve, reject) => {
        findCountyOptions(cityId)
            .then((res) => {
                resolve(res)
            })
            .catch(() => {
                reject([])
            })
    })
}

/**
 *获取区域信息
 *
 * @export
 * @param {*} cityId
 * @return {*}
 */
export function getStreetList(countyId) {
    return new Promise((resolve, reject) => {
        findStreetOptions(countyId)
            .then((res) => {
                resolve(res)
            })
            .catch(() => {
                reject([])
            })
    })
}
/**
 *获取单元列表
 *获取社区列表
 *
 * @export
 * @param {*} buildId
 * @return {*}
 */
export function getCommunityList(streetId) {
    return new Promise((resolve, reject) => {
        findCommunityOptions(streetId)
            .then((res) => {
                resolve(res)
            })
            .catch(() => {
                reject([])
            })
    })
}

// 网格
export function getGridParentList(communityId) {
    return new Promise((resolve, reject) => {
        findGridOptions(communityId)
            .then((res) => {
                resolve(res)
            })
            .catch(() => {
                reject([])
            })
    })
}
// 建筑
export const getBuildOptions = (grid) => findBuildOptions(grid).then((res) => res || [])
// 用户
export const getUserOptions = (buildId) => findUserOptions(buildId).then((res) => res || [])

/**
 *获取经纬度信息
 *
 * @export
 * @param {*} cityId
 * @return {*}
 */
export function getLantInfo(addr) {
    return new Promise((resolve, reject) => {
        const baseUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${addr}.json?access_token=${accessToken}`
        window
            .fetch(baseUrl, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            })
            .then((response) => {
                resolve(response.json())
            })
            .catch(() => {
                reject({})
            })
    })
}
