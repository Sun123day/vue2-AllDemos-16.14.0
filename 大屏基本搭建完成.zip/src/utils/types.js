// 设备状态
export const STATE_ENUM = [
    { key: '上线', value: '1' },
    { key: '下线', value: '2' },
]
// 安装位置
export const POSITION_ENUM = [
    { key: '厨房', value: '1' },
    { key: '客厅', value: '2' },
    { key: '卧室', value: '3' },
]
// 通信方式
export const COMMUNICATION_ENUM = [
    { key: 'TCP', value: '1' },
    { key: 'MQTT', value: '2' },
    { key: '蓝牙', value: '3' },
]
// 报警器类型
export const ALARMT_YPE_ENUM = [
    { key: 'DTU', value: '1' },
    { key: '网关', value: '2' },
]
// 报警器检修状态
export const RECONDITION_ENUM = [
    { key: '未检修', value: '1' },
    { key: '检修中', value: '2' },
    { key: '已检修', value: '3' },
]
//用户类型
export const USERTYPE_ENUM = [
    { key: '个人用户', value: '1' },
    { key: '学生用户', value: '2' },
    { key: '非盈利组织或慈善机构用户', value: '3' },
    { key: '企业用户', value: '4' },
    { key: '零售商用户', value: '5' },
    { key: '服务行业用户', value: '6' },
]
// 告警状态/类型
export const ALARMSTATE_ENUM = [
    { key: '未处理', value: '1' },
    { key: '处理中', value: '2' },
    { key: '已处理', value: '3' },
]
// 建筑性质
export const BUILDTYPE_ENUM = [
    { value: 1, key: '住宅建筑' },
    { value: 2, key: '商业建筑' },
    { value: 3, key: '工业建筑' },
    { value: 4, key: '公共建筑' },
    { value: 5, key: '城市基础设施' },
    { value: 6, key: '农业建筑' },
    { value: 7, key: '文化建筑' },
    { value: 8, key: '宗教建筑' },
]
// 建筑性质
export const DATATYPE_ENUM = [
    { value: 1, key: '整数（Integer）' },
    { value: 2, key: '浮点数（Float）' },
    { value: 3, key: '字符串（String）' },
    { value: 4, key: '布尔值（Boolean）' },
    { value: 5, key: '数组（Array）' },
    { value: 6, key: '对象（Object）' },
    { value: 7, key: '空值（Null）' },
    { value: 8, key: '未定义（Undefined）' },
]

// 设备类型
export const DEVICE_ENUM = [
    { value: '1', key: '门站' },
    { value: '2', key: '储气库' },
    { value: '3', key: '储配站' },
    { value: '4', key: '调压室' },
    { value: '5', key: '阀井' },
]
