import router, { dynamicRoutes } from '@/router'
import store from './store'
import { Message } from 'element-ui'
import 'nprogress/nprogress.css'
import NProgress from 'nprogress' // progress bar
import { getToken, getRedirectLogin } from '@/utils/auth'
import { redirect } from '@/utils/index'

NProgress.configure({ showSpinner: false })
const whiteList = ['/login', '/auth-redirect']

const NODE_ENV = process.env.NODE_ENV

router.beforeEach((to, from, next) => {
    NProgress.start()

    if (getToken()) {
        /**
         * 如果有登陆则进入页面
         */
        getStartResouce(to, from, next)
    } else {
        /**
         * 如果没有token则进入登陆页面.
         * 1、开发环境则进入本地项目登陆界面.
         * 2、其他环境则进入安全平台登陆界面
         */
        if (NODE_ENV == 'development') {
            /**
             * 1、开发环境，本地登陆
             */
            //1、如果进入的路由是不需要权限验证则执行
            if (whiteList.indexOf(to.path) !== -1) {
                next()
                return
            }
            //判断如果本身就是进入登录路由则执行，否则重定向登录界面
            if (to.path == '/login') {
                next()
                return
            } else {
                next(`/login?redirect=${from.path}`)
            }
        } else {
            /**
             * 其他环境;
             * 1、如果环境变量配置了（VUE_LOCAHOST_LOGIN）为true；那么正式环境为本地项目登录界面。
             *
             * 2、VUE_LOCAHOST_LOGIN）为false，环境则进入安全平台登陆界面（从定向安全云登陆界面）
             */
            redirect(next, from, to)
        }
    }
})

/**
 * @function 判断是否首次登陆，首次登陆需获取用户信息和菜单
 * @param {*} to
 * @param {*} from
 * @param {*} next
 */
const getStartResouce = (to, from, next) => {
    //判断store缓存里是否有登录用户信息，用于判断是否首次登录
    if (!store.state.userInfo) {
        //1、首次登录，需要先发送获取登录用户信息、菜单数据接口请求,
        store
            .dispatch('loginUserInfo')
            .then(() => {
                store.dispatch('GenerateRoutes').then((routeData) => {
                    router.addRoutes(routeData)
                    next({ ...to })
                    NProgress.done()
                    return
                })
            })
            .catch(() => {
                store.dispatch('userLoginOut').then(() => {
                    next({ path: '/' })
                })
            })
    } else {
        if (to.path === '/login') {
            //1、如果进入的是登陆界面,则进入首页
            next({ path: '/' })
        } else {
            next()
        }
    }
}

router.afterEach((to, from, next) => {
    //缓存功能权限按钮到store
    const { permissionList = [] } = router.currentRoute.meta
    store.state.permissionList = permissionList
    /**
     * @descrptions 缓存组件
     */
    const { keepAlive = false } = from.meta
    if (keepAlive) {
        const keepAliveArr = store.state.keepAliveComponents || []
        if (keepAliveArr.indexOf(from.name) < 0) {
            keepAliveArr.push(from.name)
            store.state.keepAliveComponents = keepAliveArr
        }
    }
    NProgress.done()
})
