const mutations = {
    /**
     * @function 保存登录用户信息
     * @param {*} state
     * @param {*} userInfo
     */
    SET_USERINFO: (state, userInfo) => {
        state.userInfo = userInfo
    },
    SAVE_NAV_MENU: (state, navMenu) => {
        state.navMenu = navMenu
    },
    SET_LOGO_PATH: (state, path) => {
        state.logoPath = path
    },
}
export default mutations
