import {
    energyMonthsBar,
    energyRatePie,
    energyRankPie,
    energyYearStatics,
    getComprehensiveProportion,
    poewerRequest,
    equipmentRequest,
    deviceStatusRequest,
    energyAmountRequest,
} from '@/api/cockpit'

const state = {
    currentTypeCode: null,
    unit: null,
    barMonthData: [],
    pieRateData: [],
    energyRankList: [],
    yearStaticsData: [],
    energyAlarmList: [],
    powerChartList: [],
    equipmentData: [],
    deviceStatusData: {},
    energyAmountData: {},
}

const mutations = {
    UPDATE_UNIT: (state, unit) => {
        state.unit = unit
    },
    /**
     * @function 近12月能耗bar数据
     * @param {*} state
     * @param {*} params
     */
    MONTHS_BAR_AJAX: (state, params) => {
        energyMonthsBar(params).then((result) => {
            state.barMonthData = result.data || []
        })
    },
    /**
     * @function 能耗占比数据接口
     * @param {*} state
     * @param {*} params(接口参数)
     */
    ENERGY_RATE_AJAX: (state, params) => {
        energyRatePie(params).then((result) => {
            state.pieRateData = result.data || []
        })
    },
    /**
     * @function 能耗排名数据接口
     * @param {*} state
     * @param {*} params(接口参数)
     */
    ENERGY_RANK_AJAX: (state, params) => {
        energyRankPie(params).then((result) => {
            state.energyRankList = result.data || []
        })
    },
    /**
     * @function 能耗统计
     * @param {*} state
     * @param {*} params(接口参数)
     */
    YEAR_STATICS_AJAX: (state, params) => {
        energyYearStatics(params).then((result) => {
            state.yearStaticsData = result.data || []
        })
        const { projectId } = params
        energyAmountRequest(projectId).then((result) => {
            state.energyAmountData = result.data || []
        })
    },
    /**
     * @function 综合能耗数据
     * @param {*} state
     * @param {*} params
     */
    ENERGY_ALARM_AJAX: (state, params) => {
        getComprehensiveProportion(params).then((result) => {
            state.energyAlarmList = result.data || []
        })
    },
    /**
     * @function 实时负荷
     * @param {*} state
     * @param {*} params
     */
    POWER_AJAX: (state, params) => {
        poewerRequest(params).then((result) => {
            state.powerChartList = result.data || []
        })
    },
    /**
     * @function 关键设备
     * @param {*} state
     * @param {*} params
     */
    KEY_EQUIPMENT_AJAX: (state, params) => {
        equipmentRequest(params).then((result) => {
            state.equipmentData = result.data || []
        })
    },
    DEVICE_STATUS_AJAX: (state, params) => {
        deviceStatusRequest(params).then((result) => {
            state.deviceStatusData = result.data || {}
        })
    },
    ENERGY_TYPE_CODE: (state, code) => {
        state.currentTypeCode = code
    },
    CLEAR_CO_STORE: (state) => {
        state.powerChartList = []
        state.energyAlarmList = []
        state.yearStaticsData = []
        state.energyRankList = []
        state.pieRateData = []
        state.barMonthData = []
        state.equipmentData = []
        state.deviceStatusData = {}
        state.energyAmountData = {}
    },
}

const actions = {
    UPDATE_UNIT({ commit }, unit) {
        commit('UPDATE_UNIT', unit)
    },
    /**
     * 能源类型切换Action
     * @param {*} param0
     * @param {*} params
     */
    ENERGY_TYPE_CHANGE({ commit }, params) {
        commit('MONTHS_BAR_AJAX', params)
        commit('ENERGY_RATE_AJAX', params)
        commit('ENERGY_RANK_AJAX', params)
        commit('POWER_AJAX', params)
    },
    /**
     * @function 能耗统计action
     * @param {*} param0
     * @param {*} params
     */
    YEAR_STATICS_AICTION({ commit }, params) {
        commit('YEAR_STATICS_AJAX', params)
    },
    /**
     * @function 综合能耗数据
     */
    ALARM_ACTION({ commit }, params) {
        commit('ENERGY_ALARM_AJAX', params)
    },

    CLEAR_CO_STORE_ACTION({ commit }, params) {
        commit('CLEAR_CO_STORE', params)
    },
    KEY_EQUIPMENT_ACTION({ commit }, params) {
        commit('KEY_EQUIPMENT_AJAX', params)
    },
    DEVICE_STATUS_ACTION({ commit }, params) {
        commit('DEVICE_STATUS_AJAX', params)
    },
    ENERGY_TYPE_CODE_ACTION({ commit }, code) {
        commit('ENERGY_TYPE_CODE', code)
    },
}
export default {
    namespaced: true,
    state,
    mutations,
    actions,
}
