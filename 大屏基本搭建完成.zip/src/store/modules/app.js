const state = {}
export default {
    namespaced: true,
    state,
}
