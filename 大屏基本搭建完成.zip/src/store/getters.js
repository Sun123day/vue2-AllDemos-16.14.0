const getters = {
    //缓存登录token
    token: (state) => state.token,
    language: (state) => state.language,
    size: (state) => state.size,
    projectId: (state) => state.projectId,
    logoPath: (state) => state.logoPath,
    areaId: (state) => state.areaId,
}
export default getters
