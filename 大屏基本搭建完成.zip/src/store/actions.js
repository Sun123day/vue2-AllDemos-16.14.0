import { getLoginUserInfo, getNavMenu, loginOut } from '@/api/system'
import { generatorRoutes } from '@/router/parseRoute'
import Cookies from 'js-cookie'
import { clearCookies, removeToken } from '@/utils/auth'
import store from '@/store'
const actions = {
    /**
     * @function 登录用户信息action；
     * @param {*} param0
     */
    loginUserInfo({ commit, state }) {
        return new Promise((resolve, reject) => {
            getLoginUserInfo()
                .then((result) => {
                    const resultData = result.data
                    resultData.avatar = require('@/assets/image/defaultImg.png')
                    commit('SET_USERINFO', resultData)
                    resolve()
                })
                .catch((error) => {
                    reject(error)
                })
        })
    },
    /**
     * @function 获取路由
     * @param {*} param0
     */
    async GenerateRoutes({ commit, state }) {
        return new Promise(async (resolve) => {
            const result = await getNavMenu()
            //获取到配置菜单路由数据.
            const resultData = result.data || []

            //解析成路由
            const routers = generatorRoutes(resultData)
            commit('SAVE_NAV_MENU', routers)
            resolve(routers)
        })
    },
    /**
     * @function 退出登录
     */
    userLoginOut() {
        return new Promise((resolve, reject) => {
            loginOut()
                .then((result) => {
                    if (result.code == '200') {
                        const rememberMe = Cookies.get('rememberMe')
                        if (!rememberMe) {
                            //清除cookies
                            clearCookies()
                        } else {
                            removeToken()
                        }
                        store.state.userInfo = null
                        resolve()
                    } else {
                        reject()
                    }
                })
                .catch(() => {
                    reject()
                })
        })
    },
    setLogoPath({ commit }, path) {
        commit('SET_LOGO_PATH', path)
    },
}
export default actions
