import { findProjectOptions, findMeterOptions } from '@/api/common.js'
export default {
    data() {
        return {
            projectList: [],
            meterList: [],
        }
    },
    created() {
        findProjectOptions().then((res) => {
            if (res.code === 200) {
                this.projectList = res.data
            }
        })
    },
    methods: {
        getMeterListByProject(projectId) {
            findMeterOptions(projectId).then((res) => {
                if (res.code === 200) {
                    this.meterList = res.data
                }
            })
        },
    },
}
