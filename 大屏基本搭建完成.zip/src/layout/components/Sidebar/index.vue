<template>
    <div :class="{ 'has-logo': showLogo }">
        <!-- <logo v-if="showLogo" :collapse="isCollapse" /> -->
        <el-scrollbar wrap-class="scrollbar-wrapper" style="overflow-x: hidden">
            <el-menu
                :default-active="activeMenu"
                :unique-opened="false"
                :active-text-color="variables.menuActiveText"
                :collapse-transition="false"
                mode="vertical"
            >
                <div v-for="menuItem in menuData" :key="menuItem.key">
                    <el-submenu
                        v-if="!menuItem.hidden && menuItem.resourceType === '1'"
                        :index="menuItem.path"
                    >
                        <template slot="title">
                            <Item
                                :icon="menuItem.meta && menuItem.meta.icon"
                                :title="generateTitle(menuItem.meta.title)"
                            />
                        </template>
                        <AppLink
                            v-for="subItem in menuItem.children || []"
                            :key="subItem.key"
                            :to="resolvePath(subItem.path)"
                            :options="subItem"
                            v-if="!subItem.hidden"
                        >
                            <el-menu-item :key="subItem.key" :index="subItem.path">
                                <Item
                                    :icon="subItem.meta && subItem.meta.icon"
                                    :title="generateTitle(subItem.meta.title)"
                                />
                            </el-menu-item>
                        </AppLink>
                    </el-submenu>
                    <AppLink
                        v-if="!menuItem.hidden && menuItem.resourceType === '2'"
                        :key="menuItem.key"
                        :to="resolvePath(menuItem.path)"
                        :options="menuItem"
                    >
                        <el-menu-item :index="menuItem.path">
                            <Item
                                :icon="menuItem.meta && menuItem.meta.icon"
                                :title="generateTitle(menuItem.meta.title)"
                            />
                        </el-menu-item>
                    </AppLink>
                </div>
            </el-menu>
        </el-scrollbar>
    </div>
</template>

<script>
    import { mapState } from 'vuex'
    import variables from '@/styles/variables.scss'
    import AppLink from './Link'
    import path from 'path'
    import { generateTitle } from '@/utils/i18n'
    import { isExternal } from '@/utils/validate'
    import Item from './Item'
    export default {
        components: {
            AppLink,
            Item,
        },
        data() {
            return {
                num: 0,
                menuData: [],
            }
        },
        computed: {
            ...mapState({
                navMenu: (state) => state.navMenu,
                sidebarLogo: (state) => state.settings.sidebarLogo,
                sidebarOpened: (state) => state.sidebar.opened,
            }),
            activeMenu() {
                const route = this.$route
                const { meta, path } = route
                // if set path, the sidebar will highlight the path you set
                if (meta.activeMenu) {
                    return meta.activeMenu
                }
                return path
            },
            showLogo() {
                return this.sidebarLogo
            },
            variables() {
                return variables
            },
            isCollapse() {
                return !this.sidebarOpened
            },
        },
        watch: {},
        mounted() {
            this.initMenuData()
        },
        methods: {
            initMenuData() {
                this.menuData = this.$lodash.cloneDeep(this.navMenu)
            },
            countNum(val) {
                let arr = val.filter(
                    (item) =>
                        item.conversationID !== '@TIM#SYSTEM' &&
                        item.conversationID !== 'C2Cadministrator'
                )
                this.num = arr.reduce((acc, cur) => {
                    return acc + cur.unreadCount
                }, 0)
                this.num = this.num < 100 ? this.num : '99+'
            },
            resolvePath(routePath) {
                if (isExternal(routePath)) {
                    return routePath
                }
                if (isExternal(this.basePath)) {
                    return this.basePath
                }

                return path.resolve(this.basePath || '', routePath)
            },
            generateTitle,
        },
    }
</script>
<style lang="scss" scoped>
    ::v-deep .el-scrollbar {
        height: 100%;
    }
    ::v-deep .el-scrollbar__view {
        height: 100%;
        background: $menuBg;
    }
    ::v-deep .el-menu {
        border-right: none;
        .el-menu-item.is-active {
            //border-right: 4px solid $primary-color;
            background-color: $menuActiveBgColor !important;
        }
        .el-submenu.is-active {
            .el-submenu__title {
                color: $primary-color;
            }
        }
        .el-submenu__title:hover {
            background-color: $menuActiveBgColor !important;
        }
        .el-menu-item:hover,
        .el-menu-item:focus {
            background-color: $menuActiveBgColor !important;
        }
    }
</style>
