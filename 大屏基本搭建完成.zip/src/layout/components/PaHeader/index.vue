<template>
    <div class="header-box">
        <div class="item-box left-box">
            <img :src="logoPath" alt="" style="height: 38px" />
            <div class="title-text">{{ title }}</div>
        </div>
        <div class="item-box right-box">
            <span style="margin-right: 30px">
                <el-badge :value="alarmCount" :max="999" class="item">
                    <i
                        class="iconfont icon-xiaoxi"
                        @click="goToAlarm"
                        style="font-size: 24px; color: #fff"
                    />
                </el-badge>
            </span>

            <img src="../../../assets/image/touxiang.png" class="user-avatar" />
            <el-dropdown>
                <span class="el-dropdown-link">
                    {{ userName }}<i class="el-icon-arrow-down el-icon--right" />
                </span>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item @click.native="onReset">
                        <span style="display: block">账户设置</span>
                    </el-dropdown-item>

                    <el-dropdown-item @click.native="onLogout">
                        <span style="display: block">{{ '退出登录' }}</span>
                    </el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex'
    import { findDefaultProject } from '@/api/projectInfoMessage.js'
    import Cookies from 'js-cookie'
    import settings from '@/settings'
    // import { findlevelList } from '@/api/warningMessage'
    export default {
        name: 'PaHeader',
        data() {
            return {
                alarmCount: 0,
                cityList: [],
                userData: '',
                interval: 60000,
                heartbeat: null,
                // title: settings.title,
                title: "锦江燃气安全",
            }
        },
        computed: {
            ...mapGetters(['projectId']),
            logoPath() {
                return this.$store.state.logoPath
            },
            userName: {
                get() {
                    const { nickName = '' } = this.$store.state.userInfo || {}
                    return nickName
                },
            },
            currentCityCode: {
                get() {
                    return this.$store.state.currentCityCode
                },
                set(val) {},
            },
        },
        watch: {
            projectId: {
                handler(value) {
                    value && this.getLoginPath(value)
                },
                immediate: true,
            },
        },
        mounted() {
            // findCityInfoList().then((result)=>{
            //     this.cityList=result?.data||[]
            // })
            // if(!this.currentCityCode){
            //   findCityInfoByAppType(process.env.VUE_APP_SUB_APP_CODE).then(res=>{
            //     if(res.code === 200){
            //       this.$store.dispatch("setCurrentCityCodeState", res.data.id);
            //     }
            //   })
            // }
            this.getlevelList()
        },
        destroyed() {
            clearInterval(this.heartbeat)
        },
        methods: {
            // getlevelList() {
            //     let projectId = this.$store.state.projectId
            //     findlevelList({ projectId: projectId, status: 'untreated' }).then(
            //         ({ code, data }) => {
            //             if (code === 200) {
            //                 this.alarmCount = data.all || 0
            //             }
            //         }
            //     )
            // },
            goToAlarm() {
                // this.$router.push({
                //     path: '/warningMessage',
                //     query: {
                //         status: 'untreated',
                //     },
                // })
            },
            getLoginPath(id) {
                findDefaultProject().then((resp) => {
                    const { code, data } = resp
                    if (code === 200 && data) {
                        this.$store.dispatch('setLogoPath', data.enterpriseLogo)
                    }
                })
            },
            changeCity(newCity) {
                this.$store.dispatch('setCurrentCityCodeState', newCity)
            },
            async heartbeatFn() {
                const result = await this.$requestPost(
                    `/cloud-im/user/online?imUserId=${this.userData.imUserId}`,
                    {}
                )
            },
            toggleSideBar() {
                this.$store.dispatch('app/toggleSideBar')
            },
            // 退出登录
            onLogout() {
                this.$confirm('确认退出当前账号吗？', '安全退出', {
                    confirmButtonText: '退出',
                    cancelButtonText: '取消',
                    type: 'warning',
                })
                    .then(() => {
                        this.logout()
                        clearInterval(this.heartbeat)
                    })
                    .catch(() => {
                        this.logout()
                        clearInterval(this.heartbeat)
                    })
            },
            async logout() {
                this.$store.dispatch('userLoginOut').then(() => {
                    this.$message({
                        message: '退出成功',
                        type: 'success',
                    })
                    setTimeout(() => {
                        this.$router.push(`/login`)
                    }, 1000)
                })
            },
            // 账户设置
            onReset() {
                this.$router.push('/mine/reset')
            },
        },
    }
</script>

<style lang="scss" scoped>
    .pa-logo {
        color: #fff !important;
    }
    .header-box {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        height: $header-height;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 2000;
        background: $header-bg-color;
        .line {
            width: 1px;
            height: 26px;
            background: #ffffff;
            opacity: 0.2;
            margin: 0 15px;
        }
        .right-box {
            margin-right: 16px;
        }
        .left-box {
            margin-left: 16px;
        }
    }

    .item-box {
        display: flex;
        align-items: center;
    }

    .header-title {
        // width: 150px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        img {
            height: 100%;
        }
    }
    .title-text {
        font-weight: 600;
        color: #ffffff;
        font-size: 16px;
        margin-left: 15px;
    }
    .user-avatar {
        width: 24px;
        height: 24px;
        margin-right: 8px;
    }

    .el-dropdown {
        font-size: 14px;
        color: #fff;
    }

    .el-icon--right {
        margin-left: 8px;
    }

    .el-dropdown-link {
        cursor: pointer;
    }

    .icon-off-line-icon,
    .icon-on-line-icon {
        color: #fff;
    }

    .icon-xiaoxi {
        cursor: pointer;
    }

    .cityBox {
        ::v-deep .el-input__inner {
            background: transparent;
            color: #fff !important;
        }
    }
</style>
