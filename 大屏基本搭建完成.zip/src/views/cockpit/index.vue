<script>
import autofit from 'autofit.js'
import store from '@/store'
import AMapLoader from "@amap/amap-jsapi-loader";

import TopHeader from './components/TopHeader/index.vue'
import Alarm from './components/Alarm/index.vue'
import LeftTopLeft from './components/LeftTopLeft/index.vue'
import LeftTopRight from './components/LeftTopRight/index.vue'
import LeftMidLeft from './components/LeftMidLeft/index.vue'
import LeftMidRight from './components/LeftMidRight/index.vue'
import LeftBtm from './components/LeftBtm/index.vue'
import RightTop from './components/RightTop/index.vue'
import RightMid from './components/RightMid/index.vue'
import RightBtmLeft from './components/RightBtmLeft/index.vue'
import RightBtmRight from './components/RightBtmRight/index.vue'
import { now } from 'lodash';

// 必须添加安全密钥，否则不会显示区域边界和高光图像
window._AMapSecurityConfig = {
  securityJsCode: 'd0fb298dd6215ebc0ad013a0ae450d88', 
}

export default {
    components: {
        TopHeader,
        Alarm,
        LeftTopLeft,
        LeftTopRight,
        LeftMidLeft,
        LeftMidRight,
        LeftBtm,
        RightTop,
        RightMid,
        RightBtmLeft,
        RightBtmRight,
    },
    provide() {
        return {
            cockpitPage: this,
        }
    },
    data() {
        return {
            echartsArr: [],
            energySelectItem: {},
            leftFlag: true,
            rightFlag: true,
            total: 0,
            now: 0,
        }
    },
    mounted() {
        window.addEventListener('resize', this.autoResize)
        autofit.init({
            // dh: 1080,
            // dw: 3840,
            // el: '#screen',
            // //忽略缩放的元素
            // ignore: [],
            // resize: true,
        })
        this.autoResize()
        setTimeout(() => {
            this.initMap(); // 获取初始化数据
        }, 900);
    },
    beforeDestroy() {
        window.removeEventListener('resize', this.autoResize)
        this.echartsArr.map((chart) => {
            chart && chart.dispose()
        })
    },
    methods: {
        autoResize() {
            this.echartsArr.map((chart) => {
                chart && chart.resize()
            })
        },
        chartOnCreated(chart) {
            this.echartsArr.push(chart)
        },
        initMap(){
            AMapLoader.load({
                key: "4fb14fe8cc5e2f521c0837dbf1998c82", // 申请好的Web端开发者Key，首次调用 load 时必填
                version: "2.0", // 指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
                // 需要使用的的插件列表
                plugins: [
                    "AMap.Geocoder", // 逆向地理解码插件
                    "AMap.Marker", // 点标记插件
                    "AMap.MapType", // 地图类型
                    "AMap.DistrictSearch", // 行政区查询插件
                    "AMap.Polygon", // 多边形绘制插件
                    "AMap.Size", // 自定义图标大小
                    "AMap.Pixel", // 自定义图标偏移
                ],
                AMapUI: {
                    version: "1.1",
                    plugins: ["overlay/SimpleMarker"]
                }
            }).then(AMap => {
                const map = new AMap.Map("map", {
                    resizeEnable: true,
                    zoom: 16, //缩放比
                    pitch:80,
                    center: [104.117262,30.598726] //中心设为锦江区
                });

                // 地图样式-暗色
                map.setMapStyle("amap://styles/darkblue");

                // 缩放地图到合适的视野级别
                // map.setFitView();  

                const opts = {
                    subdistrict: 0,    // 获取边界不需要返回下级行政区
                    extensions: 'all', // 返回行政区边界坐标组等具体信息
                    level: 'district' // 查询行政级别为 区
                }

                const districtSearch = new AMap.DistrictSearch(opts);
                
                // console.log("districtSearch", districtSearch);

                const polygons = [];

                const arr = ['锦江区']; // 只保留锦江区
                // console.log("arr", arr);
                arr.forEach((item) => {
                    // console.log("arr", arr);
                    districtSearch.search(item, (status, result) => { // 查询成功时，result即为对应的行政区信息
                        // console.log("item", item);
                        // map.remove(polygons); // 清除上次结果
                        const bounds = result.districtList[0].boundaries;
                        // console.log("bounds", bounds);
                        if (bounds && bounds.length > 0) {
                        for (let i = 0, l = bounds.length; i < l; i++) {
                            // 生成行政区划polygon
                            const polygon = new AMap.Polygon({
                                strokeWeight: 5, // 边界线宽
                                strokeColor: '#0091ea', // 边界颜色
                                path: bounds[i],
                                fillOpacity: 0.4, // 区域高亮透明度
                                fillColor: '#80d8ff',// 区域高亮颜色
                            });
                            polygons.push(polygon);
                        }
                        }
                        map.add(polygons);
                        map.setFitView(polygons); // 视口自适应
                    })
                })

                // 经纬度标点
                let markers = [
                    { position: [104.145407, 30.585463], title: '三圣小学', status: 'abnormal', total: 10, now: 1 },
                    { position: [104.144225, 30.593702], title: '锦江城市花园一期', status: 'normal', total: 20, now: 2 },
                    { position: [104.142251, 30.589065], title: '三圣街道办事处', status: 'normal', total: 30, now: 3 },
                    { position: [104.128649,30.603628], title: '成都三中', status: 'abnormal', total: 40, now: 4 },
                    { position: [104.117148,30.577695], title: '回龙寺', status: 'normal', total: 50, now: 5 },
                    { position: [104.093973,30.613084], title: '华润万家', status: 'normal', total: 60, now: 6 },
                    { position: [104.091227,30.641445], title: '天府国际', status: 'abnormal', total: 70, now: 7 },
                    { position: [104.098179,30.627118], title: '秀城', status: 'abnormal', total: 80, now: 8 },
                ];

                // 推入图标
                // markers.forEach((markerData) => {
                //     if (markerData.status === 'abnormal') {
                //         markerData.icon = new AMap.Icon({
                //             size: new AMap.Size(25.88, 36.64), // 图标尺寸
                //             image: '~@/assets/image/cockpit/abnormal.png', // 图标的取图地址
                //             imageSize: new AMap.Size(25.88, 36.64), // 图标所用图片大小
                //             imageOffset: new AMap.Pixel(0, 0), // 图标取图偏移量
                //         })
                //     } else {
                //         markerData.icon = new AMap.Icon({
                //             size: new AMap.Size(25.88, 36.64), // 图标尺寸
                //             image: '~@/assets/image/cockpit/normal.png', // 图标的取图地址
                //             imageSize: new AMap.Size(25.88, 36.64), // 图标所用图片大小
                //             imageOffset: new AMap.Pixel(0, 0), // 图标取图偏移量
                //         })
                //     }
                // })

                // 标记数组
                let markerArr = [];
                // 创建标记
                markers.forEach((markerData) => {
                    const marker = new AMap.Marker({
                        position: markerData.position, // 经纬度
                        title: markerData.title, // 标题
                        icon: new AMap.Icon({
                            size: new AMap.Size(25.88, 36.64), // 图标尺寸
                            image: markerData.status === 'abnormal'
                                    ? require('@/assets/image/cockpit/abnormal.png') 
                                    : require('@/assets/image/cockpit/normal.png'), // 图标的取图地址
                            imageSize: new AMap.Size(25.88, 36.64), // 图标所用图片大小
                            imageOffset: new AMap.Pixel(0, 0), // 图标取图偏移量
                        }),
                        offset: new AMap.Pixel(0, 0), // 图标偏移量
                    });
                    // 为每个marker添加点击事件
                    marker.on('click', () => this.handleClickMarker(markerData));
                    markerArr.push(marker)
                });
                // console.log("markerArr", typeof markerArr);
                // console.log("markerArr", markerArr);
                map.add(markerArr); // 将所有标记数组添加到地图上
            })
        },
        handleClickMarker(markerData){
            console.log("点击了标记", markerData);
            this.total = markerData.total;
            this.now = markerData.now;
        },
        leftClick(){
            this.leftFlag =!this.leftFlag;
        },
        rightClick(){
            this.rightFlag =!this.rightFlag;
        }
    },
    beforeDestroy() {
        store.dispatch('cockpit/CLEAR_CO_STORE_ACTION')
    },
}
</script>

<template>
    <div class="page-swaper" id="screen">
        <TopHeader />
        <div class="main-conatner">
            <div class="main-layout">
            <div class="left-drawer">
            <!-- <div class="left-drawer" style="display: none !important;"> -->
                <div class="left-body" v-show="leftFlag">
                    <div class="left-top">
                        <div class="title-container">
                            <span class="title">燃气风险态势</span>
                        </div>
                        <div class="left-top-main">
                            <LeftTopLeft />
                            <LeftTopRight />
                        </div>
                    </div>
                    <div class="left-mid">
                        <div class="title-container">
                            <span class="title">预警处置情况</span>
                        </div>
                        <div class="left-mid-main">
                            <LeftMidLeft />
                            <LeftMidRight />
                        </div>
                    </div>
                    <div class="left-btm">
                        <div class="title-container">
                            <span class="title">燃气分类风险信息</span>
                        </div>
                        <div class="left-btm-main">
                            <LeftBtm />
                        </div>
                    </div>
                </div>
                <img class="drawer-handler" src="~@/assets/image/cockpit/left.png" alt="" @click="leftClick">
            </div>
            <div class="mid-area" id="map">
                <Alarm
                    :total="total"
                    :now="now"
                />
            </div>
            <div class="right-drawer">
            <!-- <div class="right-drawer" style="display: none !important;"> -->
                <img class="drawer-handler" src="~@/assets/image/cockpit/right.png" alt="" @click="rightClick">
                <div class="right-body" v-show="rightFlag">
                    <div class="right-top">
                        <RightTop />
                    </div>
                    <div class="right-mid">
                        <RightMid />
                    </div>
                    <div class="right-btm">
                        <div class="title-container">
                            <span class="title">应急调度指挥</span>
                        </div>
                        <div class="right-btm-main">
                            <RightBtmLeft />
                            <RightBtmRight />
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
    .page-swaper {
        position: absolute;
        width: 100%;
        height: 100%;
        overflow: hidden;
        background: #09121d;
        display: flex;
        flex-direction: column;
        .main-conatner {
            flex-grow: 1;
            position: relative;
            // margin: 0 27px;
            .main-layout {
                position: absolute;
                top: 0;
                right: 15px;
                left: 15px;
                bottom: 0;
                // overflow: hidden;
                display: flex;
                justify-content: space-between;
                .drawer-handler {
                    width: 31px;
                    height: 329px;
                    cursor: pointer;
                }
                .left-drawer, .right-drawer {
                    // display: none !important;
                    position: absolute;
                    top: -25px;
                    flex: 1;
                    height: 980px;
                    display: flex;
                    align-items: center;
                    z-index: 100;
                   .left-body, .right-body {
                        flex: 1;
                        width: 1280px;
                        height: 100%;
                        background-color: rgba(0,31,60,0.8);
                        display: flex;
                        flex-direction: column;
                        // justify-content: space-between;
                    }
                }
                .left-drawer {
                    left: 0;
                }
                .right-drawer {
                    right: 0;
                }
                .left-top,
                .right-top,.right-mid,.right-btm{
                    // flex: 1;
                    width: 100%;
                    height: 326px;
                }
                .left-mid {
                    // flex: 1;
                    width: 100%;
                    height: 274px;
                    margin-top: 13px;
                }
                .left-btm {
                    width: 100%;
                    height: 334px;
                    margin-top: 26px;
                }
                .title-container {
                    width: 100%;
                    height: 26px;
                    background-image: url('~@/assets/image/cockpit/title-container.png');
                    background-size: 1280px 26px;
                    background-repeat: no-repeat;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    .title {
                        height: 26px;
                        font-family: YouSheBiaoTiHei, YouSheBiaoTiHei;
                        font-weight: bold;
                        font-size: 20px;
                        color: #2AFFFF;
                        line-height: 26px;
                        text-align: left;
                        font-style: italic;
                        text-transform: none;
                        margin-left: 34px;
                    }
                }

                .right-btm-main {
                    height: 274px;
                    width: 1240px;
                    padding: 13px 17px 13px 20px;
                }
                .left-top-main {
                    height: 285px;
                    width: 1240px;
                    padding: 13px 17px 13px 20px;
                }
                .left-mid-main {
                    height: 248px;
                    width: 1240px;
                    padding: 13px 17px 13px 20px;
                }
                .left-btm-main {
                    height: 295px;
                    width: 1240px;
                    padding: 13px 17px 13px 20px;
                }
                .right-btm-main {
                    padding: 22px 2px 20px 37px;
                    width: 1240px;
                    gap: 28px;
                }

                .left-top-main, .left-mid-main, .right-btm-main {
                    display: flex;
                    gap: 32px;
                }

                .mid-area, #map {
                    position: absolute;
                    top: 0;
                    flex: 1;
                    height: 100%;
                    width: 100%;
                    // background-color: #fff;
                }
            }
        }
    }
</style>
