<!-- 燃气风险态势-居民 -->
<script>
export default {
    components:{
    },
    props:{
      list: {
        type: Array,
      }
    },
    data(){
        return{
            // list: [
            //   {street: '春熙路街道', special: '1', point: '1', normal: '1'},
            //   {street: '书院街道', special: '1', point: '1', normal: '1'},
            //   {street: '东湖街道', special: '1', point: '1', normal: '1'},
            //   {street: '测试街道10', special: '1', point: '1', normal: '1'},
            //   {street: '测试街道100', special: '1', point: '1', normal: '1'},
            // ]
        }
    },    
    computed: {
      // 将 list 数据按 3 条划分为一组
      groupedList() {
        const groups = [];
        for (let i = 0; i < this.list.length; i += 3) {
          groups.push(this.list.slice(i, i + 3));
        }
        return groups;
      },
    },
    methods:{
        getRankImage(rank) {
          if (rank === 1) {
            return require('@/assets/image/cockpit/1st.png');
          } else if (rank === 2) {
            return require('@/assets/image/cockpit/2nd.png');
          } else if (rank === 3) {
            return require('@/assets/image/cockpit/3rd.png');
          }

        }
    }
}
</script>
<template>
    <div>
        <div class="header">
          <span class="header-txt" style="width: 72px; text-align: center;">排名</span>
          <span class="header-txt" style="flex: 1; text-align: center;">街道</span>
          <span class="header-txt" style="width: 120px; text-align: center;">特别关注</span>
          <span class="header-txt" style="width: 120px; text-align: center;">重点关注</span>
          <span class="header-txt" style="width: 96px; text-align: center;">一般关注</span>
        </div>
        <div class="table">
          <el-carousel 
            v-if="list && list.length > 0"
            :autoplay="true" 
            :interval="3500" 
            direction="vertical"
          >
            <el-carousel-item v-for="(group, index) in groupedList" :key="index">
              <div v-for="(item, idx) in group" :key="idx" class="item">
                <div class="item-img">
                  <img v-if="index * 3 + idx + 1 <= 3" :src="getRankImage(index * 3 + idx + 1)" alt="" style="width: 22px; height: 32px;">
                  <span v-else>{{index * 3 + idx + 1}}</span>
                </div>
                <div class="item-street">
                  {{item.street}}
                </div>
                <div class="item-special">
                  {{item.special}}
                </div>
                <div class="item-point">
                  {{item.keynote}}
                </div>
                <div class="item-normal">
                  {{item.general}}
                </div>
              </div>
            </el-carousel-item>
          </el-carousel>
          <div v-else class="list-empty">
            暂无数据
          </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
.list-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #909399;
  height: 192px;
  line-height: 192px;
  font-size: 12px;
  background-color: #0c2e55;
}
.header {
  height: 40px;
  background: linear-gradient(#022549 0%, #14569A 100%);
  border-radius: 0;
  border-bottom: 2px solid #4390DE;
  display: flex;
  align-items: center;
}
.header-txt {
  border-right: 1px solid rgba(67, 144, 222, 0.20);
  height: 40px;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
.header-txt:last-child{
  border-right: none;
}
.table {
  // flex: 1;
  // background-color: #fff;
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .item {
    height: 64px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid rgba(67, 144, 222, 0.20);
  }
}
.item-img {
  width: 72px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-right: 1px solid rgba(67, 144, 222, 0.20);
}
.item-street {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  border-right: 1px solid rgba(67, 144, 222, 0.20);
}
.item-special {
  width: 120px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-right: 1px solid rgba(67, 144, 222, 0.20);
}
.item-point {
  width: 120px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-right: 1px solid rgba(67, 144, 222, 0.20);
}
.item-normal {
  width: 96px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.item-img, .item-street, .item-special, .item-point, .item-normal {
  height: 64px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 64px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-carousel__indicator--vertical{
    display: none;
}
::v-deep .el-carousel__arrow--left{
    display: none!important;;
}
::v-deep .el-carousel__arrow--right{
    display: none!important;;
}
</style>