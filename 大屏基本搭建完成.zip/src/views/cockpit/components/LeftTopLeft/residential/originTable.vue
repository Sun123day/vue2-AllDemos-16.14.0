<!-- 燃气风险态势-居民 -->
<!-- 表格样式 -->
<script>
// import { findPayRefundList } from "@/api/costRecord"
export default {
    components:{
    },
    data(){
        return{
            paramExport: null,
        }
    },
    methods:{
        loadTbaleData({resolve,params}){
          
          resolve({
                      records:[
                        {street: '春熙路街道', special: '1',urgency: '1',normal: '1'},
                        {street: '书院街道', special: '1',urgency: '1',normal: '1'},
                        {street: '东湖街道', special: '1',urgency: '1',normal: '1'},
                      ],
                      total:0
                  })
          // findPayRefundList(params).then((res) => {
          //     if(res.code=='200'){
          //         const resData=res.data||{}
          //         resolve({
          //             records:resData.records||[],
          //             total:resData.total
          //         })
          //     }else{
          //         resolve({
          //             records:[],
          //             total:0
          //         })
          //     }
          //   });
        },
        getRankImage(row, rank) {
          if (rank === 1) {
            return require('@/assets/image/cockpit/1st.png');
          } else if (rank === 2) {
            return require('@/assets/image/cockpit/2nd.png');
          } else if (rank === 3) {
            return require('@/assets/image/cockpit/3rd.png');
          }
        }
    }
}
</script>
<template>
    <div>
        <RlTable
            :is-pagination="false"
            @on-change="loadTbaleData"
            :search="false"
        >
        <template #default>
              <el-table-column label="排名" type="index" width="72" fixed="left">
                <template #default="{ row, $index }">
                  <!-- 传递 $index + 1 给 getRankImage，确保从 1 开始 -->
                  <img :src="getRankImage(row, $index + 1)" alt="Rank Image" style="width: 22px; height: 32px;" />
                </template>
              </el-table-column>
                <el-table-column prop="street" label="街道"  width="180" :show-overflow-tooltip="true" />
                <el-table-column prop="special" label="特别关注" :show-overflow-tooltip="true" />
                <el-table-column prop="urgency" label="重点关注" :show-overflow-tooltip="true" />
                <el-table-column prop="normal" label="一般关注" :show-overflow-tooltip="true" />
            </template>
        </RlTable>
    </div>
</template>

<style lang="scss" scoped>
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 58px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
::v-deep .el-table--scrollable-y .el-table__body-wrapper {
  overflow: hidden !important;

}
</style>