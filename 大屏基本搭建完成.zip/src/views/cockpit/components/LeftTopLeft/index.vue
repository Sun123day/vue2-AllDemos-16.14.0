<!-- 费用记录 -->
<template>
  <div class="left-top-left-container">
      <div class="header">
        <BigScreenTab
            :sourceData="tabData"
            v-model="tabType"
            @change="handleChange"
        />
        <p class="txt">总数：<span class="num">{{ categoryTotal }}</span></p>
      </div>
      <Residential
        v-if="tabType == 'RESIDENTIAL'"
        class="table"
        :list = "list"
      />
      <Commercial
        v-if="tabType == 'COMMERCIAL'"
        class="table"
        :list = "list"
      />
  </div>
</template>

<script>
import BigScreenTab from '@/components/BigScreenTab'
import Residential from './residential/index.vue'
import Commercial from './commercial/index.vue'
const POLICY = 'RESIDENTIAL' // 配置选项

import { getUserCount, getUserStatistics } from '@/api/cockpitNew'
export default {
    name: 'customAlarmManage',
    components: {
        BigScreenTab,
        Residential,
        Commercial
    },
    data() {
        return {
            tabType: POLICY,
            tabData: [
                {
                    code: 'RESIDENTIAL',
                    text: '居民',
                },
                {
                    code: 'COMMERCIAL',
                    text: '工商业',
                },
            ],
            categoryTotal: 0,
            list: []
        }
    },
    created(){
      this.handleChange()
    },
    // mounted() {
    //   // 设置定时器，每10秒调用一次
    //   this.intervalId = setInterval(() => {
    //     this.handleChange();
    //   }, 10000); // 10000毫秒 = 10秒
    // },
    // beforeDestroy() {
    //   // 清理定时器
    //   if (this.intervalId) {
    //     clearInterval(this.intervalId);
    //   }
    // },
    methods: {
        handleChange() {
          // console.log(this.tabType);
          this.getUserCount()
          this.getUserStatistics()
        },
        getUserCount(){
          const category = this.tabType == 'RESIDENTIAL'? 0 : 1
          getUserCount(category).then((res) => {
            if(res.code == '200'){
              this.categoryTotal = res.data || 0
            }
          })
        },
        getUserStatistics(){
          const category = this.tabType == 'RESIDENTIAL'? 0 : 1
          getUserStatistics(category).then(res => {
            if(res.code == '200'){
              this.list = res.data || []
            }
          })
        }
    },
}
</script>
<style lang="scss" scoped>
.left-top-left-container {
  width: 595px;
  height: 100%;
  // background-color: #fff;
}
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 36px;
  margin-bottom: 7px;

  .txt {
    // width: 48px;
    height: 22px;
    font-family: PingFang SC, PingFang SC;
    font-weight: 400;
    font-size: 16px;
    color: #4390DE;
    line-height: 19px;
    text-align: center;
    font-style: normal;
    text-transform: none;
    .num {
      height: 22px;
      font-family: DINPro, DINPro;
      font-weight: bold;
      font-size: 16px;
      color: #2AFFFF;
      line-height: 19px;
      text-align: center;
      font-style: normal;
      text-transform: none;
    }
  }
}

.table {
  height: 231px;
  width: 595px;
  position: relative;
  border: 2px solid #4390DE;
}
</style>