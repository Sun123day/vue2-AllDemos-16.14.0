<template>
    <div>
        <div class="title-container">
            <span class="title">安全隐患巡查</span>
            <div class="title-btn-container">
                <span 
                    class="title-btn-txt" 
                    @click="safeDayClick"
                    :class="{ 'selected': isSelected('day') }"
                >今日</span>
                <span class="title-btn-line"></span>
                <span 
                    class="title-btn-txt" 
                    @click="safeWeekClick"
                    :class="{ 'selected': isSelected('week') }"
                >周</span>
                <span class="title-btn-line"></span>
                <span 
                    class="title-btn-txt"
                    @click="safeMonthClick"
                    :class="{ 'selected': isSelected('month') }"
                >月</span>
                <span class="title-btn-line"></span>
                <span
                    class="title-btn-txt"
                    @click="safeYearClick"
                    :class="{ 'selected': isSelected('year') }"
                >年</span>
                <span class="title-btn-line"></span>
                <span
                    class="title-btn-txt"
                    @click="safeAllClick"
                    :class="{ 'selected': isSelected('all') }"
                >全部</span>
                <span class="title-btn-line"></span>
            </div>
        </div>
        <div class="main-content">
            <div class="item">
                <div class="visit">上门安检</div>
                <div class="item-content">
                    <div class="item-item">
                        <div class="item-txt">巡查次数</div>
                        <div>
                            <span class="item-num">{{ computedVisitNum1 }}</span>
                            <span class="item-unit">次</span>
                        </div>
                    </div>
                    <div class="item-item">
                        <div class="item-txt">巡查点位</div>
                        <div>
                            <span class="item-num">{{ computedVisitNum2 }}</span>
                            <span class="item-unit">次</span>
                        </div>
                    </div>
                    <div class="item-item">
                        <div class="item-txt">发现隐患</div>
                        <div>
                            <span class="item-num">{{ computedVisitNum3 }}</span>
                            <span class="item-unit">次</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="else">其他</div>
                <div class="item-content">
                    <div class="item-item">
                        <div class="item-txt">举报隐患数</div>
                        <div>
                            <span class="item-num">{{ computedElseNum1 }}</span>
                            <span class="item-unit">条</span>
                        </div>
                    </div>
                    <div style="height: 20px;">
                    </div>
                    <div class="item-item">
                        <div class="item-txt">其他渠道隐患数</div>
                        <div>
                            <span class="item-num">{{ computedElseNum2 }}</span>
                            <span class="item-unit">条</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="noperson">到访不遇</div>
                <div class="noperson-total">
                    <div class="noperson-total-txt"></div>
                    <div class="noperson-total-txt">总数：{{ computedNoPersonNum4 }}</div>
                </div>
                <div class="item-content">
                    <div class="item-item">
                        <div class="item-txt">空巢巡查数</div>
                        <div>
                            <span class="item-num">{{ computedNoPersonNum1 }}</span>
                            <span class="item-unit">次</span>
                        </div>
                    </div>
                    <div class="item-item">
                        <div class="item-txt">残疾巡查数</div>
                        <div>
                            <span class="item-num">{{ computedNoPersonNum2 }}</span>
                            <span class="item-unit">次</span>
                        </div>
                    </div>
                    <div class="item-item">
                        <div class="item-txt">高龄巡查数</div>
                        <div>
                            <span class="item-num">{{ computedNoPersonNum3 }}</span>
                            <span class="item-unit">次</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import dayjs from 'dayjs';
import { getHiddenDangerVisit, getHiddenDangerElse, getHiddenDangerNoPerson } from '@/api/cockpitNew';
export default {
    data() {
      return {
        safeSelected: 'day',
        start: dayjs().format('YYYY-MM-DD'),
        end: dayjs().format('YYYY-MM-DD'),

        visitList: [],
        elseList: null,
        noPersonList: null,
        
        intervalId: null,    // 保存定时器的 ID
        timeTypes: ['day', 'week', 'month', 'year', 'all'],
        currentIndex: 0,     // 当前执行的时间类型索引
      }
    },
    created(){
        this.safeDayClick()
    },
    // mounted() {
    //     // 启动定时器，每 10 秒触发一次
    //     this.startAutoSwitch();  // 启动定时切换
    // },
    // beforeDestroy() {
    //     if (this.intervalId) {
    //         clearInterval(this.intervalId);  // 组件销毁时清除定时器
    //     }
    // },
    computed:{
        // 上门安检
        computedVisitList(){
            if(!this.visitList || this.visitList.length === 0){
                // console.log("进入了");
                return [
                    // { name: '巡查次数', num: 0},
                    // { name: '巡查点位', num: 0},
                    // { name: '发现隐患', num: 0},
                    0,
                    0,
                    0,
                ]
            }
            else {
                // console.log("进入了2");
                return this.visitList
            }
        },
        computedVisitNum1(){
            // const item = this.computedVisitList.filter(item => item.name === '巡查次数')
            // return item[0]?.num || 0
            // console.log("进入了3", this.computedVisitList);
            return this.computedVisitList[0] || 0
        },
        computedVisitNum2(){
            // const item = this.computedVisitList.filter(item => item.name === '巡查点位')
            // return item[0]?.num || 0
            return this.computedVisitList[1] || 0
        },
        computedVisitNum3(){
            // const item = this.computedVisitList.filter(item => item.name === '发现隐患')
            // return item[0]?.num || 0
            return this.computedVisitList[2] || 0
        },

        // 其他
        computedElseList(){
            if(!this.elseList){
                return {
                    1: 0,
                    2: 0,
                }
            }
            else {
                return this.elseList
            }
        },
        // 计算并返回 computedElseList 中键 1 对应的值，若不存在则返回 0
        computedElseNum1() {
            const list = this.computedElseList;
            // 如果 list 中有键 1，返回该键的值，否则返回 0
            return list.hasOwnProperty(1) ? list[1] : 0;
        },
        // 计算并返回 computedElseList 中键 2 对应的值，若不存在则返回 0
        computedElseNum2() {
            const list = this.computedElseList;
            // 如果 list 中有键 2，返回该键的值，否则返回 0
            return list.hasOwnProperty(2) ? list[2] : 0;
        },

        // 到访不遇
        computedNoPersonList(){
            if(!this.noPersonList){
                return {
                    0: 0, // 高龄
                    1: 0, // 残疾
                    2: 0, // 空巢
                    3: 0, // 总数
                }
            }
            else {
                return this.noPersonList
            }
        },
        // 空巢
        computedNoPersonNum1() {
            const list = this.computedNoPersonList;
            return list.hasOwnProperty(2) ? list[2] : 0;
        },
        // 残疾
        computedNoPersonNum2() {
            const list = this.computedNoPersonList;
            return list.hasOwnProperty(1)? list[1] : 0;
        },
        // 高龄
        computedNoPersonNum3() {
            const list = this.computedNoPersonList;
            return list.hasOwnProperty(0)? list[0] : 0;
        },
        // 总数
        computedNoPersonNum4() {
            const list = this.computedNoPersonList;
            return list.hasOwnProperty(3)? list[3] : 0;
        },

    },
    methods:{
      // 启动定时器每10秒自动切换
      startAutoSwitch() {
          this.intervalId = setInterval(() => {
              // 根据当前的索引调用相应的点击方法
              switch (this.timeTypes[this.currentIndex]) {
                  case 'day':
                      this.safeDayClick();
                      break;
                  case 'week':
                      this.safeWeekClick();
                      break;
                  case 'month':
                      this.safeMonthClick();
                      break;
                  case 'year':
                      this.safeYearClick();
                      break;
                  case 'all':
                      this.safeAllClick();
                      break;
              }
  
              // 更新当前索引，确保循环调用
              this.currentIndex = (this.currentIndex + 1) % this.timeTypes.length;
          }, 10000); // 每10秒执行一次
      },
      safeDayClick() {
        //   console.log("请求了日");
          this.safeSelected = 'day';
          this.start = dayjs().format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
          this.getAllData(this.start, this.end)
      },
      safeWeekClick() {
        //   console.log("请求了周");
          this.safeSelected = 'week';
          this.start = dayjs().subtract(7, 'day').format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
          this.getAllData(this.start, this.end)
      },
      safeMonthClick() {
          this.safeSelected = 'month';
          this.start = dayjs().subtract(1, 'month').format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
          this.getAllData(this.start, this.end)
      },
      safeYearClick() {
          this.safeSelected = 'year';
          this.start = dayjs().subtract(1,'year').format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
          this.getAllData(this.start, this.end)
      },
      safeAllClick() {
          this.safeSelected = 'all';
          this.start = ''
          this.end = '';
          this.getAllData(this.start, this.end)
      },
      isSelected(value) {
          return this.safeSelected === value;
      },
      getAllData(start, end) {
        const params = {
            areaId: this.$store.state.areaId,
            start: start,
            end: end,
        }
        getHiddenDangerVisit(params).then(res => {
            if(res.code == 200){
                this.visitList = res.data
            }
        })
        getHiddenDangerElse(params).then(res => {
            if(res.code == 200){
                this.elseList = res.data
            }
        })
        getHiddenDangerNoPerson(params).then(res => {
            if(res.code == 200){
                this.noPersonList = res.data
            }
        })
      }
    }
}
</script>

<style lang="scss" scoped>
.title-container {
    width: 100%;
    height: 26px;
    background-image: url('~@/assets/image/cockpit/title-container.png');
    background-size: 1280px 26px;
    background-repeat: no-repeat;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .title {
        height: 26px;
        font-family: YouSheBiaoTiHei, YouSheBiaoTiHei;
        font-weight: bold;
        font-size: 20px;
        color: #2AFFFF;
        line-height: 26px;
        text-align: left;
        font-style: italic;
        text-transform: none;
        margin-left: 34px;
    }
    .title-btn-container {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-right: 30px;

        .title-btn-txt{
            height: 16px;
            font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
            font-weight: 400;
            font-size: 16px;
            color: #00FFFF;
            line-height: 16px;
            text-align: left;
            font-style: normal;
            text-transform: none;
            cursor: pointer;
        }
        .title-btn-line {
            border: 1px solid #00FFFF;
            height: 18px;
        }
        .selected {
            color: #FFAB2D; // 选中时字体颜色变为#FFAB2D
        }
    }
}
.main-content {
    padding: 32px 52px;
    display: flex;
    gap: 25px;
}
.item {
    width: 375px;
    height: 232px;
    background-image: url('~@/assets/image/cockpit/safe-bg.png');
    background-size: 375px 232px;
    background-repeat: no-repeat;

    display: flex;
    flex-direction: column;
    align-items: center;

    .visit {
        background-image: url('~@/assets/image/cockpit/visit.png');
    }
    .else {
        background-image: url('~@/assets/image/cockpit/else.png');
    }
    .noperson {
        background-image: url('~@/assets/image/cockpit/noperson.png');
    }

    .visit, .else, .noperson {
        width: 142px;
        margin-top: 17px;
        margin-bottom: 9px;
        margin-left: 38px;
        background-size: 142px 34px;
        background-repeat: no-repeat;

        font-family: PingFang SC, PingFang SC;
        font-weight: bold;
        font-size: 15px;
        line-height: 20px;
        text-align: left;
        font-style: normal;
        text-transform: none;
        color: #9ADDFF;

        padding: 7px 0 7px 43px;
    }

    .item-content {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-evenly;
        flex: 1;
        width: 100%;
    }

    .item-item {
        display: flex;
        align-items: center;
        justify-content: space-between;

        width: 203px;
        height: 20px;
        padding: 8px 17px;
        background-image: url('~@/assets/image/cockpit/safeItem.png');
        background-size: 237px 36px;
        background-repeat: no-repeat;

        .item-txt, .item-num, .item-unit {
            height: 20px;
            font-family: PingFang SC, PingFang SC;
            font-weight: 400;
            font-size: 14px;
            color: #BDE7FF;
            line-height: 20px;
            text-align: left;
            font-style: normal;
            text-transform: none;
        }
        .item-num {
            color: #2AFFFF;
        }
    }

    .noperson-total {
        display: flex;
        justify-content: space-between !important;
        width: 100%;
        
        .noperson-total-txt {
            height: 20px;
            font-family: PingFang SC, PingFang SC;
            font-weight: bold;
            font-size: 14px;
            color: #FFB800;
            line-height: 20px;
            text-align: left;
            font-style: normal;
            text-transform: none;
            margin-right: 16px;
        }
    }
}
</style>