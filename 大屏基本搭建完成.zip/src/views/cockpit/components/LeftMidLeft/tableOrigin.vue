<!-- 燃气风险态势-居民 -->
<script>
// import { findPayRefundList } from "@/api/costRecord"
export default {
    components:{
    },
    data(){
        return{
            paramExport: null,
        }
    },
    methods:{
        loadTbaleData({resolve,params}){
          
          resolve({
                      records:[
                        {name: '数量', street: 1, special: null, urgency: 10, normal: 15},
                        {name: '占比', street: 2, special: 15, urgency: 0, normal: 10},
                        {name: '环比', street: 3, special: 1, urgency: null, normal: 10},
                      ],
                      total:0
                  })
          // findPayRefundList(params).then((res) => {
          //     if(res.code=='200'){
          //         const resData=res.data||{}
          //         resolve({
          //             records:resData.records||[],
          //             total:resData.total
          //         })
          //     }else{
          //         resolve({
          //             records:[],
          //             total:0
          //         })
          //     }
          //   });
        },
    }
}
</script>
<template>
    <div>
        <RlTable
            :is-pagination="false"
            @on-change="loadTbaleData"
            :search="false"
        >
          <template #default>
                <el-table-column 
                  label="安全事件" 
                  width="135"
                  show-overflow-tooltip 
                  align="right"
                >
                  <el-table-column
                    prop="name"
                    label="指标"
                    width="128"
                    show-overflow-tooltip
                    align="left"
                  />
                </el-table-column>
                <el-table-column prop="street" label="全部" >
                  <template slot-scope="scope">
                    <span v-if="scope.row.street">{{ scope.row.street }}</span>
                    <span v-else>0</span>
                  </template>
                </el-table-column>
                <el-table-column prop="special" label="已办结" >
                  <template slot-scope="scope">
                    <span v-if="scope.row.special">{{ scope.row.special }}</span>
                    <span v-else>0</span>
                  </template>
                </el-table-column>
                <el-table-column prop="urgency" label="正在办理" >
                  <template slot-scope="scope">
                    <span v-if="scope.row.urgency">{{ scope.row.urgency }}</span>
                    <span v-else>0</span>
                  </template>
                </el-table-column>
                <el-table-column prop="normal" label="超期办结" >
                  <template slot-scope="scope">
                    <span v-if="scope.row.normal" style="color: #FF0000;">{{ scope.row.normal }}</span>
                    <span v-else>0</span>
                  </template>
                </el-table-column>
            </template>
        </RlTable>
    </div>
</template>

<style lang="scss" scoped>
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  // height: 58px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  // line-height: 58px;
  // text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  // height: 48px !important;
  height: 60px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
::v-deep .el-table--scrollable-y .el-table__body-wrapper {
  overflow: hidden !important;

}


::v-deep .el-table thead.is-group th {
  background: none !important;
}
::v-deep .el-table thead.is-group tr:first-of-type th:first-of-type {
  border-bottom: none !important;
}
::v-deep .el-table thead.is-group tr:first-of-type th:first-of-type:before {
  content: '' !important;
  position: absolute !important;
  width: 1px !important;
  height: 100px !important;
  top: 0 !important;
  left: 0 !important;
  background-color: #fff !important;
  opacity: 0.3 !important;
  display: block !important;
  /* 对不齐就调整角度和表格中的宽度 */
  transform: rotate(-64deg) !important;
  transform-origin: top !important;
}
::v-deep .el-table thead.is-group tr:last-of-type th:first-of-type:before {
  content: '' !important;
  position: absolute !important;
  width: 1px !important;
  height: 100px !important;
  bottom: 0 !important;
  right: 0 !important;
  background-color: #fff !important;
  opacity: 0.3 !important;
  display: block !important;
  /* 对不齐就调整角度和表格中的宽度 */
  transform: rotate(-67deg) !important;
  transform-origin: bottom !important;
}
::v-deep .el-table thead.is-group tr {
  height: 29px !important;
}
</style>