<!-- 费用记录 -->
<template>
  <div class="left-mid-left-container">
      <!-- <div class="header"> -->
        <!-- <el-select
            v-model="timeType"
            :clearable="false"
            filterable
            placeholder="请选择"
            transfer
            style="width:125px; margin-right: 11px;"
        >
            <el-option
                v-for="item in timeTypeList"
                :key="item.code"
                :value="item.code"
                :label="item.name"
            />
        </el-select>
        <div class="calendar-container"> -->
            <!-- <el-date-picker
                v-model="startTime"
                style="width: 200px;"
                :editable="false"
                :clearable="false"
                class="calendar"
            />
            <span class="txt">至</span>
            <el-date-picker
                v-model="endTime"
                style="width: 200px;"
                :editable="false"
                :clearable="false"
                class="calendar"
            />
            <img class="calendar-img" src="~@/assets/image/cockpit/calendar.png" alt=""> -->
            <!-- <el-date-picker
                v-model="time"
                type="week"
                format="yyyy 第 WW 周"
                :editable="false"
                :clearable="false"
                class="calendar-single"
                style="width: 100%;"
            /> -->
                <!-- suffix-icon="el-icon-date" -->
        <!-- </div> -->
      <!-- </div> -->
      <div class="table">
        <Table />
      </div>
  </div>
</template>

<script>
import dayjs from 'dayjs';
import Table from './table.vue'
export default {
    components:{
        Table,
    },
    data() {
        return {
            time: dayjs().format('YYYY-MM-DD'),
            startTime: dayjs().format('YYYY-MM-DD'),
            endTime: dayjs().format('YYYY-MM-DD'),
            timeTypeList: [
                {
                    code: 'week',
                    name: '近一周',
                },
                {
                    code: 'month',
                    name: '近一月',
                },
                {
                    code: 'year',
                    name: '近一年',
                },
            ],
            timeType: 'week',
        }
    },
    methods: {
    },
}
</script>
<style lang="scss" scoped>
.left-mid-left-container {
  width: 595px;
//   height: 100%;
  // background-color: #fff;
}
.header {
  display: flex;
  align-items: center;
//   justify-content: space-between;
  height: 36px;
  margin-bottom: 7px;
  width: 599px;
}

.table {
//   height: 231px;
//   height: 200px;
  margin-top: 8px;
  height: 236px;
  width: 595px;
  position: relative;
  border: 2px solid #4390DE;
}
::v-deep .el-input__inner {
    border-radius: 0 !important;
    border: 1px solid #4390DE !important;
    height: 36px !important;
}
// ::v-deep .el-select:hover .el-input__inner {
//     border: 1px solid #4390DE !important;
// }
//使select右侧箭头换成自己的图片，并且调整箭头方向向下
// ::v-deep .el-select .el-input .el-select__caret::before {
//     /*content: "\e78f"*/
//     content: "";/*去除select默认的下拉图标*/
//     background: url('~@/assets/image/cockpit/select-arrow.png') center center no-repeat;
//     background-size: 14px 14px;
//     position: absolute;
//     width: 100%;
//     height: 100%;
//     //使图片箭头向下
//     appearance: none;// 去除select默认的下拉图标
//     -moz-appearance: none; // 兼容chrome
//     -webkit-appearance: none;// 兼容firefox
//     -webkit-transform: rotate(180deg);/* Safari 和 Chrome */
//     -moz-transform: rotate(180deg);/* Firefox */
//     -o-transform: rotate(180deg);/* Opera */
//     -ms-transform: rotate(180deg);/* IE 9 */
//     transform: rotate(180deg);/* 旋转180度图片 */
//     top: 0%;
//     right: 10%;
//   }
::v-deep .el-select .el-input .el-select__caret {
    color: #4390DE !important
}
.calendar-container {
    display: flex;
    align-items: center;
    // justify-content: space-between;
    // flex: 1;
    border: 1px solid #4390DE !important;
}
.calendar ::v-deep .el-input__inner {
    border: none !important;
    padding-left: 42px !important;
    padding-right: 56px !important;

}
.calendar ::v-deep.el-icon-date:before {
    content: '' !important;
}
.txt {
    height: 22px;
    font-family: PingFang SC, PingFang SC;
    font-weight: bold;
    font-size: 16px;
    color: #32C5FF;
    line-height: 19px;
    text-align: left;
    font-style: normal;
    text-transform: none;
    margin-right: 15px;
    margin-left: 9px;
}
.calendar-img {
    width: 16px;
    height: 16px;
}
.calendar-single ::v-deep.el-icon-date:before {
    content: '' !important;
}
.calendar-single ::v-deep.el-input__suffix {
    width: 25px !important;
}
.calendar-single ::v-deep.el-input__suffix:before {
    content: "\e78e" !important;
    font-family: element-icons !important;
    color: #32C5FF !important;

}
</style>