<script>
import { getSecurityCheckStatistics } from '@/api/cockpitNew'
export default {
    components:{
    },
    data(){
        return{
            list: []
        }
    },
    created(){
      this.getStatisticsList()
    },
    // mounted() {
    //   // 设置定时器，每10秒调用一次
    //   this.intervalId = setInterval(() => {
    //     this.getStatisticsList();
    //   }, 10000); // 10000毫秒 = 10秒
    // },
    // beforeDestroy() {
    //   // 清理定时器
    //   if (this.intervalId) {
    //     clearInterval(this.intervalId);
    //   }
    // },
    computed:{
      computedList(){
        if(!this.list || this.list.length === 0){
          // console.log("进入了");
          return [
            { name: '全部事件', num: 0, rate: 0, periodRate: 0 },
            { name: '已办结', num: 0, rate: 0, periodRate: 0 },
            { name: '正在办理', num: 0, rate: 0, periodRate: 0 },
            { name: '已逾期', num: 0, rate: 0, periodRate: 0 },
          ]
        }
        else {
          // console.log("进入了2");
          return this.list
        }
      },
      // 全部事件
      computedAllNum() {
        const item = this.computedList.filter(item => item.name === '全部事件')
        return item[0]?.num || 0
      },
      computedAllRate() {
        const item = this.computedList.filter(item => item.name === '全部事件')
        return item[0]?.rate || 0
      },
      computedAllPeriodRate() {
        const item = this.computedList.filter(item => item.name === '全部事件')
        return item[0]?.periodRate || 0
      },
      // 已办结
      computedFinishedNum() {
        const item = this.computedList.filter(item => item.name === '已办结')
        return item[0]?.num || 0
      },
      computedFinishedRate() {
        const item = this.computedList.filter(item => item.name === '已办结')
        return item[0]?.rate || 0
      },
      computedFinishedPeriodRate() {
        const item = this.computedList.filter(item => item.name === '已办结')
        return item[0]?.periodRate || 0
      },
      // 正在办理
      computedProcessNum() {
        const item = this.computedList.filter(item => item.name === '正在办理')
        return item[0]?.num || 0
      },
      computedProcessRate() {
        const item = this.computedList.filter(item => item.name === '正在办理')
        return item[0]?.rate || 0
      },
      computedProcessPeriodRate() {
        const item = this.computedList.filter(item => item.name === '正在办理')
        return item[0]?.periodRate || 0
      },
      // 已逾期
      computedOverdueNum() {
        const item = this.computedList.filter(item => item.name === '已逾期')
        return item[0]?.num || 0
      },
      computedOverdueRate() {
        const item = this.computedList.filter(item => item.name === '已逾期')
        return item[0]?.rate || 0
      },
      computedOverduePeriodRate() {
        const item = this.computedList.filter(item => item.name === '已逾期')
        return item[0]?.periodRate || 0
      },

    },
    methods:{
      getStatisticsList(){
        getSecurityCheckStatistics().then((res)=>{
          if(res.code=='200'){
            this.list=res.data||[]
          }
        })
      }
    }
}
</script>
<template>
    <div>
      <div class="header">
        <div class="header1" style="flex: 1;">
          <div class="header1-top">指标</div>
          <div class="header1-btm">事件</div>
        </div>
        <div class="header2" style="width: 120px;">全部事件</div>
        <div class="header3" style="width: 120px;">已办结</div>
        <div class="header4" style="width: 120px;">正在办理</div>
        <div class="header5" style="width: 120px;">已逾期</div>
      </div>
      <div class="table">
        <div class="item">
          <div class="item1" style="flex: 1;">数量</div>
          <div class="item2" style="width: 120px;">{{ computedAllNum }}</div>
          <div class="item3" style="width: 120px;">{{ computedFinishedNum }}</div>
          <div class="item4" style="width: 120px;">{{ computedProcessNum }}</div>
          <div class="item5" style="width: 120px;">{{ computedOverdueNum }}</div>
        </div>
        <div class="item">
          <div class="item1" style="flex: 1;">占比</div>
          <div class="item2" style="width: 120px;">{{ computedAllRate }}%</div>
          <div class="item3" style="width: 120px;">{{ computedFinishedRate }}%</div>
          <div class="item4" style="width: 120px;">{{ computedProcessRate }}%</div>
          <div class="item5" style="width: 120px;">{{ computedOverdueRate }}%</div>
        </div>
        <div class="item">
          <div class="item1" style="flex: 1;">环比</div>
          <div class="item2 item-last-row" style="width: 120px;">
            {{ computedAllPeriodRate }}%
            <img v-if="computedAllPeriodRate > 0" src="~@/assets/image/cockpit/arrow_up.png" alt="" class="item-img">
            <img v-if="computedAllPeriodRate < 0" src="~@/assets/image/cockpit/arrow_down.png" alt="" class="item-img">
          </div>
          <div class="item3 item-last-row" style="width: 120px;">
            {{ computedFinishedPeriodRate }}%
            <img v-if="computedFinishedPeriodRate > 0" src="~@/assets/image/cockpit/arrow_up.png" alt="" class="item-img">
            <img v-if="computedFinishedPeriodRate < 0" src="~@/assets/image/cockpit/arrow_down.png" alt="" class="item-img">
          </div>
          <div class="item4 " style="width: 120px;">
            {{ computedProcessPeriodRate }}%
            <img v-if="computedProcessPeriodRate > 0" src="~@/assets/image/cockpit/arrow_up.png" alt="" class="item-img">
            <img v-if="computedProcessPeriodRate < 0" src="~@/assets/image/cockpit/arrow_down.png" alt="" class="item-img">
          </div>
          <div class="item5 item-last-row" style="width: 120px; color: #fff;">
            {{ computedOverduePeriodRate }}%
            <img v-if="computedOverduePeriodRate > 0" src="~@/assets/image/cockpit/arrow_up.png" alt="" class="item-img">
            <img v-if="computedOverduePeriodRate < 0" src="~@/assets/image/cockpit/arrow_down.png" alt="" class="item-img">
          </div>
        </div>
      </div>
    </div>
</template>

<style lang="scss" scoped>
.header {
  display: flex;
  height: 56px;
  border-bottom: 2px solid #4390DE;
  background: linear-gradient(#022549 0%, #14569A 100%);
}
.header1,.header2,.header3,.header4,.header5 {
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px;
  color: #32C5FF;
  text-align: center;
  font-style: normal;
  text-transform: none;
}
.header1,.header2,.header3,.header4 {
  border-right: 1px solid rgba(67,144,222,0.2);
}
.header2,.header3,.header4,.header5 {
  line-height: 56px;
}
.header1 {
  display: flex;
  .header1-top, .header1-btm {
    height: 56px;
    display: flex;
  }
  .header1-top {
    width: 105px;
    justify-content: flex-start;
    background: linear-gradient(-150deg, transparent 59px, transparent 0);
    margin-right: -61px;
    align-items: flex-end;
    padding-left: 15px;
    padding-bottom: 4px;
    position: relative;

  }
  .header1-top::before {
    content: '';
    height: 57px;
    width: 0.5px;
    background-color: #4390DE;
    transform: rotateZ(116.7deg) scale(2.24);
    position: absolute;
    left: 56px;
  }
  .header1-btm {
    width: 102px;
    align-items: flex-start;
    justify-content: flex-end;
    background: linear-gradient(30deg, transparent 56px, transparent 0);
    margin-left: -66px;
    padding-top: 4px;
    padding-right: 11px;
  }
}
.table {
  flex: 1;
}
.item {
  display: flex;
  align-items: center;
  border-bottom: 1px solid rgba(67,144,222,0.2);
  height: 59px;
  // height: 48px;
}
.item1,.item2,.item3,.item4 {
  border-right: 1px solid rgba(67,144,222,0.2);
}
.item1 {
  height: 59px;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px;
  color: #32C5FF;
  line-height: 59px;
  text-align: center;
  font-style: normal;
  text-transform: none;
}
.item2, .item3, .item4 {
  height: 59px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 59px;
  text-align: center;
  font-style: normal;
  text-transform: none;
}
.item5 {
  height: 59px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FF0000;
  line-height: 59px;
  text-align: center;
  font-style: normal;
  text-transform: none;
}
.item-last-row {
  display: flex;
  align-items: center;
  justify-content: center;
}
.item-img {
  width: 8px;
  height: 18px;
  margin-left: 5px;
}
</style>