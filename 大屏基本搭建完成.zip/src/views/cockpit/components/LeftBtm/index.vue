<template>
  <div>
    <div class="left-btm-content">
      <div class="main">
          <!-- 燃气风险分类  -->
          <div @click="handleLeftClick1" class="item-left-1"><div class="txt-container"><span class="num">{{ computedLeft1 }}</span><span class="unit">个</span></div></div>
          <div @click="handleLeftClick2" class="item-left-2"><div class="txt-container"><span class="num">{{ computedLeft2 }}</span><span class="unit">个</span></div></div>
          
          <!-- 设施类 热水器类 灶具类 燃气软用管类 -->
          <div @click="handleLeftClick3" class="item-left-3"><div class="txt-container"><span class="num">{{ computedLeft3 }}</span><span class="unit">个</span></div></div>
          <div @click="handleLeftClick4" class="item-left-4"><div class="txt-container"><span class="num">{{ computedLeft4 }}</span><span class="unit">个</span></div></div>
          <div @click="handleLeftClick5" class="item-left-5"><div class="txt-container"><span class="num">{{ computedLeft5 }}</span><span class="unit">个</span></div></div>
          <div @click="handleLeftClick6" class="item-left-6"><div class="txt-container"><span class="num">{{ computedLeft6 }}</span><span class="unit">个</span></div></div>
          
          <!-- 燃气风险分类  -->
          <div @click="handleRightClick1" class="item-right-1"><div class="txt-container"><span class="num">{{ computedRight1 }}</span><span class="unit">个</span></div></div>
          <div @click="handleRightClick2" class="item-right-2"><div class="txt-container"><span class="num">{{ computedRight2 }}</span><span class="unit">个</span></div></div>
          
          <!-- 用户类型风险 空巢 残疾 高龄 -->
          <div @click="handleRightClick3" class="item-right-3"><div class="txt-container"><span class="num">{{ computedRight3 }}</span><span class="unit">个</span></div></div>
          <div @click="handleRightClick4" class="item-right-4"><div class="txt-container"><span class="num">{{ computedRight4 }}</span><span class="unit">个</span></div></div>
          <div @click="handleRightClick5" class="item-right-5"><div class="txt-container"><span class="num">{{ computedRight5 }}</span><span class="unit">个</span></div></div>
      </div>
    </div>
  </div>
</template>

<script>
import Letf1 from './components/left1/index.vue'
import Letf2 from './components/left2/index.vue'
import Letf3 from './components/left3/index.vue'
import Letf4 from './components/left4/index.vue'
import Letf5 from './components/left5/index.vue'
import Letf6 from './components/left6/index.vue'
import Right1 from './components/right1/index.vue'
import Right2 from './components/right2/index.vue'
import Right3 from './components/right3/index.vue'
import Right4 from './components/right4/index.vue'
import Right5 from './components/right5/index.vue'

import { getRiskUserType, getRiskCount, getFacilityCount } from '@/api/cockpitNew'
export default {
  components:{
    Letf1,
    Letf2,
    Letf3,
    Letf4,
    Letf5,
    Letf6,
    Right1,
    Right2,
    Right3,
    Right4,
    Right5,
  },
  data(){
    return {
      topList: [],
      leftbtmList: null,
      rightbtmList:[]
    }
  },
  created(){
    this.getTypes()
  },
  // mounted() {
  //   // 设置定时器，每10秒调用一次
  //   this.intervalId = setInterval(() => {
  //     this.getTypes();
  //   }, 10000); // 10000毫秒 = 10秒
  // },
  // beforeDestroy() {
  //   // 清理定时器
  //   if (this.intervalId) {
  //     clearInterval(this.intervalId);
  //   }
  // },
  computed: {
    computedTopList() {
      if(!this.topList || this.topList.length === 0){
        // console.log("进入了");
        return [
          0,
          0,
          0,
          0
        ]
      }
      else {
        // console.log("进入了2");
        return this.topList
      }
    },
    computedLeft1(){
      return this.computedTopList[0] || 0
    },
    computedLeft2(){
      return this.computedTopList[1] || 0
    },
    computedRight1(){
      return this.computedTopList[2] || 0
    },
    computedRight2(){
      return this.computedTopList[3] || 0
    },
    computedRightBtmList() {
      if(!this.rightbtmList || this.rightbtmList.length === 0){
        // console.log("进入了");
        return [
          {userType: 2, num: 0},
          {userType: 0, num: 0},
          {userType: 1, num: 0},
        ]
      }
      else {
        // console.log("进入了2");
        return this.rightbtmList
      }
    },
    computedRight3(){
      const item = this.computedRightBtmList.filter(item => item.userType === 2)
      return item[0]?.num || 0
    },
    computedRight4(){
      const item = this.computedRightBtmList.filter(item => item.userType === 1)
      return item[0]?.num || 0
    },
    computedRight5(){
      const item = this.computedRightBtmList.filter(item => item.userType === 0)
      return item[0]?.num || 0
    },

    // 到访不遇
    computedLeftBtmList(){
        if(!this.leftbtmList){
            return {
                0: 0, // 设施类 
                1: 0, // 热水器类
                2: 0, // 灶具类 
                3: 0, // 燃气软用管类
            }
        }
        else {
            return this.leftbtmList
        }
    },
    computedLeft3() {
        const list = this.computedLeftBtmList;
        return list.hasOwnProperty(0) ? list[0] : 0;
    },
    computedLeft4() {
        const list = this.computedLeftBtmList;
        return list.hasOwnProperty(1) ? list[1] : 0;
    },
    computedLeft5() {
        const list = this.computedLeftBtmList;
        return list.hasOwnProperty(2) ? list[2] : 0;
    },
    computedLeft6() {
        const list = this.computedLeftBtmList;
        return list.hasOwnProperty(3) ? list[3] : 0;
    },
  },  
  // mounted() {
  //   // 设置定时器，每10秒调用一次
  //   this.intervalId = setInterval(() => {
  //     this.getTypes();
  //   }, 10000); // 10000毫秒 = 10秒
  // },
  // beforeDestroy() {
  //   // 清理定时器
  //   if (this.intervalId) {
  //     clearInterval(this.intervalId);
  //   }
  // },
  methods:{
    getTypes(){
      this.getTOP()
      this.getRightBTM()
      this.getLeftBTM()
    },
    getTOP(){
      getRiskCount(this.$store.state.areaId).then(res => {
        if(res.code == 200) {
          this.topList = res.data
        }
      })
    },
    getRightBTM(){
      getRiskUserType().then(res => {
        if(res.code == 200) {
          this.rightbtmList = res.data
        }
      })
    },
    getLeftBTM(){
      getFacilityCount(this.$store.state.areaId).then(res => {
        if(res.code == 200) {
          this.leftbtmList = res.data
        }
      })
    },
    handleLeftClick1(){
      new this.$pageModal(
          Letf1,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleLeftClick2(){
      new this.$pageModal(
          Letf2,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleLeftClick3(){
      new this.$pageModal(
          Letf3,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleLeftClick4(){
      new this.$pageModal(
          Letf4,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleLeftClick5(){
      new this.$pageModal(
          Letf5,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleLeftClick6(){
      new this.$pageModal(
          Letf6,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleRightClick1(){
      new this.$pageModal(
          Right1,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleRightClick2(){
      new this.$pageModal(
          Right2,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleRightClick3(){
      new this.$pageModal(
          Right3,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleRightClick4(){
      new this.$pageModal(
          Right4,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    handleRightClick5(){
      new this.$pageModal(
          Right5,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },

  }
}
</script>

<style lang="scss" scoped>
.left-btm-content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
}
.main {
  // width: 1152px;
  // height: 281px;
  width: 1066px;
  height: 225px;
  // background-image: url('~@/assets/image/cockpit/left-btm.png');
  background-image: url('~@/assets/image/cockpit/left-btm-bg.png');
  // background-size: 1152px 281px;
  background-size: 1066px 225px;
  background-repeat: no-repeat;
  position: relative;

 .item-left-1,
 .item-left-2,
 .item-left-3, 
 .item-left-4,
 .item-left-5,
 .item-left-6,
 .item-right-1,
 .item-right-2,
 .item-right-3, 
 .item-right-4,
 .item-right-5 {
    position: absolute;
    display: flex;
    align-items: baseline;
    justify-content: center;
    // width: 84px;
    // background-color: green;
    background-repeat: no-repeat;
    display: flex;
    align-items: flex-end;
    cursor: pointer;

    .txt-container {
      margin-bottom: 5px;
    }
    .num {
      height: 19px;
      font-family: DINPro, DINPro;
      font-weight: 500;
      font-size: 15px;
      color: #FFFFFF;
      line-height: 19px;
      text-align: left;
      font-style: normal;
      text-transform: none;
    }
    .unit {
      height: 11px;
      font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
      font-weight: 400;
      font-size: 9px;
      color: #CAFBFF;
      line-height: 10px;
      text-align: left;
      font-style: normal;
      text-transform: none;
    }
  }

  .item-left-1 {
    left: 186px;
    top: 16px;
    background-image: url('~@/assets/image/cockpit/left-1.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
  .item-left-2 {
    left: 338px;
    top: 16px;
    background-image: url('~@/assets/image/cockpit/left-2.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
 .item-left-3 {
    left: -42px;
    top: 182px;
    background-image: url('~@/assets/image/cockpit/left-3.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
 .item-left-4 {
    left: 80px;
    top: 182px;
    background-image: url('~@/assets/image/cockpit/left-4.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
 .item-left-5 {
    left: 200px;
    top: 182px;
    background-image: url('~@/assets/image/cockpit/left-5.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
 .item-left-6 {
    left: 333px;
    top: 182px;
    background-image: url('~@/assets/image/cockpit/left-6.png');
    background-size: 93px 96px;
    width: 114px;
    height: 96px;
  }

  .item-right-1 {
    left: 698px;
    top: 16px;
    background-image: url('~@/assets/image/cockpit/right-1.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
  .item-right-2 {
    left: 860px;
    top: 16px;
    background-image: url('~@/assets/image/cockpit/right-2.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
 .item-right-3 {
    left: 710px;
    top: 182px;
    background-image: url('~@/assets/image/cockpit/right-3.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
 .item-right-4 {
    left: 859px;
    top: 182px;
    background-image: url('~@/assets/image/cockpit/right-4.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
 .item-right-5 {
    left: 1014px;
    top: 182px;
    background-image: url('~@/assets/image/cockpit/right-5.png');
    background-size: 93px 96px;
    width: 93px;
    height: 96px;
  }
}
</style>