export function getPieChartOption(data) {
  const option = {
    title: [    
      {
          text: data[0].rate + '%',
          subtext: data[0].length + '公里',
          textStyle:{
              fontSize: 20,
              color:"#2AFFFF"
          },
          subtextStyle: {
              fontSize: 16,
              color: '#2AFFFF'
          },
          textAlign:"center",
          x: '47%',
          y: '30%',
          zlevel: 10,
      }
    ],
    series: [
      {
        type: 'pie',
        radius: ['75%', '100%'],
        center: ['50%', '50%'],
        data: [
          {
            value: data[0].rate, // 使用 length 作为饼图的值
            itemStyle: {
              color: '#1AC9FF'
            }
          },
          {
            value: 100 - data[0].rate, // 剩余部分的值,
            itemStyle: {
                color: "transparent"
            }
          }
        ],
        emphasis: {
          scale: false,
          label: {
            show: false,
          }
        },
        label: {
          show: false,
          position: 'center',
        },
      },
      {
        type: 'pie',
        radius: ['80%', '90%'],
        center: ['50%', '50%'],
        data: [
            {
                value: data[0].rate,
                label:{
                  show: false
                },
                itemStyle: {
                    color: "transparent"
                }
            },
            {
                value: 100-data[0].rate,
                itemStyle: {
                    color: '#083861',
                    shadowColor: 'rgba(26, 201, 255, 0.3)',
                    shadowBlur: 5,
                },
                label: {
                    show: false,
                },
            }
        ],
        emphasis: {
          scale: false,
          label: {
            show: false,
          }
        },
        label: {
          show: false,
          position: 'center',
        },
      }
    ],
    
  };

  return option;
}
