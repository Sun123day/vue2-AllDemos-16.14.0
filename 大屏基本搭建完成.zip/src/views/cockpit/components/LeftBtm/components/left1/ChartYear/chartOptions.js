export function getBarChartOption(data) {

  // 横轴数据
  const xAxis = data.map(item => item.name)
  // 系列 1 数据 (类目1)
  const seriesData = data.map(item => item.length)
  const max = Math.max(...seriesData) + 10
  // 构造柱最大值数组
  const maxList = []
  for (let i = 0; i < data.length; i += 1) {
      maxList.push(max)
  }

  const option = {
    tooltip: {
      trigger: 'axis',
      
  formatter: function (params) {
    let res = '';
    params.forEach(function (item) {
    //   console.log(item);
      res += item.name + ' : ' + item.data.length + ' (' + item.data.rate + '%)';
    });
    return res;
  },
       // 显示名称、值和百分比
      axisPointer: { // 坐标轴指示器，坐标轴触发有效
          type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    color: ['#15477B', '#3FF5E6', '#FFCC54'],

    series: [
        {
            // 该系列为背景深蓝色半胶囊
            data: maxList,
            type: 'bar',
            xAxisIndex: 0,
            silent: true,
            barWidth: 30,
            tooltip: {
                show: false,
            },
        },
        {
            // name: '类目1',
            data: data,
            type: 'bar',
            xAxisIndex: 1,
            itemStyle: {
                color: {
                    type: 'linear',
                    x: 0,
                    y: 0,
                    x2: 0,
                    y2: 1,
                    colorStops: [{
                        offset: 0,
                        color: '#1EF8F3', // 0% 处的颜色
                    }, {
                        offset: 0.25,
                        color: '#67F9F6',
                    }, {
                        offset: 0.5,
                        color: '#A8F6F4',
                    }, {
                        offset: 0.75,
                        color: '#D1FAF9',
                    }, {
                        offset: 1,
                        color: '#E0F8F7', // 100% 处的颜色
                    }],
                },
            },
            barWidth: 10,
        },
        
    ],
    dataZoom: {
        type: 'inside',
        xAxisIndex: [0, 1],
    },
    xAxis: [{
            data: maxList,
            axisLine: {
                show: false,
            },
            axisLabel: {
                show: false,
            },
            axisTick: {
                show: false,
            },
            position: 'bottom',
        },
        {
            data: xAxis,
            axisLine: {
                show: false,
            },
            axisLabel: {
                color: '#fff',
            },
            axisTick: {
                show: false,
            },
            position: 'bottom',
        },
    ],
    yAxis: {
        axisLine: {
            show: false,
        },
        axisLabel: {
            show: false,
        },
        axisTick: {
            show: false,
        },
        splitLine: {
            show: false,
        },
    },
    
  };

  return option;
}
