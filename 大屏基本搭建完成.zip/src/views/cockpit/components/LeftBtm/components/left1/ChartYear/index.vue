<template>
  <div ref="pieEchartRes" style="width: 400px; height: 400px"></div>
</template>

<script>
import { getBarChartOption } from './chartOptions'
import * as echarts from 'echarts'

export default {
  props: {
    tableData: {
      type: Array
    }
  },
  data() {
    return {
      mycharts: null,
      // tableData: [
      //   {name: '10年以下', length: 900, rate: 90},
      //   {name: '10~19', length: 50, rate: 5},
      //   {name: '20~29', length: 30, rate: 3},
      //   {name: '30年以上', length: 20, rate: 2},
      // ]
    }
  },
  mounted() {
    this.initEcharts()
  },
  watch: {
    tableData: {
      handler() {
        this.refreshChart()
      },
      deep: true
    }
  },
  beforeDestroy() {
    if (this.mycharts) {
      this.mycharts.dispose()
      this.mycharts = null
    }
  },
  methods: {
    initEcharts() {
      this.mycharts = echarts.init(this.$refs.pieEchartRes)
      window.addEventListener('resize', this.autoResize)
      this.autoResize()
      this.refreshChart()
    },
    autoResize() {
      if (this.mycharts) {
        this.mycharts.resize()
      }
    },
    refreshChart() {
      if (!this.mycharts || !this.tableData) {
        return
      }
      const option = getBarChartOption(this.tableData)
      this.mycharts.setOption(option)
    },
    setHighLight(dataIndex = 0) {
      this.mycharts.dispatchAction({
        type: 'highlight',
        seriesIndex: 0,
        dataIndex
      })
    }
  }
}
</script>