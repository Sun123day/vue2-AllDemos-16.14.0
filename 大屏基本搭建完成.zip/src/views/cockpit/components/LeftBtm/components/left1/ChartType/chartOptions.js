export function getPieChartOption(data) {
  const color = [
    '#2AA8FF',
    '#04CDFF',
    '#9BE3FF',
    '#9BE3FF',
    '#FFD012'
  ];

  // 计算 length 的总和
  const totalLength = data.reduce((sum, item) => sum + item.length, 0);
  
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{b}: {c} ({d}%)', // 显示名称、值和百分比
    },
    title: [    
      {
          // text: 100086.11,
          // text: 0,
          text: totalLength,
          subtext: '公里',
          textStyle:{
              fontSize: 20,
              color:"#2AFFFF"
          },
          subtextStyle: {
              fontSize: 16,
              color: '#2AFFFF'
          },
          textAlign:"center",
          x: '47%',
          y: '40%',
          zlevel: 10,
      }
      
    ],
    series: [
      {
        type: 'pie',
        radius: ['85%', '100%'],
        center: ['50%', '50%'],
        data: data.map((item, index) => ({
          name: item.name,
          value: item.length, // 使用 length 作为饼图的值
          rate: item.rate, // 保持原有的 rate
          itemStyle: {
            color: color[index % color.length]
          }
        })),      
        itemStyle: {
          // borderRadius: 2,
          borderColor: '#0472a3',
          borderWidth: 1,
          shadowColor: 'rgba(142, 152, 241, 0.6)',
          shadowBlur: 5,
        },
        padAngle: 4,
        emphasis: {
          scale: false,
          label: {
            show: false,
          }
        },
        label: {
          show: false,
          position: 'center',
        },
      },
      {
        radius: ['0', '70%'],
        center: ['50%', '50%'],
        type: 'pie',
        z: 10,
        color: '#0e3264',
        label: {
          show: false,
        },
        labelLine: {
          show: false,
        },
        emphasis: {
          show: false,
          scale: false
        },
        animation: false,
        tooltip: {
          show: false,
        },
        data: [{ value: 1 }],
      },
      {
        type: 'pie',
        zlevel: 3,
        silent: true,
        radius: ['77%', '78%'],
        label: {
            normal: {
                show: false
            },
        },
        labelLine: {
            normal: {
                show: false
            }
        },
        data: _pie3(),
      }, 
    ],
    
  };

  return option;
}

export function _pie3() {
  let dataArr = [];
  for (var i = 0; i < 150; i++) {
      if (i % 2 === 0) {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 25,
              value: 10,
              itemStyle: {
                  normal: {
                      color: "rgb(126,190,255)",
                      borderWidth: 0,
                      borderColor: "rgba(0,0,0,0)"
                  }
              }
          })
      } else {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 20,
              value: 10,
              itemStyle: {
                  normal: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0,
                      borderColor: "rgba(0,0,0,0)"
                  }
              }
          })
      }

  }
  return dataArr
}