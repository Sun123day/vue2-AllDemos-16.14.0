<!-- 管线 -->
<template>
  <div style="display: flex; align-items: center; justify-content: center; height: 100%;">
    <div class="content">
        <div class="box">
            <div class="box-header">管线类型</div>
            <div class="box-container" style="display: flex; justify-content: space-between;">
                <ChartType
                    :tableData="computedTypeList"
                />
                <div class="type-container">
                    <div class="type-item">
                        <div class="type-color" style="background-color: #2AA8FF;"/>
                        <div class="type-row">
                            <div class="type-txt">高压管线</div>
                            <div class="type-num">{{ computedTypeLength1 }}公里</div>
                        </div>
                    </div>
                    <div class="type-item">
                        <div class="type-color" style="background-color: #04CDFF;"/>
                        <div class="type-row">
                            <div class="type-txt">次高压管线</div>
                            <div class="type-num">{{ computedTypeLength2 }}公里</div>
                        </div>
                    </div>
                    <div class="type-item">
                        <div class="type-color" style="background-color: #9BE3FF;"/>
                        <div class="type-row">
                            <div class="type-txt">中压管线A</div>
                            <div class="type-num">{{ computedTypeLength3 }}公里</div>
                        </div>
                    </div>
                    <div class="type-item">
                        <div class="type-color" style="background-color: #01EAEA;"/>
                        <div class="type-row">
                            <div class="type-txt">中压管线B</div>
                            <div class="type-num">{{ computedTypeLength4 }}公里</div>
                        </div>
                    </div>
                    <div class="type-item">
                        <div class="type-color" style="background-color: #FFD012;"/>
                        <div class="type-row">
                            <div class="type-txt">低压管线</div>
                            <div class="type-num">{{ computedTypeLength5 }}公里</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="box-header">管线年限</div>
            <div class="box-container" style="display: flex; flex-direction: column;">
                <div class="year-title-container">
                    <span @click="selectButton(0)"  v-if="selectedIndex !== 0" class="year-btn-normal">高压管线</span>
                    <span v-if="selectedIndex == 0" class="year-btn-clcik">高压管线</span>
                    <span @click="selectButton(1)" v-if="selectedIndex !== 1" class="year-btn-normal">次高压管线</span>
                    <span v-if="selectedIndex == 1" class="year-btn-clcik">次高压管线</span>
                    <span @click="selectButton(2)" v-if="selectedIndex !== 2" class="year-btn-normal">中压管线A</span>
                    <span v-if="selectedIndex == 2" class="year-btn-clcik">中压管线A</span>
                    <span @click="selectButton(3)" v-if="selectedIndex !== 3" class="year-btn-normal">中压管线B</span>
                    <span v-if="selectedIndex == 3" class="year-btn-clcik">中压管线B</span>
                    <span @click="selectButton(4)" v-if="selectedIndex !== 4" class="year-btn-normal">低压管线</span>
                    <span v-if="selectedIndex == 4" class="year-btn-clcik">低压管线</span>
                </div>
                <div class="year-txt">
                    年限分布
                </div>
                <div class="year-chart">
                    <ChartYear
                        :tableData="computedYearList"
                    />
                </div>
            </div>
        </div>
        <div class="box">
            <div class="box-header">管线材质</div>
            <div class="box-container" style="display: flex; justify-content: space-between;">
                <div class="material-chart-container">
                    <ChartMaterial1
                        :tableData="computedMaterialList1"
                    />
                    <div class="material-chart-title">铸铁管</div>
                </div>
                <div class="material-chart-container">
                    <ChartMaterial2
                        :tableData="computedMaterialList2"
                    />
                    <div class="material-chart-title">钢质管</div>
                </div>
                <div class="material-chart-container">
                    <ChartMaterial3
                        :tableData="computedMaterialList3"
                    />
                    <div class="material-chart-title">PE管</div>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
import ChartType from './ChartType/index.vue'
import ChartYear from './ChartYear/index.vue'
import ChartMaterial1 from './ChartMaterial1/index.vue'
import ChartMaterial2 from './ChartMaterial2/index.vue'
import ChartMaterial3 from './ChartMaterial3/index.vue'

import { getPipelineType, getPipelineLife, getPipelineMaterial } from '@/api/cockpitNew'
export default {
    components: {
        ChartType,
        ChartYear,
        ChartMaterial1,
        ChartMaterial2,
        ChartMaterial3,
    },  
    data() {
        return {
            // 默认选中的按钮索引
            selectedIndex: 0,
            typeList: [],
            yearList: [],
            materialList: [],
        };
    },
    created(){
        this.initSetModal()
        this.getAllCharts()
    },
    computed: {
        // 类型
        computedTypeList(){
            if(!this.typeList || this.typeList.length === 0){
                // console.log("进入了");
                return [
                    { name: '高压管线', length: 0, rate: 0 },
                    { name: '次高压管线', length: 0, rate: 0 },
                    { name: '中压管线A', length: 0, rate: 0 },
                    { name: '中压管线B', length: 0, rate: 0 },
                    { name: '低压管线', length: 0, rate: 0 },
                ]
            }
            else {
                // console.log("进入了2");
                return this.typeList
            }
        },
        computedTypeLength1() {
            const item = this.computedTypeList.filter(item => item.name === '高压管线')
            return item[0]?.length || 0
        },
        computedTypeLength2() {
            const item = this.computedTypeList.filter(item => item.name === '次高压管线')
            return item[0]?.length || 0
        },
        computedTypeLength3() {
            const item = this.computedTypeList.filter(item => item.name === '中压管线A')
            return item[0]?.length || 0
        },
        computedTypeLength4() {
            const item = this.computedTypeList.filter(item => item.name === '中压管线B')
            return item[0]?.length || 0
        },
        computedTypeLength5() {
            const item = this.computedTypeList.filter(item => item.name === '低压管线')
            return item[0]?.length || 0
        },

        // 年限
        computedYearList(){
            if(!this.yearList || this.yearList.length === 0){
                // console.log("进入了");
                return [
                    { name: '10年以下', length: 0, rate: 0 },
                    { name: '10~19', length: 0, rate: 0 },
                    { name: '20~29', length: 0, rate: 0 },
                    { name: '30年以上', length: 0, rate: 0 },
                ]
            }
            else {
                // console.log("进入了2");
                return this.yearList
            }
        },

        //材质 
        computedMaterialList(){
            if(!this.materialList || this.materialList.length === 0){
                // console.log("进入了");
                return [
                    { name: '铸铁管', length: 0, rate: 0 },
                    { name: '钢质管', length: 0, rate: 0 },
                    { name: 'PE管', length: 0, rate: 0 },
                ]
            }
            else {
                // console.log("进入了2");
                return this.materialList
            }
        },
        computedMaterialList1() {
            const item = this.computedMaterialList.filter(item => item.name === '铸铁管')
            return item
        },
        computedMaterialList2() {
            const item = this.computedMaterialList.filter(item => item.name === '钢质管')
            return item
        },
        computedMaterialList3() {
            const item = this.computedMaterialList.filter(item => item.name === 'PE管')
            return item
        },
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "管线详情");
            this.$emit("SetPageWidth", 1400);
        },
        // 切换选中的按钮
        selectButton(index) {
            this.selectedIndex = index;
            // console.log("触发了按钮", index);
            this.getChartYear()
        },
        getAllCharts(){
            this.getChartType()
            this.getChartYear()
            this.getChartMaterials()
        },
        getChartType(){
            getPipelineType().then(res=>{
                if(res.code == 200){
                    this.typeList = res.data
                }
            })
        },
        getChartYear(){
            getPipelineLife(this.selectedIndex).then(res=>{
                if(res.code == 200){
                    this.yearList = res.data
                }
            })
        },
        getChartMaterials(){
            getPipelineMaterial().then(res=>{
                if(res.code == 200){
                    this.materialList = res.data
                }
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.content {
    display: flex;
    align-items: center;
    gap: 14px;
    margin: 0 30px;
}
.box {
    background-color: #082553;
    width: 434px;
    height: 618px;
    display: flex;
    flex-direction: column;

    .box-header {
        height: 20px;
        font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
        font-weight: bold;
        font-size: 16px;
        color: #FFFFFF;
        line-height: 20px;
        text-align: center;
        font-style: normal;
        text-transform: none;
        margin: 16px 0;
    }
    .box-container {
        flex: 1;
        // width: 434px;
        display: flex;
        // flex-direction: column;
        align-items: center;
        margin: 0 14px;
    }
}
.type-container {
    height: 180px; 
    display: flex;
    flex-direction: column;
    gap: 12px;
    justify-content: center;
    
    .type-item {
        display: flex;
        align-items: center;

        .type-color {
            width: 14px;
            height: 3px;
            margin-right: 8px;
        }
        .type-row {
            flex: 1;
            width: 160px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            
            .type-txt, .type-num {
                height: 20px;
                font-family: PingFang SC, PingFang SC;
                font-weight: 300;
                font-size: 13px;
                color: #FFFFFF;
                line-height: 20px;
                text-align: left;
                font-style: normal;
                text-transform: none;
            }
            .type-num {
                text-align: left;
            }
        }
    }
}
.year-title-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    margin-bottom: 20px;

    .year-btn-clcik {
        background: rgba(3, 28, 55, 0.3);
        box-shadow: inset 0px 0px 11px 0px #46ACFF;
        border-image: linear-gradient(180deg, rgba(0, 170, 249, 1), rgba(42, 255, 255, 1)) 1; /* 使用渐变边框 */
        padding: 5px 6px;
        cursor: pointer;
        border-radius: 4px;
        color: #fff;
    }

    .year-btn-normal {
        padding: 5px 6px;
        cursor: pointer;
        border-radius: 4px;
        color: #fff;
    }
}
.year-txt {
    height: 20px;
    font-family: PingFang SC, PingFang SC;
    font-weight: bold;
    font-size: 13px;
    color: #FFFFFF;
    line-height: 20px;
    text-align: left;
    font-style: normal;
    text-transform: none;
    display: flex;
    justify-content: flex-start;
    width: 100%;
}
.year-chart {
    width: 100%;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
}
.material-chart-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
}
</style>