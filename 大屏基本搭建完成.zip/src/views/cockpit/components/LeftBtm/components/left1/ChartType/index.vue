<template>
  <div ref="pieEchartRes" style="width: 180px; height: 180px"></div>
</template>

<script>
import { getPieChartOption } from './chartOptions'
import * as echarts from 'echarts'

export default {
  props: {
    tableData: {
      type: Array
    }
  },
  data() {
    return {
      mycharts: null,
      // tableData: [
      //   {name: '高压管线', length: 400, rate: 50},
      //   {name: '次高压管线', length: 300, rate: 30},
      //   {name: '中压管线A', length: 200, rate: 20},
      //   {name: '中压管线B', length: 50, rate: 5},
      //   {name: '低压管线', length: 50, rate: 5},
      // ]
    }
  },
  mounted() {
    this.initEcharts()
  },
  watch: {
    tableData: {
      handler() {
        this.refreshChart()
      },
      deep: true
    }
  },
  beforeDestroy() {
    if (this.mycharts) {
      this.mycharts.dispose()
      this.mycharts = null
    }
  },
  methods: {
    initEcharts() {
      this.mycharts = echarts.init(this.$refs.pieEchartRes)
      window.addEventListener('resize', this.autoResize)
      this.autoResize()
      this.refreshChart()
    },
    autoResize() {
      if (this.mycharts) {
        this.mycharts.resize()
      }
    },
    refreshChart() {
      if (!this.mycharts || !this.tableData) {
        return
      }
      const option = getPieChartOption(this.tableData)
      this.mycharts.setOption(option)
    },
    setHighLight(dataIndex = 0) {
      this.mycharts.dispatchAction({
        type: 'highlight',
        seriesIndex: 0,
        dataIndex
      })
    }
  }
}
</script>