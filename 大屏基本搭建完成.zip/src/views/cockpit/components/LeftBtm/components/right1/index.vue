<!-- 相邻空间 -->
<template>
  <div class="content">
    <div class="header">
        <div style="display: flex;">
          <div class="alarmType">
              <span class="alarmTxt">类别</span>
              <el-select
                  v-model="category"
                  :clearable="false"
                  filterable
                  placeholder="请选择"
                  transfer
                  style="width:160px; margin-left: 6px;"
                  @change = "handleChangeCategory"
              >
                  <el-option
                      v-for="item in categoryList"
                      :key="item.code"
                      :value="item.code"
                      :label="item.name"
                  />
              </el-select>
          </div>
          <div class="alarmType" style="margin-left: 16px;">
              <span class="alarmTxt">相邻空间名称</span>
              <el-select
                  v-model="id"
                  :clearable="false"
                  filterable
                  placeholder="请选择"
                  transfer
                  style="width:160px; margin-left: 6px;"
              >
                  <el-option
                      v-for="item in nameList"
                      :key="item.id"
                      :value="item.id"
                      :label="item.name"
                  />
              </el-select>
          </div>
        </div>
        <div style="display: flex; margin-left: 25px !important;">
            <img class="btn" src="~@/assets/image/cockpit/search-btn.png" alt="" @click="handleSearch">
            <img class="btn" src="~@/assets/image/cockpit/reset-btn.png" alt="" @click="handleReset">
        </div>
    </div>
    <div class="addr">地址：{{ computedAddress }}</div>
    <div class="content-main">
      <RlTable
          :is-pagination="true"
          @on-change="loadTbaleData"
          :search="false"
          ref="rltable"
      >
        <template #default>
          <el-table-column type="index" label="序号" width="80" />
          <el-table-column prop="alarmLevel" label="类别" />
          <el-table-column prop="spaceName" label="名称" />
          <el-table-column prop="currentGas" label="可燃气体浓度(%VOL)" width="180"/>
          <el-table-column prop="alarmLevel" label="报警级别" />
          <el-table-column prop="collectTime" label="采集时间" />
        </template>
      </RlTable>
    </div>
  </div>
</template>
  
<script>
import { getSpaceCollectName, getSpaceCollectPageList } from '@/api/cockpitNew'
export default {
    data() {
      return {
        // list: [
        //   { pressure: 100, temperature: 10, flow: 10, time: "2023-07-01 10:00:00" },
        //   { pressure: 200, temperature: 20, flow: 20, time: "2023-07-01 10:00:00" },
        //   { pressure: 300, temperature: 30, flow: 30, time: "2023-07-01 10:00:00" },
        //   { pressure: 400, temperature: 40, flow: 40, time: "2023-07-01 10:00:00" },
        // ],
        category: null,
        categoryList:[
          { code: 0, name: '雨水井' },
          { code: 1, name: '污水井' },
          { code: 2, name: '电力井' },
          { code: 3, name: '通信井' },
        ],
        id: null,
        nameList:[],
      }  
    },
    created(){
        this.initSetModal()
    },
    computed:{
      computedAddress(){
        if(!this.nameList ||this.nameList.length == 0) {
          return '-'
        }
        else {
          return this.nameList.find(item => item.id === this.id)?.address || '-';
        }
      }
    },
    methods:{
        handleChangeCategory() {
            this.id = null
            this.nameList = []
            getSpaceCollectName(this.category).then(res => {
                if(res.code == '200') {
                    this.nameList = res.data || []
                }
            })
        },
        initSetModal() {
            this.$emit("SetTitle", "相邻空间详情");
            this.$emit("SetPageWidth", 950);
        },
        loadTbaleData({resolve,params}){
          // resolve({
          //             records:this.list,
          //             total:this.list.length
          //         })
          params.condition = this.id
          getSpaceCollectPageList(params).then((res) => {
              if(res.code=='200'){
                  const resData=res.data||{}
                  resolve({
                      records:resData.records||[],
                      total:resData.total
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
        handleSearch() {
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        handleReset() {
          this.category = null
          this.id = null
          this.handleSearch()
        },
    }
}
</script>
  
<style lang="scss" scoped>
::v-deep .el-input__inner {
  border-radius: 0 !important;
  border: 1px solid #4390DE;
  height: 36px !important;
  line-height: 36px !important;
}
::v-deep .el-select .el-input .el-select__caret {
    color: #4390DE !important
}
.content-main {
  height: 600px;
  position: relative;
  box-sizing: border-box;
}
.content {
    margin: 0 60px;
    margin-top: 28px;
}
.header {
    display: flex;
    align-items: center;
    height: 36px;
    margin-bottom: 30px;
}
.alarmType {
    display: flex;
    align-items: center;
    .alarmTxt {
        height: 20px;
        font-family: PingFang SC, PingFang SC;
        font-weight: 500;
        font-size: 14px;
        color: #FFFFFF;
        line-height: 20px;
        text-align: left;
        font-style: normal;
        text-transform: none;
    }
}
.btn {
  width: 67px;
  height: 36px;
  margin-left: 12px;
}
.addr {
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 500;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  margin-bottom: 10px;
}
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
</style>