<script>
import TableTwoMergeOdd from '../tableTwoMergeOdd.vue';
export default {
    components:{
      TableTwoMergeOdd,
    },
    props: {
      rowData: {
        type: Object,
      }
    },
    data() {
        return {
          list1: [
              // {key: '住户联系人', value: 'xxx'},
              // {key: '住户电话', value: 'xxx'},
              // {key: '隐患地址', value: 'xxx'},
              // {key: '隐患详情', value: 'xxx'},
              // {key: '隐患级别', value: 'xxx'},
              // {key: '隐患状态', value: 'xxx'},
              // {key: '隐患来源', value: 'xxx'},
              // {key: '整改时间', value: 'xxx'},
              // {key: '排查人员', value: 'xxx'},
              // {key: '发现时间', value: 'xxx'},
              // {key: '整改人员', value: 'xxx'},
              // {key: '整改人联系方式', value: 'xxx'},
              // {key: '隐患图片', value: '图片路径'},
          ],
          name: this.$props.rowData?.name || '-', // 住户联系人
          phone: this.$props.rowData?.phone || '-', // 住户电话
          address: this.$props.rowData?.address || '-', // 隐患地址
          detail: this.$props.rowData?.detail || '-', // 隐患详情
          level: this.$props.rowData?.level || '-', // 隐患级别
          status: this.$props.rowData?.status || '-', // 隐患状态
          origin: this.$props.rowData?.origin || '-', // 隐患来源
          correctTime: this.$props.rowData?.correctTime || '-', // 整改时间
          checkPersonName: this.$props.rowData?.checkPersonName || '-', // 排查人员
          checkTime: this.$props.rowData?.checkTime || '-', // 发现时间
          correctPersonName: this.$props.rowData?.correctPersonName || '-', // 整改人员
          correctPersonTel: this.$props.rowData?.correctPersonTel || '-', // 整改人联系方式
          imgUrl: this.$props.rowData?.imgUrl || '-', // 隐患图片
        }
    },
    created(){
        this.initSetModal()
    },
    computed:{
      computedList1(){
        return [
          {key: '住户联系人', value: this.name},
          {key: '住户电话', value: this.phone},
          {key: '隐患地址', value: this.address},
          {key: '隐患详情', value: this.detail},
          {key: '隐患级别', value: this.computedLevel},
          {key: '隐患状态', value: this.computedStatus},
          {key: '隐患来源', value: this.origin},
          {key: '整改时间', value: this.correctTime},
          {key: '排查人员', value: this.checkPersonName},
          {key: '发现时间', value: this.checkTime},
          {key: '整改人员', value: this.correctPersonName},
          {key: '整改人联系方式', value: this.correctPersonTel},
          {key: '隐患图片', value: this.imgUrl},
        ];
      },
      computedLevel(){
        switch(this.level){
          case 1:
            return '一级';
          case 2:
            return '二级';
          case 3:
            return '三级';
        }
      },
      computedStatus(){
        switch(this.status){
          case 1:
            return '未排查';
          case 2:
            return '已排查';
        }
      },
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "管线包裹占压内部详情");
            this.$emit("SetPageWidth", 800);
        },
    }
}
</script>
<template>
    <div class="content">
      <div>
        <div class="table1">
          <TableTwoMergeOdd
            :tableData="computedList1" 
            :tableStyle="{width: '100%'}"
          />
        </div>
      </div>
    </div>
</template>

<style lang="scss" scoped>
.content {
  margin-top: 28px;
  // height: 600px;
  position: relative;
  box-sizing: border-box;
}
.table1 {
  // height: 260px;
  margin: 0 38px;
  margin-bottom: 15px;
  margin-top: 10px;
}
</style>