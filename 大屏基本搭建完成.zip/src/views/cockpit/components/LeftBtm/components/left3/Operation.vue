<template>
    <Space>
        <el-tooltip class="item" effect="light" content="定位" placement="bottom-start">
            <img
                src="~@/assets/image/cockpit/grid_detail_op_btn.png"
                style="width: 13.4px; height: 13.4px;"
                @click="onDeleteClick"
            />
        </el-tooltip>
    </Space>
</template>
<script>
    // import { deleteLineInfo } from '@/api/proLineManage'
    export default {
        name: 'Operation',
        props: {
            rowData: {
                type: Object,
                default: () => {
                    return {}
                },
            },
        },
        inject: ['tableRoot'],
        methods: {
            onDeleteClick() {
                // this.$confirm('您确认要删除数据嘛？', '提示', {
                //     confirmButtonText: '确定',
                //     cancelButtonText: '取消',
                //     distinguishCancelAndClose: true,
                //     type: 'warning',
                // }).then(() => {
                //     deleteLineInfo(this.rowData.id).then((result) => {
                //         if (result.code == 200) {
                //             this.$message.success(result.msg)
                //             this.tableRoot.onSearchChange()
                //         }
                //     })
                // })
            },
        },
    }
</script>
