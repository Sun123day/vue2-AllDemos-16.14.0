<template>
  <div>
      <div class="sub-title-container">
          <span class="title">停气通知</span>
          <img class="btn" src="~@/assets/image/cockpit/more-btn.png" alt="" @click="handleMoreClick">
      </div>
      <div class="table">
        <!-- <div class="item" v-for="(item, index) in list" :key="index">
          <div class="item-title">【停气通知】</div>
          <div class="item-info" v-if="item.infoItem.length > 30">
            <el-tooltip placement="top">
              <div slot="content" class="tooltip-content">{{ item.infoItem }}</div>
              <div>{{ item.infoItem.substring(0, 26) + '...' }}</div>
            </el-tooltip>
          </div>
          <div class="item-info" v-else>{{ item.infoItem }}</div>
          <div class="item-time">{{ item.time }}</div>
        </div> -->
        <el-carousel
          v-if="list && list.length > 0"
          :autoplay="true" 
          :interval="3500" 
          direction="horizontal" 
          height="187px"
        >
          <el-carousel-item v-for="(group, index) in groupedList" :key="index">
            <div v-for="(item, idx) in group" :key="idx" class="item">
              <!-- <div class="item-title">【停气通知】</div> -->
              <div class="item-title">【{{item.title || '停气通知'}}】</div>
              <div class="item-info" v-if="item.content.length > 29">
                <el-tooltip placement="top">
                  <div slot="content" class="tooltip-content">{{ item.content }}</div>
                  <div>{{ item.content.substring(0, 26) + '...' }}</div>
                </el-tooltip>
              </div>
              <div class="item-info" v-else>{{ item.content }}</div>

              <div class="item-time">{{ item.time }}</div>
            </div>
          </el-carousel-item>
        </el-carousel>
        <div v-else class="list-empty">
          暂无数据
        </div>
      </div>
  </div>
</template>

<script>
import MoreFormModal from './components/MoreFormModal.vue'
import { getStopGasNotice } from '@/api/cockpitNew'

export default {
    components: {
      MoreFormModal,
    },
    data(){
      return {
        list: [
          // {content: '10月8日21:00-10月9日5:00，1xxxxx停气', time: '2024-10-18 11:38:00'},
          // {content: '10月8日21:00-10月9日5:00，2xxxxx停气', time: '2024-10-18 11:38:00'},
          // {content: '10月8日21:00-10月9日5:00，3xxxxx停气', time: '2024-10-18 11:38:00'},
          // {content: '10月8日21:00-10月9日5:00，10xxxxx停气', time: '2024-10-18 11:38:00'},
          // {content: '10月8日21:00-10月9日5:00，100xxxxx停气', time: '2024-10-18 11:38:00'},
        ],
      }
    },
    created(){
      this.getNoticeList()
    },
    computed: {
      // 将 list 数据按 3 条划分为一组
      groupedList() {
        const groups = [];
        for (let i = 0; i < this.list.length; i += 3) {
          groups.push(this.list.slice(i, i + 3));
        }
        return groups;
      },
    },
    // mounted() {
    //   // 设置定时器，每10秒调用一次
    //   this.intervalId = setInterval(() => {
    //     this.getNoticeList();
    //   }, 10000); // 10000毫秒 = 10秒
    // },
    // beforeDestroy() {
    //   // 清理定时器
    //   if (this.intervalId) {
    //     clearInterval(this.intervalId);
    //   }
    // },
    methods: {
        getNoticeList(){
          getStopGasNotice().then(res => {
            if(res.code == 200){
              this.list = res.data || []
            }
          })
        },
        handleMoreClick() {
          new this.$pageModal(
              MoreFormModal,
              {
                  props: {
                  },
              },
              (result) => {
              }
          )
        }
    },


}
</script>

<style lang="scss" scoped>
.list-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #909399;
  height: 187px;
  line-height: 187px;
  font-size: 12px;
  background-color: #0c2e55;
}
::v-deep .el-carousel__indicator--horizontal{
    display: none;
}
::v-deep .el-carousel__arrow--left{
    display: none!important;;
}
::v-deep .el-carousel__arrow--right{
    display: none!important;;
}
.sub-title-container {
    margin-bottom: 16px;
    width: 590px;
    height: 30px;
    background-image: url('~@/assets/image/cockpit/sub-title-container.png');
    background-size: 590px 30px;
    background-repeat: no-repeat;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .title {
      height: 26px;
      font-family: YouSheBiaoTiHei, YouSheBiaoTiHei;
      font-weight: 400;
      font-size: 19px;
      color: #CFEAFF;
      line-height: 0;
      letter-spacing: 1px;
      text-align: left;
      font-style: normal;
      text-transform: none;
      padding-left: 43px;
    }
    .btn {
      width: 67px;
      height: 30px;
    }
}
.table {
  width: 590px;
  height: 187px;
  display: flex;
  flex-direction: column;
  gap: 14px;
  overflow: hidden;
}
.item {
  width: 559px;
  height: 20px;
  background-image: url('~@/assets/image/cockpit/info-item.png');
  background-size: 590px 53px;
  background-repeat: no-repeat;
  padding: 17px 14px 16px 17px;
  display: flex;
  align-items: center;
  margin-bottom: 14px;
}
.item-title {
  width: 92px;
  height: 20px;
  font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
  font-weight: bold;
  font-size: 14px;
  color: #FF0000;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
.item-info {
  width: 262px;
  margin-left: 22px;
  // width: 243px;
  // max-width: 250px;
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
.tooltip-content {
  white-space: normal;
  word-wrap: break-word;
  max-width: 250px;
}
.item-time {
  margin-left: 45px;
  // width: 136px;
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
</style>