<!-- 停气通知更多 -->
<template>
  <div class="content">
    <div class="header">
        <div class="alarmType">
            <span class="alarmTxt">停气时间</span>
            <el-date-picker
                v-model="timeRange"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :editable="false"
                :clearable="false"
                style="width: 280px !important; margin-left: 6px;"
                class="calendar-single"
                :pickerOptions="pickerOptions"
            />
        </div>
        <div style="display: flex; margin-left: 25px !important;">
            <img class="btn" src="~@/assets/image/cockpit/search-btn.png" alt="" @click="handleSearch">
            <img class="btn" src="~@/assets/image/cockpit/reset-btn.png" alt="" @click="handleReset">
        </div>
    </div>
    <div class="content-main">
      <RlTable
          :is-pagination="true"
          @on-change="loadTbaleData"
          :search="false"
          ref="rltable"
      >
        <template #default>
          <el-table-column type="index" label="序号" width="80" />
          <el-table-column prop="id" label="ID" width="120" />
          <el-table-column prop="content" label="描述" />
          <el-table-column prop="time" label="停气时间" width="140" />
        </template>
      </RlTable>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs';
import { getStopGasNoticePageList } from '@/api/cockpitNew'
export default {
    components:{
    },
    data() {
      return {
        // list: [
        //   { txt: '描述12345678', time: "2024-11-18 11:09:12" },
        //   { txt: '描述12345678,101112131415161718192021222324252627282930', time: "2024-11-18 11:09:12" },
        //   { txt: '描述12345678,101112131415161718192021222324252627282930', time: "2024-11-18 11:09:12" },
        //   { txt: '描述12345678,101112131415161718192021222324252627282930', time: "2024-11-18 11:09:12" },
        // ],
        timeRange: [],
        pickerOptions: {
            disabledDate(time) {
                return time.getTime() > new Date().getTime()    //使用这种方法实现
            },
        },
      }  
    },
    created(){
        this.initSetModal()
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "停气通知列表");
            this.$emit("SetPageWidth", 950);
        },
        loadTbaleData({resolve,params}){
          // resolve({
          //             records:this.list,
          //             total:this.list.length
          //         })
          params.condition = {
            start: this.timeRange[0] ? dayjs(this.timeRange[0]).format('YYYY-MM-DD 00:00:00') : '',
            end: this.timeRange[1] ? dayjs(this.timeRange[1]).format('YYYY-MM-DD 23:59:59') : ''
          }
          getStopGasNoticePageList(params).then((res) => {
              if(res.code=='200'){
                  const resData = res.data ||[]
                  resolve({
                      records:resData.records || [],
                      total:resData.total || 0
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
        handleSearch() {
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        handleReset() {
          this.timeRange = []
          this.handleSearch()
        },
    }
}
</script>
  
<style lang="scss" scoped>
.tooltip-content {
  white-space: normal;
  word-wrap: break-word;
  max-width: 500px;
  max-height: 200px;
  overflow-y: scroll;
}
::v-deep .el-input__inner {
  border-radius: 0 !important;
  border: 1px solid #4390DE;
  height: 36px !important;
  line-height: 36px !important;
}
.content-main {
  height: 600px;
  position: relative;
  box-sizing: border-box;
}
.content {
    margin: 0 60px;
    margin-top: 28px;
}
.header {
    display: flex;
    align-items: center;
    height: 36px;
    margin-bottom: 30px;
}
.alarmType {
    display: flex;
    align-items: center;
    .alarmTxt {
        height: 20px;
        font-family: PingFang SC, PingFang SC;
        font-weight: 500;
        font-size: 14px;
        color: #FFFFFF;
        line-height: 20px;
        text-align: left;
        font-style: normal;
        text-transform: none;
    }
}
.btn {
  width: 67px;
  height: 36px;
  margin-left: 12px;
}
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
.calendar-single ::v-deep.el-icon-date:before {
    content: '' !important;
}
.calendar-single ::v-deep.el-input__suffix {
    width: 25px !important;
}
// .calendar-single ::v-deep.el-input__suffix:before {
.calendar-single ::v-deep i:last-child {
    background: url('~@/assets/image/cockpit/calendar.png') center center no-repeat !important;
    background-size: 18px 18px !important;
}
.calendar-single ::v-deep.el-range-separator {
    line-height: 28px !important;
}
</style>