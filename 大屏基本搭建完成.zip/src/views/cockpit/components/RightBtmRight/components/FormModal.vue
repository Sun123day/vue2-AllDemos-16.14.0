<!-- <script>
import { 
    addLineInfo,
    updateLineInfo,
 } from "@/api/proLineManage";
import _ from 'lodash'
import { categoryTreeGet } from '@/api/category.js'
import { findSubitemTreeByEnergyType } from '@/api/common'
import BaseTree from '@/components/BaseTree'
export default {
    components:{ BaseTree },
    props: {
        title: String,
        rowData: Object
    },
    data() {
        return {
            electricityOptions: {
                data: [],
                clickParent: true,
                props: {
                    'node-key': 'id',
                    children: 'children',
                    label: 'name',
                    value: 'id',
                },
            },
            steamOptions: {
                data: [],
                clickParent: true,
                props: {
                    'node-key': 'id',
                    children: 'children',
                    label: 'name',
                    value: 'id',
                },
            },
            compressedairOptions: {
                data: [],
                clickParent: true,
                props: {
                    'node-key': 'id',
                    children: 'children',
                    label: 'name',
                    value: 'id',
                },
            },
            tapwaterOptions: {
                data: [],
                clickParent: true,
                props: {
                    'node-key': 'id',
                    children: 'children',
                    label: 'name',
                    value: 'id',
                },
            },
            purewaterOptions: {
                data: [],
                clickParent: true,
                props: {
                    'node-key': 'id',
                    children: 'children',
                    label: 'name',
                    value: 'id',
                },
            },
            electricityFlag: false,
            steamFlag: false,
            compressedairFlag: false,
            tapwaterFlag: false,
            purewaterFlag: false,

            formData:{
                projectId:this.$store.state.projectId,
                name:this.$props.rowData?.name || null,                
                code:this.$props.rowData?.code || null,
                electricityItem:this.$props.rowData?.electricityItem || null,
                steamItem:this.$props.rowData?.steamItem || null,
                compressedAirItem:this.$props.rowData?.compressedAirItem || null,
                tapWaterItem:this.$props.rowData?.tapWaterItem || null,
                pureWaterItem:this.$props.rowData?.pureWaterItem || null,
            },
            rules:{
                name: [
                    { required: true, message: "请输入产线名称", trigger: "blur" }
                ],
                code: [
                    { required: true, message: "请输入产线标识", trigger: "blur" }
                ],
                electricityItem: [
                    { required: true, message: "请选择电关联分项", trigger: "change" }
                ],
                steamItem: [
                    { required: true, message: "请选择蒸汽关联分项", trigger: "change" }
                ],
                compressedAirItem: [
                    { required: true, message: "请选择压缩空气关联分项", trigger: "change" }
                ],
                tapWaterItem: [
                    { required: true, message: "请选择水关联分项", trigger: "change" }
                ],
                pureWaterItem: [
                    { required: true, message: "请选择纯水关联分项", trigger: "change" }
                ],
            }
        }
    },
    created(){
        this.initSetModal()
        // categoryTreeGet(this.$store.state.projectId).then(res => {
        //     if(res.code == 200){
        //         const data = res.data
        //         this.electricityOptions.data = res.data.filter((item) => item.energyType === 'electricity') || []
        //         this.steamOptions.data = data.filter((item) => item.energyType === 'steam') || []
        //         this.compressedairOptions.data = data.filter((item) => item.energyType === 'compressedair') || []
        //         this.tapwaterOptions.data = data.filter((item) => item.energyType === 'tapwater') || []
        //         this.purewaterOptions.data = data.filter((item) => item.energyType === 'purewater') || []
        //     }
        // })
        
        // this.loadElectricityOptions()
        findSubitemTreeByEnergyType({
            projectId: this.$store.state.projectId,
            energyType: 'electricity'
        }).then(res => {
            if(res.code === 200){
                this.electricityOptions.data = res.data
                this.electricityFlag = true
            }
        })
        findSubitemTreeByEnergyType({
            projectId: this.$store.state.projectId,
            energyType:'steam'
        }).then(res => {
            if(res.code === 200){
                this.steamOptions.data = res.data
                this.steamFlag = true
            }
        })
        findSubitemTreeByEnergyType({
            projectId: this.$store.state.projectId,
            energyType: 'compressedair'
        }).then(res => {
            if(res.code === 200){
                this.compressedairOptions.data = res.data
                this.compressedairFlag = true
            }
        })
        findSubitemTreeByEnergyType({
            projectId: this.$store.state.projectId,
            energyType: 'tapwater'
        }).then(res => {
            if(res.code === 200){
                this.tapwaterOptions.data = res.data
                this.tapwaterFlag = true
            }
        })
        findSubitemTreeByEnergyType({
            projectId: this.$store.state.projectId,
            energyType: 'purewater'
        }).then(res => {
            if(res.code === 200){
                this.purewaterOptions.data = res.data
                this.purewaterFlag = true
            }
        })
    },
    // watch:{
    //     electricityOptions: {
    //         handler(newVal, oldVal) {
    //             console.log("触发了");
    //             //this.electricityOptions = newVal
    //             console.log("this.electricityOptions", this.electricityOptions);
    //             console.log("this.electricityOptions.data", this.electricityOptions.data);
    //         },
    //         deep: true,
    //         // immediate: true
    //     },

    // },
    mounted() {
    // async mounted() {
        // const { data } = await categoryTreeGet(this.$store.state.projectId)
        // this.electricityOptions.data = data.filter((item) => item.energyType === 'electricity') || []
        // this.steamOptions.data = data.filter((item) => item.energyType === 'steam') || []
        // this.compressedairOptions.data = data.filter((item) => item.energyType === 'compressedair') || []
        // this.tapwaterOptions.data = data.filter((item) => item.energyType === 'tapwater') || []
        // this.purewaterOptions.data = data.filter((item) => item.energyType === 'purewater') || []
        
    },
    methods:{
        // async loadElectricityOptions(){
        //     try {
        //         const res = await categoryTreeGet(this.$store.state.projectId);
        //         if (res.code == 200) {
        //             const data = res.data
        //             this.electricityOptions.data = data.filter((item) => item.energyType === 'electricity') || []
        //             this.steamOptions.data = data.filter((item) => item.energyType === 'steam') || []
        //             this.compressedairOptions.data = data.filter((item) => item.energyType === 'compressedair') || []
        //             this.tapwaterOptions.data = data.filter((item) => item.energyType === 'tapwater') || []
        //             this.purewaterOptions.data = data.filter((item) => item.energyType === 'purewater') || []
        //         }
        //     } catch (error) {

        //     }
        // },
        initSetModal() {
            if (this.$props.rowData) {
                this.$emit("SetTitle", "编辑产线");
            } else {
                this.$emit("SetTitle", "新增产线");
            }
            this.$emit("SetPageWidth", 400);
            this.$emit("SetPageActions", [
                {
                    text: "取消",
                    theme: "info",
                    handle: () => {
                        this.$emit("Close");
                    }
                },
                {
                    text: "保存",
                    theme: "primary",
                    handle: () => {
                        this.submitForm();
                    },
                    loading: false
                }
            ]);
        },
        submitForm() {
            this.$refs.ruleForm.validate(valid => {
                if (valid) {
                //验证成功,发送请求
                if (this.$props.rowData) {
                    //编辑更新
                    this.sendUpdateRequestFun();
                } else {
                    //新增
                    this.sendAddRequestFun();
                }
                } else {
                //验证失败
                }
            });
        },
        sendAddRequestFun() {
            addLineInfo({
                ...this.formData
            }).then(result => {
                if (result.code == 200) {
                    this.$message.success(result.msg);
                    this.$emit("Close", true);
                }
            }).catch((err) => {
                this.$message.error(err)
            })
        },
        sendUpdateRequestFun() {
            const params={
                ...this.formData,
                id: this.$props.rowData?.id
            }
                updateLineInfo(params).then(result => {
                if (result.code == 200) {
                    this.$message.success(result.msg);
                    this.$emit("Close", true);
                }
            }).catch((err) => {
                this.$message.error(err)
            })
        },
    }
}
</script>
<template>
    <el-form
        label-position="top" 
        :model="formData"
        :rules="rules"
        ref="ruleForm"
    >
        <el-row :gutter="24">
            <el-col :span="12">
                <el-form-item label="产线名称" prop="name">
                    <el-input
                        placeholder="请输入产线名称"
                        v-model="formData.name"
                        clearable
                    />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="产线标识" prop="code">
                    <el-input
                        placeholder="请输入产线标识"
                        v-model="formData.code"
                        clearable
                    />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="电关联分项" prop="electricityItem">
                    <el-tree-select
                        v-if="electricityFlag"
                        v-model="formData.electricityItem"
                        placeholder="请选择电关联分项"
                        :treeParams="electricityOptions"
                        :select-params="{
                            clearable: false,
                        }"
                        selectClass="customSelectTrees"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="蒸汽关联分项" prop="steamItem">
                    <el-tree-select
                        v-if="steamFlag"
                        v-model="formData.steamItem"
                        placeholder="请选择蒸汽关联分项"
                        :treeParams="steamOptions"
                        :select-params="{
                            clearable: false,
                        }"
                        selectClass="customSelectTrees"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="压缩空气关联分项" prop="compressedAirItem">
                    <el-tree-select
                        v-if="compressedairFlag"
                        v-model="formData.compressedAirItem"
                        placeholder="请选择压缩空气关联分项"
                        :treeParams="compressedairOptions"
                        :select-params="{
                            clearable: false,
                        }"
                        selectClass="customSelectTrees"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="自来水关联分项" prop="tapWaterItem">
                    <el-tree-select
                        v-if="tapwaterFlag"
                        v-model="formData.tapWaterItem"
                        placeholder="请选择自来水关联分项"
                        :treeParams="tapwaterOptions"
                        :select-params="{
                            clearable: false,
                        }"
                        selectClass="customSelectTrees"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="纯水关联分项" prop="pureWaterItem">
                    <el-tree-select
                        v-if="purewaterFlag"
                        v-model="formData.pureWaterItem"
                        placeholder="请选择纯水联分项"
                        :treeParams="purewaterOptions"
                        :select-params="{
                            clearable: false,
                        }"
                        selectClass="customSelectTrees"
                    />
                </el-form-item>
            </el-col>
        </el-row>
    </el-form>
</template>

<style lang="scss" scoped>
    .customSelectTrees {
        display: inline-block;
        margin-left: 0;
        width: 100% !important;
        ::v-deep.el-select {
            width: 100% !important;
        }
    }
</style> -->