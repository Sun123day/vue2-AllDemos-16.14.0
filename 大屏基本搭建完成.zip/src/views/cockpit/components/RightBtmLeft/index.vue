<!-- 费用记录 -->
<template>
  <div class="left-top-left-container">
      <div class="header">
        <BigScreenTab
            :sourceData="tabData"
            v-model="tabType"
            @change="handleChange"
        />
      </div>
      <Post
        v-if="tabType == 'POST'"
        class="table"
      />
      <Info
        v-if="tabType == 'INFO'"
        class="table"
      />
  </div>
</template>

<script>
import BigScreenTab from '@/components/BigScreenTab'
import Post from './post/index.vue'
import Info from './info/index.vue'
const POLICY = 'POST' // 配置选项
export default {
    name: 'customAlarmManage',
    components: {
        BigScreenTab,
        Post,
        Info
    },
    data() {
        return {
            tabType: POLICY,
            tabData: [
                {
                    code: 'POST',
                    text: '应急值守',
                },
                {
                    code: 'INFO',
                    text: '抢险信息',
                },
            ],
        }
    },
    methods: {
        handleChange() {
          console.log(this.tabType);
        }
    },
}
</script>
<style lang="scss" scoped>
.left-top-left-container {
  width: 615px;
  height: 100%;
  // background-color: #fff;
}
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 36px;
  margin-bottom: 7px;

  .txt {
    // width: 48px;
    height: 22px;
    font-family: PingFang SC, PingFang SC;
    font-weight: 400;
    font-size: 16px;
    color: #4390DE;
    line-height: 19px;
    text-align: center;
    font-style: normal;
    text-transform: none;
    .num {
      height: 22px;
      font-family: DINPro, DINPro;
      font-weight: bold;
      font-size: 16px;
      color: #2AFFFF;
      line-height: 19px;
      text-align: center;
      font-style: normal;
      text-transform: none;
    }
  }
}

.table {
  // height: 231px;
  width: 615px;
  position: relative;
}
</style>