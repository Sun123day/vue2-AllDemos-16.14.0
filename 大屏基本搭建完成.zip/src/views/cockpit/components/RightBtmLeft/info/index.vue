<!-- 应急调度指挥-抢险信息 -->
<script>
import ScheduleForm from './ScheduleForm/index.vue'
import CarForm from './CarForm/index.vue'
import PersonForm from './PersonForm/index.vue'
import { getEmergencyInfo } from '@/api/cockpitNew'
export default {
    components:{
      ScheduleForm,
      CarForm,
      PersonForm,
    },
    data(){
        return{
          list: [],
        }
    },
    created(){
      this.getEmergencyInfo()
    },
    // mounted() {
    //   // 设置定时器，每10秒调用一次
    //   this.intervalId = setInterval(() => {
    //     this.getEmergencyInfo();
    //   }, 10000); // 10000毫秒 = 10秒
    // },
    // beforeDestroy() {
    //   // 清理定时器
    //   if (this.intervalId) {
    //     clearInterval(this.intervalId);
    //   }
    // },
    computed:{
      computedList(){
        if(!this.list || this.list.length === 0){
          // console.log("进入了");
          return [
            [0, 0],
            [0, 0],
            [0, 0]
          ]
        }
        else {
          // console.log("进入了2");
          return this.list
        }
      },
      computedTotal1(){
        return this.computedList[0][0] || 0
      },
      computedWorking1(){
        return this.computedList[0][1] || 0
      },
      computedTotal2(){
        return this.computedList[1][0] || 0
      },
      computedWorking2(){
        return this.computedList[1][1] || 0
      },
      computedTotal3(){
        return this.computedList[2][0] || 0
      },
      computedWorking3(){
        return this.computedList[2][1] || 0
      },
    },
    methods:{
        getEmergencyInfo(){
          getEmergencyInfo(this.$store.state.areaId).then((res) => {
            if(res.code=='200'){
              this.list = res.data
            }
          })
        },
        onScheduleClick(){
          new this.$pageModal(
            ScheduleForm,
              {
                  props: {
                  },
              },
              (result) => {
              }
          )
        },
        onCarClick(){
          new this.$pageModal(
            CarForm,
              {
                  props: {
                  },
              },
              (result) => {
              }
          )
        },
        onPersonClick(){
          new this.$pageModal(
            PersonForm,
              {
                  props: {
                  },
              },
              (result) => {
              }
          )
        }
    }
}
</script>
<template>
    <div class="container">
      <div class="header">抢险信息</div>
      <div class="content">
        <div class="item" @click="onScheduleClick">
          <img class="item-img" src="~@/assets/image/cockpit/scheduleNum.png" alt="">
          <div class="item-header">应急排班人员数量</div>
          <div class="item-txt">
            <div class="txt-txt">总数</div>
            <div class="txt-num">{{ computedTotal1 }}</div>
          </div>
          <div class="item-txt">
            <div class="txt-txt">工作中</div>
            <div class="txt-num">{{ computedWorking1 }}</div>
          </div>
        </div>
        <div class="line"></div>
        <div class="item" @click="onCarClick">
          <img class="item-img" src="~@/assets/image/cockpit/carNum.png" alt="">
          <div class="item-header">抢险车辆数量</div>
          <div class="item-txt">
            <div class="txt-txt">总数</div>
            <div class="txt-num">{{ computedTotal2 }}</div>
          </div>
          <div class="item-txt">
            <div class="txt-txt">工作中</div>
            <div class="txt-num">{{ computedWorking2 }}</div>
          </div>
        </div>
        <div class="line"></div>
        <div class="item" @click="onPersonClick">
          <img class="item-img" src="~@/assets/image/cockpit/personNum.png" alt="">
          <div class="item-header">抢险人员数量</div>
          <div class="item-txt">
            <div class="txt-txt">总数</div>
            <div class="txt-num">{{ computedTotal3 }}</div>
          </div>
          <div class="item-txt">
            <div class="txt-txt">工作中</div>
            <div class="txt-num">{{ computedWorking3 }}</div>
          </div>
        </div>
      </div>
    </div>
</template>
<style lang="scss" scoped>
.container {
  width: 100%;
  height: 207px;
  border: 2px solid #4390DE;
}
.header {
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;

  background: linear-gradient(#022549 0%, #14569A 100%);
  border-radius: 0px 0px 0px 0px;
  border-bottom: 1px solid #4390DE;

  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 16px;
  color: #FFFFFF;
  line-height: 19px;
  text-align: center;
  font-style: normal;
  text-transform: none;
}
.content {
  height: 167px;
  display: flex;
  align-items: center;
  justify-content: space-between;

  .line {
    height: 115px;
    border: 1px solid;
    border-image: linear-gradient(90deg, rgba(2, 27, 54, 1), rgba(52, 128, 204, 1), rgba(4, 30, 57, 1)) 1 1;
  }
  .item {
    width: 204px;
    height: 167px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 7px;
    .item-header {
      width: 130px;
      height: 20px;
      font-family: PingFang SC, PingFang SC;
      font-weight: 400;
      font-size: 14px;
      line-height: 20px;
      text-align: center;
      font-style: normal;
      text-transform: none;
      color: #4390DE;
    }
    .item-img {
      width: 57px;
      height: 51px;
      margin-top: 17px;
    }
    .item-txt {
      display: flex;
      justify-content: space-between;
      .txt-txt {
        width: 65px;
        height: 20px;
        font-family: PingFang SC, PingFang SC;
        font-weight: 400;
        font-size: 14px;
        color: #FFFFFF;
        line-height: 16px;
        text-align: left;
        font-style: normal;
        text-transform: none;
      }
      .txt-num {
        width: 65px;
        height: 18px;
        font-family: DINPro, DINPro;
        font-weight: bold;
        font-size: 14px;
        color: #F5A21D;
        line-height: 16px;
        text-align: left;
        font-style: normal;
        text-transform: none;
      }
    }
  }
}
</style>