<!-- 抢险信息-抢险车辆 -->
<template>
  <div class="content">
    <div class="header">
        <div style="display: flex;">
          <div class="alarmType">
              <span class="alarmTxt">车牌号码</span>
              <el-input
                  v-model="tel"
                  placeholder="请输入车牌"
                  size="small"
                  style="width: 140px; margin-left: 6px;"
                  clearable
                  class="searchInput"
              />
          </div>
          <div class="alarmType" style="margin-left: 16px;">
              <span class="alarmTxt">车主名称</span>
              <el-input
                  v-model="name"
                  placeholder="请输入名称"
                  size="small"
                  style="width: 140px; margin-left: 6px;"
                  clearable
                  class="searchInput"
              />
          </div>
        </div>
        <div style="display: flex; margin-left: 25px !important;">
            <img class="btn" src="~@/assets/image/cockpit/search-btn.png" alt="" @click="handleSearch">
            <img class="btn" src="~@/assets/image/cockpit/reset-btn.png" alt="" @click="handleReset">
        </div>
    </div>
    <div class="content-main">
      <RlTable
          :is-pagination="true"
          @on-change="loadTbaleData"
          :search="false"
          ref="rltable"
      >
        <template #default>
          <el-table-column type="index" label="序号" width="80" />
          <el-table-column prop="number" label="车牌号码" />
          <el-table-column prop="name" label="车主名称" />
          <el-table-column prop="phone" label="电话号码" />
          <!-- <el-table-column label="操作" width="100">
              <template slot-scope="scope">
                  <Operation :rowData="scope.row"/>
              </template>
          </el-table-column> -->
        </template>
      </RlTable>
    </div>
  </div>
</template>

<script>
import Operation from './Operation.vue'
import { getEmergencyCarMore } from '@/api/cockpitNew'
export default {
    components:{
      Operation,
    },
    data() {
      return {
        tel: '',
        name: '',
        // list: [
        //   { num: '川A12345', name: '名称1', tel: "151xxxxxxxx" },
        //   { num: '川B12345', name: '名称2', tel: "151xxxxxxxx" },
        //   { num: '川C12345', name: '名称3', tel: "151xxxxxxxx" },
        //   { num: '川D12345', name: '名称4', tel: "151xxxxxxxx" },
        // ]
      }  
    },
    created(){
        this.initSetModal()
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "抢险车辆详情");
            this.$emit("SetPageWidth", 750);
        },
        loadTbaleData({resolve,params}){
          // resolve({
          //             records:this.list,
          //             total:this.list.length
          //         })
          params.condition = {
            areaId: this.$store.state.areaId,
            name: this.name,
            tel: this.tel
          }
          getEmergencyCarMore(params).then((res) => {
              if(res.code=='200'){
                  const resData=res.data||{}
                  resolve({
                      records:resData.records||[],
                      total:resData.total
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
        handleSearch() {
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        handleReset() {
          this.name = ''
          this.tel = ''
          this.handleSearch()
        },
    }
}
</script>
  
<style lang="scss" scoped>
::v-deep .el-input__inner {
  border-radius: 0 !important;
  border: 1px solid #4390DE;
  height: 36px !important;
  line-height: 36px !important;
}
.content-main {
  height: 600px;
  position: relative;
  box-sizing: border-box;
}
.content {
    margin: 0 60px;
    margin-top: 28px;
}
.header {
    display: flex;
    align-items: center;
    height: 36px;
    margin-bottom: 30px;
}
.alarmType {
    display: flex;
    align-items: center;
    .alarmTxt {
        height: 20px;
        font-family: PingFang SC, PingFang SC;
        font-weight: 500;
        font-size: 14px;
        color: #FFFFFF;
        line-height: 20px;
        text-align: left;
        font-style: normal;
        text-transform: none;
    }
}
.btn {
  width: 67px;
  height: 36px;
  margin-left: 12px;
}
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
</style>