<!-- 应急调度指挥-应急值守 -->
<script>
import Operation from './Operation.vue'
import { getEmergencyDuty } from "@/api/cockpitNew"
export default {
    components: {
      Operation,
    },
    data(){
        return{
            list: [
              // {department: '应急局', post: '1',name: '156xxxxxxxx',tel: '1'},
              // {department: '应急局', post: '1',name: '156xxxxxxxx',tel: '1'},
              // {department: '经信局', post: '1',name: '156xxxxxxxx',tel: '1'},
              // {department: '经信局', post: '1',name: '156xxxxxxxx',tel: '1'},
            ]
        }
    },
    // mounted() {
    //   // 设置定时器，每10秒调用一次
    //   this.intervalId = setInterval(() => {
    //     this.handleSearch();
    //   }, 10000); // 10000毫秒 = 10秒
    // },
    // beforeDestroy() {
    //   // 清理定时器
    //   if (this.intervalId) {
    //     clearInterval(this.intervalId);
    //   }
    // },
    computed:{
        computedList(){
          if(!this.list || this.list.length == 0){
            return [
              {department: '应急局', post: '带班领导', name: '-', tel: '-'},
              {department: '应急局', post: '带班经理', name: '-', tel: '-'},
              {department: '经信局', post: '带班领导', name: '-', tel: '-'},
              {department: '经信局', post: '带班经理', name: '-', tel: '-'},
            ]
          }
          else {
            return this.list
          }
        }
    },
    methods:{
      handleSearch(){
          this.$nextTick(() => {
            const rltable = this.$refs.rltable
            if(rltable){
              rltable.onSearchChange()
            }
          })
      },
      spanMethod({ row, column, rowIndex, columnIndex }) {
          // 合并第一列（department）中的相同值的行
          if (columnIndex === 0) {
            if (rowIndex > 0 && this.computedList[rowIndex].department === this.computedList[rowIndex - 1].department) {
              return { rowspan: 0, colspan: 0 }; // 如果与上一行相同，则当前行不显示
            } else {
              // 如果与上一行不同，则显示当前行并合并
              const rowspan = this.getRowSpanForStreet(rowIndex);
              return { rowspan, colspan: 1 }; // colspan 设为 1，因为只有一个列需要合并
            }
          }
        },
        getRowSpanForStreet(rowIndex) {
          let count = 1;
          const department = this.computedList[rowIndex].department;
          for (let i = rowIndex + 1; i < this.computedList.length; i++) {
            if (this.computedList[i].department === department) {
              count++;
            } else {
              break;
            }
          }
          return count; // 返回当前 `department` 的连续行数，控制行合并的数量
        },
        loadTbaleData({resolve,params}){
          // resolve({
          //             records: this.list,
          //             total:0
          //         })
          getEmergencyDuty(this.$store.state.areaId).then((res) => {
              if(res.code=='200'){
                  this.list = res.data||[]
                  resolve({
                      records: this.computedList,
                      total:0
                  })
              }else{
                  resolve({
                      records: this.computedList,
                      total:0
                  })
              }
            });
        },
    }
}
</script>
<template>
    <div style="height: 200px; border: 2px solid #4390DE;">
        <RlTable
            :is-pagination="false"
            @on-change="loadTbaleData"
            :search="false"
            :stripe="false"
            :spanMethod="spanMethod"
            ref="rltable"
        >
        <template #default>
                <el-table-column prop="department" label="政府部门"  />
                <el-table-column prop="post" label="职务" :show-overflow-tooltip="true" />
                <el-table-column prop="name" label="人员姓名" :show-overflow-tooltip="true" />
                <el-table-column prop="tel" label="联系电话" :show-overflow-tooltip="true" />
                <!-- <el-table-column label="操作" width="80">
                    <template slot-scope="scope">
                        <Operation :rowData="scope.row"/>
                    </template>
                </el-table-column> -->
            </template>
        </RlTable>
    </div>
</template>

<style lang="scss" scoped>
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
::v-deep .el-table--scrollable-y .el-table__body-wrapper {
  overflow: hidden !important;

}
</style>