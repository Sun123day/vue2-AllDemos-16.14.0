<!-- 设备 -->
<template>
  <div class="content">
    <div class="header">
        <div style="display: flex;">
          <div class="alarmType">
              <span class="alarmTxt">名称</span>
              <el-input
                  v-model="name"
                  placeholder="请输入名称"
                  size="small"
                  style="width: 140px; margin-left: 6px;"
                  clearable
                  class="searchInput"
              />
          </div>
          <div class="alarmType" style="margin-left: 16px;">
              <span class="alarmTxt">用户类型</span>
              <el-select
                  v-model="alarmType"
                  :clearable="false"
                  filterable
                  placeholder="请选择"
                  transfer
                  style="width:160px; margin-left: 6px;"
              >
                  <el-option
                      v-for="item in alarmTypeList"
                      :key="item.code"
                      :value="item.code"
                      :label="item.name"
                  />
              </el-select>
          </div>
        </div>
        <div style="display: flex; margin-left: 25px !important;">
            <img class="btn" src="~@/assets/image/cockpit/search-btn.png" alt="" @click="handleSearch">
            <img class="btn" src="~@/assets/image/cockpit/reset-btn.png" alt="" @click="handleReset">
        </div>
    </div>
    <div class="content-main">
      <RlTable
          :is-pagination="true"
          @on-change="loadTbaleData"
          :search="false"
      >
        <template #default>
          <el-table-column type="index" label="序号" width="80" />
          <el-table-column prop="pressure" label="用户名称" />
          <el-table-column prop="flow" label="用户类型" />
          <el-table-column prop="temperature" label="用户地址" />
          <el-table-column prop="time" label="电话号码" />
          <el-table-column label="操作" width="100">
              <template slot-scope="scope">
                  <Operation :rowData="scope.row"/>
              </template>
          </el-table-column>
        </template>
      </RlTable>
    </div>
  </div>
</template>

<script>
import Operation from './Operation.vue'
export default {
    components:{
      Operation,
    },
    data() {
      return {
        list: [
          { pressure: 100, temperature: 10, flow: 10, time: "151xxxxxxxx" },
          { pressure: 200, temperature: 20, flow: 20, time: "151xxxxxxxx" },
          { pressure: 300, temperature: 30, flow: 30, time: "151xxxxxxxx" },
          { pressure: 400, temperature: 40, flow: 40, time: "151xxxxxxxx" },
        ]
      }  
    },
    created(){
        this.initSetModal()
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "设备告警详情");
            this.$emit("SetPageWidth", 950);
        },
        loadTbaleData({resolve,params}){
          resolve({
                      records:this.list,
                      total:this.list.length
                  })
          // findPayRefundList(params).then((res) => {
          //     if(res.code=='200'){
          //         const resData=res.data||{}
          //         resolve({
          //             records:resData.records||[],
          //             total:resData.total
          //         })
          //     }else{
          //         resolve({
          //             records:[],
          //             total:0
          //         })
          //     }
          //   });
        },
        handleSearch() {
            
        },
        handleReset() {

        },
    }
}
</script>
  
<style lang="scss" scoped>
::v-deep .el-input__inner {
  border-radius: 0 !important;
  border: 1px solid #4390DE;
  height: 36px !important;
  line-height: 36px !important;
}
::v-deep .el-select .el-input .el-select__caret {
    color: #4390DE !important
}
.content-main {
  height: 600px;
  position: relative;
  box-sizing: border-box;
}
.content {
    margin: 0 60px;
    margin-top: 28px;
}
.header {
    display: flex;
    align-items: center;
    height: 36px;
    margin-bottom: 30px;
}
.alarmType {
    display: flex;
    align-items: center;
    .alarmTxt {
        height: 20px;
        font-family: PingFang SC, PingFang SC;
        font-weight: 500;
        font-size: 14px;
        color: #FFFFFF;
        line-height: 20px;
        text-align: left;
        font-style: normal;
        text-transform: none;
    }
}
.btn {
  width: 67px;
  height: 36px;
  margin-left: 12px;
}
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
</style>