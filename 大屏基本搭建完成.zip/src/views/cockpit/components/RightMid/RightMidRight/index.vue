<template>
  <div>
    <div class="container">
      <div class="left">
        <div class="left-bg">
          <div class="pie">
            <PieChart
              :tableData = "computedList"
            />
          </div>
        </div>
      </div>
      <div class="right">
        <div class="item" @click="onCHClick">
          <div class="item-left">
            <div class="bubble" style="border: 2px solid #20A8FF;"></div>
            <div class="txt">甲烷</div>
          </div>
          <div class="item-right">{{ computedCH }}</div>
        </div>
        <div class="item" @click="onCOClick">
          <div class="item-left">
            <div class="bubble" style="border: 2px solid #FCD141;"></div>
            <div class="txt">一氧化碳</div>
          </div>
          <div class="item-right">{{ computedCO }}</div>
        </div>
        <div class="item" @click="onDeviceClick">
          <div class="item-left">
            <div class="bubble" style="border: 2px solid #04E5DD;"></div>
            <div class="txt">设备寿命</div>
          </div>
          <div class="item-right">{{ computedDevice }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import PieChart from './PieChart/index.vue'
import CHModal from './CH/index.vue'
import COModal from './CO/index.vue'
import DeviceModal from './Device/index.vue'
import { getAlarmType } from '@/api/cockpitNew'

export default {
  components: {
    PieChart,
    CHModal,
    COModal,
    DeviceModal
  },
  props:{
    start: {
      type: String,
      default: dayjs().format('YYYY-MM-DD')
    },
    end: {
      type: String,
      default: dayjs().format('YYYY-MM-DD')
    }
  },
  data(){
    return {
      list: [
        // { type: '甲烷', num: 0},
        // { type: '一氧化碳', num: 0},
        // { type: '设备寿命', num: 0},
      ]
    }
  },
  // mounted() {
  //   // 设置定时器，每10秒调用一次
  //   this.intervalId = setInterval(() => {
  //     this.getAlarmTypeList();
  //   }, 10000); // 10000毫秒 = 10秒
  // },
  // beforeDestroy() {
  //   // 清理定时器
  //   if (this.intervalId) {
  //     clearInterval(this.intervalId);
  //   }
  // },
  watch: {
    start: {
      handler() {
        this.getAlarmTypeList()
      },
      immediate: true
    },
  },
  computed: {
    computedList(){
      if(!this.list || this.list.length === 0){
        // console.log("进入了");
        return [
          { type: '甲烷', num: 0},
          { type: '一氧化碳', num: 0},
          { type: '设备寿命', num: 0},
        ]
      }
      else {
        // console.log("进入了2");
        return this.list
      }
    },
    computedCH() {
      const item = this.computedList.filter(item => item.type === '甲烷')
      return item[0]?.num || 0
    },
    computedCO() {
      const item = this.computedList.filter(item => item.type === '一氧化碳')
      return item[0]?.num || 0
    },
    computedDevice() {
      const item = this.computedList.filter(item => item.type === '设备寿命')
      return item[0]?.num || 0
    }
  },
  methods: {
    getAlarmTypeList() {
      getAlarmType(this.$props.start, this.$props.end).then(res => {
        if(res.code == 200){
          this.list = res.data
        }
      })
    },
    onCHClick() {
      new this.$pageModal(
          CHModal,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    onCOClick() {
      new this.$pageModal(
          COModal,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    onDeviceClick() {
      new this.$pageModal(
          DeviceModal,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  width: 537px;
  height: 265px;
  display: flex;
  justify-content: space-between;

  padding: 0 68px;
  gap: 77px;
}
.left {
  display: flex;
  align-items: center;
  .left-bg {
    width: 196px;
    height: 196px;
    // background-color: #fff;
    border-radius: 50%;
    border: 1px solid rgba(255,255,255,0.15);
    display: flex;
    align-items: center;
    justify-content: center;
    .pie {
      width: 176px;
      height: 176px;
      border-radius: 50%;
      background-color: rgba(255,255,255,0.1);
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }
}
.right {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 263px;
}
.item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 41px;
  width: 263px;
  padding-top: 34px;
  cursor: pointer;
  .item-left {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-left: 9px;
    .bubble {
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }
    // .bubble:nth-child(1) {
    //   border: 2px solid #20A8FF;
    // }
    // .bubble:nth-child(2) {
    //   border: 2px solid #FCD141;
    // }
    // .bubble:nth-child(3) {
    //   border: 2px solid #04E5DD;
    // }
    .txt {
      margin-left: 5px;
      height: 26px;
      font-family: PingFang SC, PingFang SC;
      font-weight: 500;
      font-size: 18px;
      color: #FFFFFF;
      line-height: 26px;
      text-align: left;
      font-style: normal;
      text-transform: none;
    }
  }

  .item-right {
    margin-right: 26px;
    height: 26px;
    font-family: PingFang SC, PingFang SC;
    font-weight: 500;
    font-size: 18px;
    color: #FFFFFF;
    line-height: 26px;
    text-align: right;
    font-style: normal;
    text-transform: none;
  }
}
.item:nth-child(1){
  border-bottom: 1px solid #20A8FF;
  padding-top: 0;
}
.item:nth-child(2){
  border-bottom: 1px solid #FCD141;
}
.item:nth-child(3){
  border-bottom: 1px solid #04E5DD;
}
</style>