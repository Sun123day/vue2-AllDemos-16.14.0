export function getPieChartOption(data) {
  const color = [
    '#20A8FF',
    '#FCD141',
    '#29C287',
  ];

  const option = {
    tooltip: {
      trigger: 'item',
      formatter: (params) => {
        const dataItem = data.find(item => item.type === params.name);
        return `${dataItem.type}: ${dataItem.num}`;
      },
    },
    title: [
      {
        text: '预警',
        subtext: '类型',
        textStyle: {
          fontSize: 18,
          color: "#FFF",
        },
        subtextStyle: {
          fontSize: 18,
          color: "#FFF",
          fontWeight: 'bold',
        },
        textAlign: "center",
        x: '47%',
        y: '36%',
        zlevel: 10,
      }
    ],
    series: [
      {
        type: 'pie',
        radius: ['50%', '100%'],
        center: ['50%', '50%'],
        data: data.map((item, index) => ({
          name: item.type,  // 使用 type 作为饼图的 name
          value: item.num,  // 使用 num 作为饼图的值
          itemStyle: {
            color: color[index % color.length],
          },
        })),
        emphasis: {
          scale: false,
        },
        label: {
          show: false,
        },
      },
    ]
  };

  return option;
}
