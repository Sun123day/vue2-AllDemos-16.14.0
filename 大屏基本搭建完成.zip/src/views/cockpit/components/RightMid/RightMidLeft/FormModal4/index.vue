<!-- 自闭阀 -->
<template>
  <div></div>
</template>

<script>
export default {
  created(){
      this.initSetModal()
  },
  methods:{
      initSetModal() {
          this.$emit("SetTitle", "自闭阀详情");
          this.$emit("SetPageWidth", 950);
      },
  }
}
</script>

<style lang="scss" scoped>

</style>