<template>
  <div ref="pieEchartRes" style="width: 460px; height: 260px"></div>
</template>

<script>
import { getPie3D } from './chartOptions'
import * as echarts from 'echarts'
import "echarts-gl";
export default {
  props: {
    // tableData: {
    //   type: Array
    // }
  },
  data() {
    return {
      mycharts: null,
      tableData:[
        {
          name: '工商报警器',
          value: 40000,
          rate: 40,
          itemStyle: {
            // 透明度
            //opacity: 0.8,
            opacity: 0,
            // 扇形颜色
            color: 'rgba(51, 251, 201, 1)'
          }
        },
        {
          name: '电磁阀',
          value: 30,
          rate: 30,
          itemStyle: {
            // 透明度
            //opacity: 0.8,
            opacity: 0,
            // 扇形颜色
            color: 'rgba(245, 162, 29, 1)'
          }
        },
        {
          name: '自闭阀',
          value: 20,
          rate: 20,
          itemStyle: {
            // 透明度
            //opacity: 0.8,
            opacity: 0,
            // 扇形颜色
            color: 'rgba(38, 137, 255, 1)'
          }
        },
        {
          name: '家用报警器',
          value: 10,
          rate: 10,
          itemStyle: {
            // 透明度
            //opacity: 0.8,
            opacity: 0,
            // 扇形颜色
            // color: 'rgba(255, 253, 251, 1)'
            color: 'rgba(211, 227, 253, 1)'
          }
        }
      ]
    }
  },
  mounted() {
    this.initEcharts()
  },
  // watch: {
  //   tableData: {
  //     handler() {
  //       this.refreshChart()
  //     },
  //     deep: true
  //   }
  // },
  beforeDestroy() {
    if (this.mycharts) {
      this.mycharts.dispose()
      this.mycharts = null
    }
  },
  methods: {
    initEcharts() {
      this.mycharts = echarts.init(this.$refs.pieEchartRes)
      window.addEventListener('resize', this.autoResize)
      this.autoResize()
      this.refreshChart()
    },
    autoResize() {
      if (this.mycharts) {
        this.mycharts.resize()
      }
    },
    refreshChart() {
      if (!this.mycharts || !this.tableData) {
        return
      }
      const option = getPie3D(this.tableData, 0.71)
      this.mycharts.setOption(option)
    },
    setHighLight(dataIndex = 0) {
      this.mycharts.dispatchAction({
        type: 'highlight',
        seriesIndex: 0,
        dataIndex
      })
    }
  }
}
</script>