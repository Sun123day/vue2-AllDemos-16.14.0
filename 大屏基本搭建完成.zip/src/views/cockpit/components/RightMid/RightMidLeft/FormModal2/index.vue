<!-- 家用报警器 -->
<template>
  <div class="content">
    <div ref="barHorizontalEchartRes" style="width: 600px; height: 600px;"></div>
  </div>
</template>

<script>

import { getBarHorizontalChartOption } from './chartOptions'
import * as echarts from 'echarts'

export default {
  // props: {
  //   tableData: {
  //     type: Array
  //   }
  // },
  data() {
    return {
      mycharts: null,
      tableData: [
        {name: '正常', value: 500, rate: 50},
        {name: '离线', value: 200, rate: 20},
        {name: '故障', value: 100, rate: 10},
        {name: '寿命预警', value: 50, rate: 5},
        {name: '甲烷告警', value: 50, rate: 5},
        {name: 'CO告警', value: 100, rate: 10},
      ]
    }
  },
  created(){
      this.initSetModal()
  },
  mounted() {
    this.initEcharts()
  },
  // watch: {
  //   tableData: {
  //     handler() {
  //       this.refreshChart()
  //     },
  //     deep: true
  //   }
  // },
  beforeDestroy() {
    if (this.mycharts) {
      this.mycharts.dispose()
      this.mycharts = null
    }
  },
  methods:{
      initSetModal() {
          this.$emit("SetTitle", "家用报警器详情");
          this.$emit("SetPageWidth", 750);
      },
      initEcharts() {
        this.mycharts = echarts.init(this.$refs.barHorizontalEchartRes)
        window.addEventListener('resize', this.autoResize)
        this.autoResize()
        this.refreshChart()
      },
      autoResize() {
        if (this.mycharts) {
          this.mycharts.resize()
        }
      },
      refreshChart() {
        if (!this.mycharts || !this.tableData) {
          return
        }
        const option = getBarHorizontalChartOption(this.tableData)
        this.mycharts.setOption(option)
      },
      setHighLight(dataIndex = 0) {
        this.mycharts.dispatchAction({
          type: 'highlight',
          seriesIndex: 0,
          dataIndex
        })
      }
  }
}
</script>

<style lang="scss" scoped>
.content {
  // width: 100%;
  // height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}
::v-deep .core-modal-wrap .core-modal .core-modal-body .content-body {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
}
</style>