import * as echarts from 'echarts'
export function getBarHorizontalChartOption(data) {
  // 计算最大值并加上 10
  let maxValue = Math.max(...data.map(item => item.value)) + 50;
  let salvProMax = Array(data.length).fill(maxValue); // 背景柱的值为最大值 + 10

  const option = {
    grid: {
        left: '2%',
        right: '2%',
        bottom: '2%',
        top: '2%',
        containLabel: true
    },
    xAxis: {
        show: false,
        type: 'value'
    },
    yAxis: [{
        type: 'category',
        inverse: true,
        axisLabel: {
            show: true,
            textStyle: {
                color: '#fff'
            },
        },
        splitLine: {
            show: false
        },
        axisTick: {
            show: false
        },
        axisLine: {
            show: false
        },
        data: data.map(item => item.name) // 提取名称作为 y 轴数据
    }, {
        type: 'category',
        inverse: true,
        axisTick: 'none',
        axisLine: 'none',
        show: true,
        axisLabel: {
            textStyle: {
                color: '#ffffff',
                fontSize: '12'
            },
            formatter: function(value, index) {
                let rate = data[index].rate; // 获取当前项的 rate
                return value + '个(' + rate + '%)'; // 在每个值后加上 "个"
            }
        },
        data: data.map(item => item.value) // 提取值作为 y 轴数据
    }],
    series: [{
            name: '值',
            type: 'bar',
            zlevel: 1,
            itemStyle: {
                normal: {
                    barBorderRadius: 30,
                    color: new echarts.graphic.LinearGradient(0, 1, 1, 0, [{
                        offset: 0,
                        color: '#00A2FF'
                    }, {
                        offset: 1,
                        color: '#00CCD2'
                    }]),
                },
            },
            barWidth: 20,
            data: data.map(item => item.value) // 使用新的数据格式
        },
        {
            name: '背景',
            type: 'bar',
            barWidth: 20,
            barGap: '-100%',
            data: salvProMax, // 背景柱的值
            itemStyle: {
                normal: {
                    color: 'rgba(255,255,255,0.1)',
                    barBorderRadius: 30,
                }
            },
        },
    ]
  };

  return option;
}
