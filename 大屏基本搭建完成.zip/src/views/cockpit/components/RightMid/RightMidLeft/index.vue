<template>
  <div>
    <div class="content">
      <div class="header">设备概况</div>
      <div class="container">
        <div class="chart">
          <PieChart
              :tableData = "computedList"
          />
        </div>
        <div class="legend">
          <div class="item" @click="form1Click">
            <div class="color" style="background: linear-gradient( 282deg, #0080F2 0%, #64B4FF 100%);"></div>
            <div class="info">
              <div class="txt">工商报警器</div>
              <div class="num">{{ computedNum1 }}</div>
            </div>
            <div class="rate">{{ computedRate1 }}%</div>
          </div>
          <div class="item" @click="form2Click">
            <div class="color" style="background: linear-gradient( 219deg, #FCD141 0%, #FCD141 100%);"></div>
            <div class="info">
              <div class="txt">家用报警器</div>
              <div class="num">{{ computedNum2 }}</div>
            </div>
            <div class="rate">{{ computedRate2 }}%</div>
          </div>
          <div class="item" @click="form3Click">
            <div class="color" style="background: linear-gradient( 278deg, #FAA20A 0%, #F26904 100%);"></div>
            <div class="info">
              <div class="txt">电磁阀</div>
              <div class="num">{{ computedNum3 }}</div>
            </div>
            <div class="rate">{{ computedRate3 }}%</div>
          </div>
          <!-- <div class="item" @click="form4Click"> -->
          <div class="item">
            <div class="color" style="background: #FFFDFB;"></div>
            <div class="info">
              <div class="txt">自闭阀</div>
              <div class="num">{{ computedNum4 }}</div>
            </div>
            <div class="rate">{{ computedRate4 }}%</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs';
import PieChart from './PieChart/index.vue'
import FormModal1 from './FormModal1/index.vue';
import FormModal2 from './FormModal2/index.vue';
import FormModal3 from './FormModal3/index.vue';
import FormModal4 from './FormModal4/index.vue';
import { getDeviceType } from '@/api/cockpitNew'

export default {
  components:{
    PieChart,
    FormModal1,
    FormModal2,
    FormModal3,
    FormModal4,
  },
  props:{
    start: {
      type: String,
      default: dayjs().format('YYYY-MM-DD')
    },
    end: {
      type: String,
      default: dayjs().format('YYYY-MM-DD')
    }
  },
  data(){
    return {
      list: [
        // { name: '工商报警器', num: 0, rate: 0 },
        // { name: '家用报警器', num: 0, rate: 0 },
        // { name: '电磁阀', num: 0, rate: 0 },
        // { name: '自闭阀', num: 0, rate: 0 },
      ]
    }
  },
  // mounted() {
  //   // 设置定时器，每10秒调用一次
  //   this.intervalId = setInterval(() => {
  //     this.getAlarmTypeList();
  //   }, 10000); // 10000毫秒 = 10秒
  // },
  // beforeDestroy() {
  //   // 清理定时器
  //   if (this.intervalId) {
  //     clearInterval(this.intervalId);
  //   }
  // },
  watch: {
    start: {
      handler() {
        this.getDeviceTypeList()
      },
      immediate: true
    },
  },
  computed: {
    computedList(){
      if(!this.list || this.list.length === 0){
        // console.log("进入了");
        return [
          { name: '工商报警器', num: 0, rate: 0 },
          { name: '家用报警器', num: 0, rate: 0 },
          { name: '电磁阀', num: 0, rate: 0 },
          { name: '自闭阀', num: 0, rate: 0 },
        ]
      }
      else {
        // console.log("进入了2");
        return this.list
      }
    },
    computedNum1() {
      // const item = this.computedList.filter(item => item.name === '工商报警器')
      // return item[0]?.num || 0
      return this.computedList[0]?.num || 0
    },
    computedRate1() {
      // const item = this.computedList.filter(item => item.name === '工商报警器')
      // return item[0]?.rate || 0
      return this.computedList[0]?.rate || 0
    },
    computedNum2() {
      // const item = this.computedList.filter(item => item.name === '家用报警器')
      // return item[0]?.num || 0
      return this.computedList[1]?.num || 0
    },
    computedRate2() {
      // const item = this.computedList.filter(item => item.name === '家用报警器')
      // return item[0]?.rate || 0
      return this.computedList[1]?.rate || 0
    },
    computedNum3() {
      // const item = this.computedList.filter(item => item.name === '电磁阀')
      // return item[0]?.num || 0
      return this.computedList[2]?.num || 0
    },
    computedRate3() {
      // const item = this.computedList.filter(item => item.name === '电磁阀')
      // return item[0]?.rate || 0
      return this.computedList[2]?.rate || 0
    },
    computedNum4() {
      // const item = this.computedList.filter(item => item.name === '自闭阀')
      // return item[0]?.num || 0
      return this.computedList[3]?.num || 0
    },
    computedRate4() {
      // const item = this.computedList.filter(item => item.name === '自闭阀')
      // return item[0]?.rate || 0
      return this.computedList[3]?.rate || 0
    },
  },
  methods: {
    getDeviceTypeList() {
      getDeviceType(this.$props.start, this.$props.end).then(res => {
        if(res.code == 200){
          this.list = res.data
        }
      })
    },
    form1Click(){
      new this.$pageModal(
        FormModal1,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    form2Click(){
      new this.$pageModal(
        FormModal2,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    form3Click(){
      new this.$pageModal(
        FormModal3,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
    form4Click(){
      new this.$pageModal(
        FormModal4,
          {
              props: {
              },
          },
          (result) => {
          }
      )
    },
  }
}
</script>

<style lang="scss" scoped>
.content {
  display: flex;
  flex-direction: column;
  width: 500px;
  height: 265px;
}
.header {
  height: 26px;
  font-family: YouSheBiaoTiHei, YouSheBiaoTiHei;
  font-weight: bold;
  font-size: 20px;
  color: #2AFFFF;
  line-height: 26px;
  text-align: center;
  font-style: italic;
  text-transform: none;
  margin-bottom: 15px;
}
.container {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 40px;
}
.chart {
  height: 220px;
  width: 250px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.legend {
  width: 200px;
  height: 220px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: 20px;
}
.item {
  display: flex;
  align-items: center;
  cursor: pointer;
  .color {
    border-radius: 50%;
    height: 12px;
    width: 12px;
    margin-right: 8px;
  }
  // .color:nth-child(1){
  //   background: linear-gradient( 282deg, #0080F2 0%, #64B4FF 100%);
  // }
  // .color:nth-child(2){
  //   background: linear-gradient( 219deg, #FCD141 0%, #FCD141 100%);
  // }
  // .color:nth-child(3){
  //   background: linear-gradient( 278deg, #FAA20A 0%, #F26904 100%);
  // }
  // .color:nth-child(4){
  //   background: #FFFDFB;
  // }
  .info {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 116px;
    .txt, .num {
      height: 16px;
      font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
      font-weight: 400;
      font-size: 12px;
      color: #FFFFFF;
      line-height: 16px;
      text-align: left;
      font-style: normal;
      text-transform: none;
    }
    .num {
      color: #2AFFFF;
      text-align: right;
    }
  }
  .rate {
    width: 64px;
    height: 16px;
    font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
    font-weight: 400;
    font-size: 12px;
    color: #FFFFFF;
    line-height: 16px;
    text-align: right;
    font-style: normal;
    text-transform: none;
  }
}
</style>