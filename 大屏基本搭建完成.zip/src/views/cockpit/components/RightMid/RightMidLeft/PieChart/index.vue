<template>
  <div ref="pieEchartRes" style="width: 200px; height: 200px"></div>
</template>

<script>
import { getPieChartOption } from './chartOptions'
import * as echarts from 'echarts'

export default {
  props: {
    tableData: {
      type: Array
    }
  },
  data() {
    return {
      mycharts: null,
      // tableData: [
      //   {name: '工商报警器', num: 4000, rate: 40},
      //   {name: '家用报警器', num: 3000, rate: 30},
      //   {name: '电磁阀', num: 2000, rate: 20},
      //   {name: '自闭阀', num: 1000, rate: 10},
      // ]
    }
  },
  mounted() {
    this.initEcharts()
  },
  watch: {
    tableData: {
      handler() {
        this.refreshChart()
      },
      deep: true
    }
  },
  beforeDestroy() {
    if (this.mycharts) {
      this.mycharts.dispose()
      this.mycharts = null
    }
  },
  methods: {
    initEcharts() {
      this.mycharts = echarts.init(this.$refs.pieEchartRes)
      window.addEventListener('resize', this.autoResize)
      this.autoResize()
      this.refreshChart()
    },
    autoResize() {
      if (this.mycharts) {
        this.mycharts.resize()
      }
    },
    refreshChart() {
      if (!this.mycharts || !this.tableData) {
        return
      }
      const option = getPieChartOption(this.tableData)
      this.mycharts.setOption(option)
    },
    setHighLight(dataIndex = 0) {
      this.mycharts.dispatchAction({
        type: 'highlight',
        seriesIndex: 0,
        dataIndex
      })
    }
  }
}
</script>