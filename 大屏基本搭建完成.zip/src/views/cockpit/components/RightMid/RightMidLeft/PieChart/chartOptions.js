import * as echarts from 'echarts'
export function getPieChartOption(data) {
  const color = [
    new echarts.graphic.LinearGradient(0, 1, 0, 0, [{ offset: 1, color: '#0080F2' }, { offset: 1, color: '#64B4FF' }]),
    new echarts.graphic.LinearGradient(0, 1, 0, 0, [{ offset: 1, color: '#FCD141' }, { offset: 1, color: '#FCD141' }]),
    new echarts.graphic.LinearGradient(0, 1, 0, 0, [{ offset: 1, color: '#FAA20A' }, { offset: 1, color: '#FAA20A' }]),
    new echarts.graphic.LinearGradient(0, 1, 0, 0, [{ offset: 1, color: '#FFFDFB' }, { offset: 1, color: '#FFFDFB' }]),
  ];

  // 计算 num 的总和
  const totalNum = data.reduce((sum, item) => sum + item.num, 0);
  
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{b}: {c} ({d}%)', // 显示名称、值和百分比
    },
    title: [    
      {
          // text: 100086.11,
          // text: 0,
          text: totalNum,
          textStyle:{
              fontSize: 18,
              color:"#FF7A00"
          },
          textAlign:"center",
          x: '47%',
          y: '45%',
          zlevel: 10,
      }
      
    ],
    series: [
      {
        type: 'pie',
        radius: ['65%', '80%'],
        center: ['50%', '50%'],
        data: data.map((item, index) => ({
          name: item.name,
          value: item.num, // 使用 num 作为饼图的值
          rate: item.rate, // 保持原有的 rate
          itemStyle: {
            color: color[index % color.length]
          }
        })),      
        // itemStyle: {
        //   borderRadius: 2,
        //   borderColor: '#0472a3',
        //   borderWidth: 1,
        //   shadowColor: 'rgba(142, 152, 241, 0.6)',
        //   shadowBlur: 5,
        // },
        // padAngle: 4,
        emphasis: {
          scale: false,
          label: {
            show: false,
          }
        },
        label: {
          show: false,
          position: 'center',
        },
      },
      {
        radius: ['0', '50%'],
        center: ['50%', '50%'],
        type: 'pie',
        z: 10,
        color: '#002042',
        label: {
          show: false,
        },
        labelLine: {
          show: false,
        },
        emphasis: {
          show: false,
          scale: false
        },
        animation: false,
        tooltip: {
          show: false,
        },
        data: [{ value: 1 }],
      },
      {
        type: 'pie',
        zlevel: 3,
        silent: true,
        radius: ['57%', '58%'],
        label: {
            show: false
        },
        labelLine: {
            show: false
        },
        data: _pie3(),
      }, 
      {
        type: 'pie',
        zlevel: 3,
        silent: true,
        radius: ['85%', '86%'],
        label: {
            show: false
        },
        labelLine: {
          show: false
        },
        data: _pie4(),
      }, 
      {
        type: 'pie',
        zlevel: 3,
        silent: true,
        radius: ['90%', '91%'],
        label: {
          show: false
        },
        labelLine: {
          show: false
        },
        data: _pie5(),
      }, 
    ],
    
  };

  return option;
}

export function _pie3() {
  let dataArr = [];
  for (var i = 0; i < 150; i++) {
      if (i % 2 === 0) {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 25,
              value: 10,
              itemStyle: {
                  color: "rgb(126,190,255)",
                  borderWidth: 0,
                  borderColor: "rgba(0,0,0,0)"
              }
          })
      } else {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 20,
              value: 10,
              itemStyle: {
                  color: "rgba(0,0,0,0)",
                  borderWidth: 0,
                  borderColor: "rgba(0,0,0,0)"
              }
          })
      }

  }
  return dataArr
}

export function _pie4() {
  let dataArr = [];
  for (var i = 0; i < 200; i++) {
      if (i % 2 === 0) {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 25,
              value: 10,
              itemStyle: {
                  color: "rgb(126,190,255)",
                  borderWidth: 0,
                  borderColor: "rgba(0,0,0,0)"
              }
          })
      } else {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 20,
              value: 10,
              itemStyle: {
                  color: "rgba(0,0,0,0)",
                  borderWidth: 0,
                  borderColor: "rgba(0,0,0,0)"
              }
          })
      }

  }
  return dataArr
}

export function _pie5() {
  let dataArr = [];
  for (var i = 0; i < 100; i++) {
      if (i % 25 === 0) {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 25,
              value: 10,
              itemStyle: {
                  color: "rgb(126,190,255)",
                  borderWidth: 1,
                  borderColor: "rgba(0,0,0,0)"
              }
          })
      } else {
          dataArr.push({
              // name: (i + 1).toString(),
              name: (i).toString(),
              // value: 20,
              value: 10,
              itemStyle: {
                  color: "rgba(0,0,0,0)",
                  borderWidth: 1,
                  borderColor: "rgba(0,0,0,0)"
              }
          })
      }

  }
  return dataArr
}