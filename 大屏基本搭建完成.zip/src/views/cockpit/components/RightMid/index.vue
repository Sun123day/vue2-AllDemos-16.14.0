<template>
    <div>
        <div class="title-container">
            <span class="title">监测设备</span>
            <div class="title-btn-container">
                <span 
                    class="title-btn-txt" 
                    @click="monitorDayClick"
                    :class="{ 'selected': isSelected('day') }"
                >今日</span>
                <span class="title-btn-line"></span>
                <span 
                    class="title-btn-txt" 
                    @click="monitorWeekClick"
                    :class="{ 'selected': isSelected('week') }"
                >周</span>
                <span class="title-btn-line"></span>
                <span 
                    class="title-btn-txt"
                    @click="monitorMonthClick"
                    :class="{ 'selected': isSelected('month') }"
                >月</span>
                <span class="title-btn-line"></span>
                <span
                    class="title-btn-txt"
                    @click="monitorYearClick"
                    :class="{ 'selected': isSelected('year') }"
                >年</span>
                <span class="title-btn-line"></span>
                <span
                    class="title-btn-txt"
                    @click="monitorAllClick"
                    :class="{ 'selected': isSelected('all') }"
                >全部</span>
                <span class="title-btn-line"></span>
            </div>
        </div>
        <div class="main-content">
            <div class="left">
                <RightMidLeft
                    :start="start"
                    :end="end"
                />
            </div>
            <div class="right">
                <RightMidRight
                    :start="start"
                    :end="end"
                />
            </div>
        </div>
    </div>
</template>

<script>
import dayjs from 'dayjs';
import RightMidLeft from './RightMidLeft/index.vue'
import RightMidRight from './RightMidRight/index.vue'
export default {
    components: {
        RightMidLeft,
        RightMidRight,
    },
    data() {
      return {
        monitorSelected: 'day',
        start: dayjs().format('YYYY-MM-DD'),
        end: dayjs().format('YYYY-MM-DD'),

        intervalId: null,    // 保存定时器的 ID
        timeTypes: ['day', 'week', 'month', 'year', 'all'],
        currentIndex: 0,     // 当前执行的时间类型索引
      }
    },
    created(){
        this.monitorDayClick()
    },
    // mounted() {
    //     // 启动定时器，每 10 秒触发一次
    //     this.startAutoSwitch();  // 启动定时切换
    // },
    // beforeDestroy() {
    //     if (this.intervalId) {
    //         clearInterval(this.intervalId);  // 组件销毁时清除定时器
    //     }
    // },
    methods:{
      // 启动定时器每10秒自动切换
      startAutoSwitch() {
          this.intervalId = setInterval(() => {
              // 根据当前的索引调用相应的点击方法
              switch (this.timeTypes[this.currentIndex]) {
                  case 'day':
                      this.monitorDayClick();
                      break;
                  case 'week':
                      this.monitorWeekClick();
                      break;
                  case 'month':
                      this.monitorMonthClick();
                      break;
                  case 'year':
                      this.monitorYearClick();
                      break;
                  case 'all':
                      this.monitorAllClick();
                      break;
              }
  
              // 更新当前索引，确保循环调用
              this.currentIndex = (this.currentIndex + 1) % this.timeTypes.length;
          }, 2000); // 每10秒执行一次
      },
      monitorDayClick() {
          this.monitorSelected = 'day';
          this.start = dayjs().format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
      },
      monitorWeekClick() {
          this.monitorSelected = 'week';
          this.start = dayjs().subtract(7, 'day').format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
      },
      monitorMonthClick() {
          this.monitorSelected = 'month';
          this.start = dayjs().subtract(1, 'month').format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
      },
      monitorYearClick() {
          this.monitorSelected = 'year';
          this.start = dayjs().subtract(1,'year').format('YYYY-MM-DD');
          this.end = dayjs().format('YYYY-MM-DD');
      },
      monitorAllClick() {
          this.monitorSelected = 'all';
          this.start = ''
          this.end = '';
      },
      isSelected(value) {
          return this.monitorSelected === value;
      },
    }
}
</script>

<style lang="scss" scoped>
.title-container {
    width: 100%;
    height: 26px;
    background-image: url('~@/assets/image/cockpit/title-container.png');
    background-size: 1280px 26px;
    background-repeat: no-repeat;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .title {
        height: 26px;
        font-family: YouSheBiaoTiHei, YouSheBiaoTiHei;
        font-weight: bold;
        font-size: 20px;
        color: #2AFFFF;
        line-height: 26px;
        text-align: left;
        font-style: italic;
        text-transform: none;
        margin-left: 34px;
    }
    .title-btn-container {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-right: 30px;

        .title-btn-txt{
            height: 16px;
            font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
            font-weight: 400;
            font-size: 16px;
            color: #00FFFF;
            line-height: 16px;
            text-align: left;
            font-style: normal;
            text-transform: none;
            cursor: pointer;
        }
        .title-btn-line {
            border: 1px solid #00FFFF;
            height: 18px;
        }
        .selected {
            color: #FFAB2D; // 选中时字体颜色变为#FFAB2D
        }
    }
}
.main-content {
    padding: 15px 36px 20px;
    display: flex;
    justify-content: space-between;
    gap: 16px;
    height: 265px;
}
.left {
    width: 499px;
    height: 265px;
    // background-color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
}
.right {
    width: 673px;
    height: 265px;
    background: linear-gradient( 90deg, #032052 0%, #031D37 100%);
    border: 1px solid;
    border-image: linear-gradient(90deg, rgba(54, 111, 209, 1), rgba(2, 20, 44, 0)) 1 1;
    // background-color: pink;
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>