<!-- 费用记录 -->
<template>
  <div class="left-mid-right-container">
      <div class="header">
        <BigScreenTab
            :sourceData="tabData"
            v-model="tabType"
            @change="handleChange"
        />
          <img class="btn" src="~@/assets/image/cockpit/more-btn.png" alt="" @click="handleMoreClick">
      </div>
      <Process
        v-if="tabType == 'PROCESS'"
        class="table"
      />
      <Finish
        v-if="tabType == 'FINISH'"
        class="table"
      />
  </div>
</template>

<script>
import BigScreenTab from '@/components/BigScreenTab'
import Process from './process/index.vue'
import ProcessForm from './process/components/FormModal.vue'
import Finish from './finish/index.vue'
import FinishForm from './finish/components/FormModal.vue'
const POLICY = 'PROCESS' // 配置选项
export default {
    name: 'customAlarmManage',
    components: {
        BigScreenTab,
        Process,
        ProcessForm,
        Finish,
        FinishForm,
    },
    data() {
        return {
            tabType: POLICY,
            tabData: [
                {
                    code: 'PROCESS',
                    text: '正在办理',
                },
                {
                    code: 'FINISH',
                    text: '已办结',
                },
            ],
        }
    },
    methods: {
        handleChange() {
          console.log(this.tabType);
        },
        handleMoreClick(){
          new this.$pageModal(
            this.tabType === 'PROCESS' ? ProcessForm : FinishForm,
            {
                props:{
                  
                },
            },
            (result)=>{
                
            }
          )
        }
    },
}
</script>
<style lang="scss" scoped>
.left-mid-right-container {
  width: 620px;
  height: 100%;
  // background-color: #fff;
}
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 36px;
  margin-bottom: 7px;
}

.table {
  // height: 231px;
  height: 200px;
  width: 620px;
  position: relative;
  border: 2px solid #4390DE;
}

.btn {
  width: 67px;
  height: 30px;
}
</style>