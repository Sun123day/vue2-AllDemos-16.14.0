<script>
import dayjs from 'dayjs';
import Operation from './Operation.vue'
import { getSecurityCheckStatusPageList } from '@/api/cockpitNew'
export default {
    components: {
        Operation,
    },
    data() {
        return {
            timeRange: [],
            pickerOptions: {
                disabledDate(time) {
                    return time.getTime() > new Date().getTime()    //使用这种方法实现
                },
            },
            warnType: '',
            warnTypeList: [
                {
                    code: 1,
                    name: '甲烷'
                },
                {
                    code: 0,
                    name: '一氧化碳'
                },
                {
                    code: 2,
                    name: '寿命预警'
                }
            ],
            keyValue: '',
            // list: [
            //     {street: '街道1'},
            //     {street: '街道2'},
            // ]
        }
    },
    created(){
        this.initSetModal()
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "已办结预警列表");
            this.$emit("SetPageWidth", 900);
        },
        loadTbaleData({resolve,params}){
        //   resolve({
        //               records:this.list,
        //               total:this.list.length
        //           })
        params.condition = {
          status: 1, // 处理状态 0:正在办理 1:已办结
          warnType: this.warnType, //预警类型 0:甲烷 1:一氧化碳 2:设备寿命
          start: this.timeRange[0] ? dayjs(this.timeRange[0]).format('YYYY-MM-DD') : '',
          end: this.timeRange[1] ? dayjs(this.timeRange[1]).format('YYYY-MM-DD') : '',
          keyValue: this.keyValue
        }
        getSecurityCheckStatusPageList(params).then((res) => {
              if(res.code=='200'){
                  const resData=res.data||[]
                  resolve({
                      records:resData.records||[],
                      total:resData.total || 0
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
        handleSearch() {
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        handleReset() {
          this.timeRange = []
          this.warnType = ''
          this.keyValue = ''
          this.handleSearch()
        },
    }
}
</script>
<template>
    <div class="content">
        <div class="header">
            <el-date-picker
                v-model="timeRange"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :editable="false"
                :clearable="false"
                style="width: 280px !important;"
                class="calendar-single"
                :pickerOptions="pickerOptions"
            />
            <div class="alarmType">
                <span class="alarmTxt">预警类型</span>
                <el-select
                    v-model="warnType"
                    :clearable="false"
                    filterable
                    placeholder="请选择"
                    transfer
                    style="width:110px; margin-left: 6px;"
                >
                    <el-option
                        v-for="item in warnTypeList"
                        :key="item.code"
                        :value="item.code"
                        :label="item.name"
                    />
                </el-select>
            </div>
            <div class="searchItem">
                <el-input
                    v-model="keyValue"
                    placeholder="请输入名称"
                    size="small"
                    style="width: 140px"
                    clearable
                    class="searchInput"
                />
                <img
                    src="~@/assets/image/cockpit/grid_detail_search_btn.png"
                    alt=""
                    class="searchIcon"
                />
            </div>
            <div style="display: flex; margin-left: 25px !important;">
                <img class="btn" src="~@/assets/image/cockpit/search-btn.png" alt="" @click="handleSearch">
                <img class="btn" src="~@/assets/image/cockpit/reset-btn.png" alt="" @click="handleReset">
            </div>
        </div>
        <div class="content-main">
            <RlTable
                :is-pagination="true"
                @on-change="loadTbaleData"
                :search="false"
                ref="rltable"
            >
            <template #default>
                    <el-table-column type="index" label="序号"  width="80" />
                    <el-table-column prop="warnDate" label="预警日期" />
                    <el-table-column prop="warnTypeName" label="预警类型" />
                    <el-table-column prop="warnDesc" label="预警描述" />
                    <!-- <el-table-column prop="urgency" label="办结情况" />
                    <el-table-column prop="urgency" label="是否办结" /> -->
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <Operation :rowData="scope.row"/>
                        </template>
                    </el-table-column>
            </template>
            </RlTable>
        </div>
    </div>
</template>

<style lang="scss" scoped>
.content-main {
  height: 600px;
  position: relative;
  box-sizing: border-box;
}
.content {
    margin: 0 18px;
    margin-top: 28px;
}
.header {
    display: flex;
    align-items: center;
    height: 36px;
    margin-bottom: 18px;
}
.alarmType {
    display: flex;
    margin-left: 16px;
    align-items: center;
    .alarmTxt {
        height: 20px;
        font-family: PingFang SC, PingFang SC;
        font-weight: 500;
        font-size: 14px;
        color: #FFFFFF;
        line-height: 20px;
        text-align: left;
        font-style: normal;
        text-transform: none;
    }
}
.searchItem {
    height: 36px;
    display: flex;
    align-items: center;
    border: 1px solid #4390DE;
    margin-left: 12px;
}
.searchInput ::v-deep .el-input__inner {
  border: none !important;
}
.searchIcon {
  width: 18px;
  height: 18px;
  margin: 0 12px;
}
.btn {
  width: 67px;
  height: 36px;
  margin-left: 12px;
}
// ::v-deep .el-select .el-input .el-select__caret::before {
//     /*content: "\e78f"*/
//     content: "";/*去除select默认的下拉图标*/
//     background: url('~@/assets/image/cockpit/select-arrow.png') center center no-repeat;
//     background-size: 14px 14px;
//     position: absolute;
//     width: 100%;
//     height: 100%;
//     //使图片箭头向下
//     appearance: none;// 去除select默认的下拉图标
//     -moz-appearance: none; // 兼容chrome
//     -webkit-appearance: none;// 兼容firefox
//     -webkit-transform: rotate(180deg);/* Safari 和 Chrome */
//     -moz-transform: rotate(180deg);/* Firefox */
//     -o-transform: rotate(180deg);/* Opera */
//     -ms-transform: rotate(180deg);/* IE 9 */
//     transform: rotate(180deg);/* 旋转180度图片 */
//     top: 0%;
//     right: 10%;
// }
::v-deep .el-select .el-input .el-select__caret {
    color: #4390DE !important
}

::v-deep .el-input__inner {
  border-radius: 0 !important;
  border: 1px solid #4390DE;
  height: 36px !important;
  line-height: 36px !important;
}
::v-deep .el-input--small .el-input__inner {
  height: 36px !important;
  line-height: 36px !important;
}
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
.calendar-single ::v-deep.el-icon-date:before {
    content: '' !important;
}
.calendar-single ::v-deep.el-input__suffix {
    width: 25px !important;
}
// .calendar-single ::v-deep.el-input__suffix:before {
.calendar-single ::v-deep i:last-child {
    background: url('~@/assets/image/cockpit/calendar.png') center center no-repeat !important;
    background-size: 18px 18px !important;
}
.calendar-single ::v-deep.el-range-separator {
    line-height: 28px !important;
}
</style>