<!-- 预警类型-已办结 -->
<script>
import { getSecurityCheckStatus } from '@/api/cockpitNew'
import Operation from './components/Operation.vue'
export default {
    components:{
      Operation,
    },
    data(){
        return{
        }
    },
    // mounted() {
    //   // 设置定时器，每10秒调用一次
    //   this.intervalId = setInterval(() => {
    //     this.handleSearch();
    //   }, 10000); // 10000毫秒 = 10秒
    // },
    // beforeDestroy() {
    //   // 清理定时器
    //   if (this.intervalId) {
    //     clearInterval(this.intervalId);
    //   }
    // },
    methods:{
        handleSearch(){
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        loadTbaleData({resolve,params}){
          // resolve({
          //             records:[
          //               {warnDate: '2024-11-7', warnType: '类型1', warnDesc: '描述1'},
          //               {warnDate: '2024-11-7', warnType: '类型1', warnDesc: '描述1'},
          //               {warnDate: '2024-11-7', warnType: '类型1', warnDesc: '描述1'},
          //             ],
          //             total:0
          //         })
          params.condition = {
            status: 1 // 0:正在办理 1:已办结
          }
          getSecurityCheckStatus({
            status: 1
          }).then((res) => {
              if(res.code=='200'){
                  const resData=res.data||[]
                  resolve({
                      records:resData||[],
                      total:resData.length || 0
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
    }
}
</script>
<template>
    <div>
        <RlTable
            :is-pagination="false"
            @on-change="loadTbaleData"
            :search="false"
            ref="rltable"
        >
        <template #default>
                <el-table-column prop="warnDate" label="预警日期"  width="120" />
                <el-table-column prop="warnTypeName" label="预警类型" :show-overflow-tooltip="true" />
                <el-table-column prop="warnDesc" label="预警描述" :show-overflow-tooltip="true" />
                <el-table-column label="操作" width="100">
                    <template slot-scope="scope">
                        <Operation :rowData="scope.row"/>
                    </template>
                </el-table-column>
            </template>
        </RlTable>
    </div>
</template>

<style lang="scss" scoped>
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
::v-deep .el-table--scrollable-y .el-table__body-wrapper {
  overflow: hidden !important;

}
</style>