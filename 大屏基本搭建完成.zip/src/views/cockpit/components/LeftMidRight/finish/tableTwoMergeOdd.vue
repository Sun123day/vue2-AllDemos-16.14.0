<template>
  <table class="mailTable" :style="styleObject" v-if="s_showByRow"  border="0" cellspacing="0" cellpadding="0">
    <tr v-for="index in rowCount">
      <td class="column">{{tableData[index*2-2].key}}</td>
      <td>{{tableData[index*2-2].value}}</td>
      <td class="column">{{tableData[index*2-1] !== undefined ? tableData[index*2-1].key : ''}}</td>
      <td>{{tableData[index*2-1] !== undefined ? tableData[index*2-1].value : ''}}</td>
    </tr>
    <!-- 如果存在 lastCount，则在表格最后一行单独显示最后一项，并合并右侧内容 -->
    <tr v-if="lastCount">
      <td class="column">{{ lastCount.key }}</td>
      <td :colspan="3">{{ lastCount.value }}</td>
    </tr>
  </table>
  <table class="mailTable" :style="styleObject" v-else border="0" cellspacing="0" cellpadding="0">
    <tr v-for="index in rowCount">
      <td class="column">{{tableData[index-1].key}}</td>
      <td>{{tableData[index-1].value}}</td>
      <td class="column">{{tableData[rowCount+index-1] !== undefined ? tableData[rowCount+index-1].key : ''}}</td>
      <td>{{tableData[rowCount+index-1] !== undefined ? tableData[rowCount+index-1].value : ''}}</td>
    </tr>
    <!-- 如果存在 lastCount，则在表格最后一行单独显示最后一项，并合并右侧内容 -->
    <tr v-if="lastCount">
      <td class="column">{{ lastCount.key }}</td>
      <td :colspan="3">{{ lastCount.value }}</td>
    </tr>
  </table>
</template>

<script>
export default {
  data() {
    return {
      styleObject: {},
      s_showByRow: true,
      lastCount: null,
    };
  },
  props: ['tableData', 'tableStyle', 'showByRow'],
  computed: {
    rowCount() {
      // 先判断是否为单数，如果是单数，提取最后一项
      if (this.tableData.length % 2 !== 0) {
        this.lastCount = this.tableData[this.tableData.length - 1];
        return Math.floor(this.tableData.length / 2); // 剩下的部分
      } else {
        this.lastCount = null;
        return Math.floor(this.tableData.length / 2); // 直接取偶数行数
      }
    },
    tableRows() {
      const rows = [];
      for (let i = 0; i < this.rowCount; i++) {
        rows.push([this.tableData[i * 2], this.tableData[i * 2 + 1]]);
      }
      return rows;
    }
  },
  created() {
    this.styleObject = this.tableStyle;
    if(this.showByRow !== undefined){
      this.s_showByRow = this.showByRow;
    }
  },
}
</script>

<style lang="scss" scoped>
.mailTable, .mailTable tr, .mailTable tr td {
  border-bottom: 1px solid #052f5a;
}
.mailTable {
  height: 48px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 16px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  border: 2px solid #4390DE;
}
.mailTable ::v-deep tr td {
  border-bottom: 1px solid #052f5a;
  width: 150px; height: 48px; 
  line-height: 48px; 
  box-sizing: border-box; 
  padding: 0 10px;
}
.mailTable ::v-deep tr td.column {
  background-color: #052f5a;
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 14px;
  color: #32C5FF;
  line-height: 16px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  border-bottom: 1px solid #052f5a;
  border-top: 1px solid #052f5a;
}
</style>
