<template>
  <table class="mailTable" :style="styleObject" border="0" cellspacing="0" cellpadding="0">
    <tr v-for="(item, index) in tableData" :key="index">
      <td class="column" style="width: 25%;">{{item.key}}</td>
      <td style="width: 75%;">{{item.value}}</td>
    </tr>
  </table>
</template>

<script>
export default {
  data() {
    return {
      styleObject: {},
    };
  },
  props: ['tableData', 'tableStyle'],
  created() {
    this.styleObject = this.tableStyle;
  },
}
</script>

<style lang="scss" scoped>
.mailTable, .mailTable tr, .mailTable tr td {
  border-bottom: 1px solid #052f5a;
}
.mailTable {
  height: 48px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 16px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  border: 2px solid #4390DE;
}
.mailTable ::v-deep tr td {
  border-bottom: 1px solid #052f5a;
  width: 150px; height: 48px; 
  line-height: 48px; 
  box-sizing: border-box; 
  padding: 0 10px;
}
.mailTable ::v-deep tr td.column {
  background-color: #052f5a;
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 14px;
  color: #32C5FF;
  line-height: 16px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  border-bottom: 1px solid #052f5a;
  border-top: 1px solid #052f5a;
}
</style>
