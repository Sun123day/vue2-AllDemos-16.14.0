<script>
import TableMerge from '../../tableTwoMergeOdd.vue';
import TableVertical from '../../tableVerticalOne.vue';
export default {
    components:{
      TableMerge,
      TableVertical,
    },
    props:{
      rowData: {
        type: Object,
        default: () => {
          return {}
        },
      },
    },
    data() {
        return {
          list1: [
              {key: '任务名称', value: 'xxx'},
              {key: '用户报修', value: 'xxx'},
              {key: '用户名称', value: 'xxx'},
              {key: '用户编码', value: 'xxx'},
              {key: '用户类型', value: 'xxx'},
              {key: '是否预约', value: '是'},
              {key: '抢险地址', value: '抢险地址大区街道小区单元栋'},
          ],
          list2: [
              {key: '气表校验口', value: ''},
              {key: '户内设施', value: '管道,阀门,接头'},
              {key: '户内设施', value: '管道,阀门,接头,气表'},
              {key: '事故', value: '爆炸,灼烧,中毒'},
              {key: '无气', value: '电磁阀切断,阀门切断'},
              {key: '气小', value: '渣堵,水堵,动火,事故'},
              {key: '恢复供气', value: '渣堵,水堵,动火'},
              {key: '气表更换', value: '到期'},
              {key: '失效表', value: '损换标,反表'},
              {key: '误报', value: '无人在家,误报'},
          ],
          list3: [
              {key: '常规处置', value: 'xxx1，xx2，'},
              {key: '其他(含事故现场)', value: '管道,阀门,接头'},
              {key: '检测', value: 'xxx'},
          ],

          // list1
          taskName: this.$props.rowData?.taskName || '-', // 任务名称
          repair: this.$props.rowData?.repair || '-', // 用户报修
          userName: this.$props.rowData?.userName || '-', // 用户名称
          userCode: this.$props.rowData?.userCode || '-', // 用户编码
          uerType: this.$props.rowData?.uerType || '-', // 用户类型
          order: this.$props.rowData?.order || '-', // 是否预约
          userAddress: this.$props.rowData?.userAddress || '-', // 抢险地址

          // list2

          // list3
          normalHand: this.$props.rowData?.normalHand || '-', // 常规处置
          otherHand: this.$props.rowData?.otherHand || '-', // 其他(含事故现场)
          detect: this.$props.rowData?.detect || '-', // 检测
        }
    },
    created(){
        this.initSetModal()
    },
    computed:{
      computedRow(){
        if(!this.rowData){
          // console.log("进入了");
          return {
              // list1
              "taskName": "", // 任务名称
              "repair": "", // 用户报修
              "userName": "", // 用户名称
              "userCode": "", // 用户编码
              "uerType": "", // 用户类型
              "order": "", // 是否预约
              "userAddress": "", // 抢险地址

              // list2
              "checkPoint": "", // 气表校验口
              "houseFacilities": "", // 户内设施
              "houseFacilitiesType": "", // 户内设施类型
              "accident": "", // 事故
              "noGas": "", // 无气
              "gasSmall": "", // 气小
              "recoveryGas": "", // 恢复供气
              "gasTableReplace": "", // 气表更换
              "invalidTable": "", // 失效表
              "misreport": "", // 误报

              // list3
              "normalHand": "", // 常规处置
              "otherHand": "", // 其他(含事故现场)
              "detect": "", // 检测
            }
        }
        else {
          // console.log("进入了2");
          return this.rowData
        }
      },

      // 提取 computedRow 中 list1 相关内容，并转换为 [{key, value}] 的格式
      computedList1() {
        // const row = this.computedRow;
        // return [
        //   { key: '任务名称', value: row.taskName },
        //   { key: '用户报修', value: row.repair },
        //   { key: '用户名称', value: row.userName },
        //   { key: '用户编码', value: row.userCode },
        //   { key: '用户类型', value: row.uerType },
        //   { key: '是否预约', value: row.order == "0" ? '是' : '否' }, // 假设 '0' 代表预约，其他表示不预约
        //   { key: '抢险地址', value: row.userAddress }
        // ];
        return [
          { key: '任务名称', value: this.taskName },
          { key: '用户报修', value: this.repair },
          { key: '用户名称', value: this.userName },
          { key: '用户编码', value: this.userCode },
          { key: '用户类型', value: this.uerType },
          { key: '是否预约', value: this.order == "0" ? '是' : '否' }, // 假设 '0' 代表预约，其他表示不预约
          { key: '抢险地址', value: this.userAddress }
        ];
      },
        // 提取 computedRow 中 list2 相关内容
      computedList2() {
        const row = this.computedRow;
        return [
          { key: '气表校验口', value: row.checkPoint },
          { key: '户内设施', value: row.houseFacilities || '-' },
          { key: '户内设施类型', value: row.houseFacilitiesType || '-' },
          { key: '事故', value: row.accident || '-' },
          { key: '无气', value: row.noGas || '-' },
          { key: '气小', value: row.gasSmall || '-' },
          { key: '恢复供气', value: row.recoveryGas || '-' },
          { key: '气表更换', value: row.gasTableReplace || '-' },
          { key: '失效表', value: row.invalidTable || '-' },
          { key: '误报', value: row.misreport || '-' }
        ];
      },

      // 提取 computedRow 中 list3 相关内容
      computedList3() {
        // const row = this.computedRow;
        // return [
        //   { key: '常规处置', value: row.normalHand },
        //   { key: '其他(含事故现场)', value: row.otherHand },
        //   { key: '检测', value: row.detect }
        // ];
        return [
          { key: '常规处置', value: this.normalHand },
          { key: '其他(含事故现场)', value: this.otherHand },
          { key: '检测', value: this.detect }
        ];
      }
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "正在办结预警详情");
            this.$emit("SetPageWidth", 750);
        },
    }
}
</script>
<template>
    <div class="content">
      <div>
        <span class="header-title">工单信息</span>
        <div class="table1">
          <TableMerge
            :tableData="computedList1"
            :tableStyle="{width: '100%',height: '200px'}"
          />
        </div>
      </div>
      <div>
        <span class="header-title">检查情况</span>
        <div class="table2">
          <TableVertical
            :tableData="computedList2" 
            :tableStyle="{width: '100%',height: '500px'}"
          />
        </div>
      </div>
      <div>
        <span class="header-title">处置结果</span>
        <div class="table3">
          <TableVertical
            :tableData="computedList3" 
            :tableStyle="{width: '100%',height: '150px'}"
          />
        </div>
      </div>
    </div>
</template>

<style lang="scss" scoped>
.content {
  margin-top: 28px;
  // height: 600px;
  position: relative;
  box-sizing: border-box;
}
.header-title {
  margin: 0 38px;
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 500;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
.table1 {
  height: 200px;
  margin: 0 38px;
  margin-bottom: 15px;
  margin-top: 10px;
}
.table2 {
  height: 500px;
  margin: 0 38px;
  margin-bottom: 15px;
  margin-top: 10px;
}
.table3 {
  height: 150px;
  margin: 0 38px;
  margin-bottom: 15px;
  margin-top: 10px;
}
</style>