<template>
    <div @click="detailClick" style="display: flex; align-items: center; justify-content: flex-start; gap: 5px;">
        <img src="~@/assets/image/cockpit/detail-icon.png" alt="" style="height: 13.4px; width: 13.4px; user-select: none !important;">
        <div style="color: #2AFFFF;">详情</div>
    </div>
</template>
<script>
    import DetailModal from './DetailModal.vue'
    export default {
        name: 'Operation',
        props: {
            rowData: {
                type: Object,
                default: () => {
                    return {}
                },
            },
        },
        inject: ['tableRoot'],
        methods: {
            detailClick() {
                new this.$pageModal(
                    DetailModal,
                    {
                        props: {
                            rowData: this.rowData
                        },
                    },
                    (result) => {
                    }
                )
            },
        },
    }
</script>
