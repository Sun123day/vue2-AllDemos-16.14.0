<script>
import { getQWeather } from '@/api/qWeather'
import { truncate } from 'lodash';

export default {
    name:'TopHeader',
    data(){
        return {
            timer:null,
            dateVal:'',
            dateTimeVal:'',
            weekVal:'',
            weatherTxt:'晴',
            weatherIcon:'100',
            weatherFlag: false
        }
    },
    created(){
        
        setTimeout(()=>{
            this.getWeather()
        },1000)
        this.timer=setInterval(()=>{
            const date=new Date();
            const year = date.getFullYear(); //当前年份
            const month = date.getMonth()+1; //当前月份
            const data = date.getDate(); //天
            const hours = date.getHours(); //小时
            const minute = date.getMinutes(); //分
            const second = date.getSeconds(); //秒
            const day = date.getDay(); //获取当前星期几 
            const ampm = hours < 12 ? 'am' : 'pm';
            this.dateVal=`${year}/${month}/${data}`
            this.dateTimeVal=`${this.fnW(hours)}:${this.fnW(minute)}:${this.fnW(second)}`
            this.weekVal=this.getMyDay(date)
        },1000)

    },
    beforeDestroy(){
        if(this.timer){
            clearInterval(this.timer)
            this.timer=null
        }
    },
    methods:{
        getWeather(){
            this.$nextTick(()=>{
                getQWeather().then(res=>{
                    // console.log("res和风天气", res);
                    if(res.code == 200){
                        this.weatherTxt = res.now.text || '晴'
                        this.weatherIcon = res.now.icon || '100'
                        this.weatherFlag = true
                    }
                })
            })
        },
        fnW(str){
            let num;
            str >= 10 ? num = str : num = "0" + str;
            return num;
        },
        getMyDay(date){
            let week;
            if(date.getDay()==0) week="星期日"
            if(date.getDay()==1) week="星期一"
            if(date.getDay()==2) week="星期二"
            if(date.getDay()==3) week="星期三"
            if(date.getDay()==4) week="星期四"
            if(date.getDay()==5) week="星期五"
            if(date.getDay()==6) week="星期六"
            return week;
        },
        homeClick(){
            // this.$router.push({ path: '/' })
        }
    }
}
</script>
<template>
    <div class="header-swaper">
        <div class="left-content">
            <div class="dateTimeBox">
                <!-- <i :class="`${weatherIcon}`" ></i> -->
                <!-- <i :class="`qi-${weatherIcon}`"></i> -->
                <img
                    :src="require(`@/assets/image/qweather/q-${weatherIcon}.png`)" 
                    alt=""
                    style="height: 24px; width: 24px;"
                >
                <span style="margin-left:0.5rem">{{ weatherTxt }}</span>
                <span style="margin-left:0.5rem">{{  dateVal }}</span>
                <span style="margin-left:0.5rem">{{ weekVal }}</span>
                <span style="margin-left:0.5rem">{{ dateTimeVal }}</span>
            </div>
        </div>
        <div class="right-centent">
            <img 
                src="~@/assets/image/cockpit/goBack.png" alt=""
                class="home-btn"
                @click="homeClick"
            >
        </div>
    </div>
</template>

<style lang="scss" scoped>
.header-swaper{
    position: relative;
    width: 100%;
    height: 104px;
    display: flex;
    
    justify-content: space-between;
    background-image:url("~@/assets/image/cockpit/top_header-bg.png");
    background-repeat: no-repeat;
    background-size: 100%;
    .left-content{
        flex: 1;
        height: 100%;
        margin-left: 27px;
        height: 55px;
        display: flex;
        align-items: flex-end;
        .dateTimeBox{
            display: flex;
            margin-right: 20px;
            align-items: center;
            
            font-weight: 500;
            color: #DBEAEA;
            font-size: 18px;
            line-height: 25px;
        }
    }
    .right-centent{
        flex: 1;
        height: 55px;
        display: flex;
        justify-content: flex-end;
        margin-right:27px;
        align-items: flex-end;
    }

    .home-btn{
        width: 146px;
        height: 40px;
        overflow: hidden;
        cursor: pointer;
    }
}
</style>