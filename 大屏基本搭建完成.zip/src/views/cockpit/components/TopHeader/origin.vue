<script>

export default {
    name:'TopHeader',
    data(){
        return {
            timer:null,
            dateVal:'',
            dateTimeVal:'',
            weekVal:''
        }
    },
    created(){
        this.timer=setInterval(()=>{
            const date=new Date();
            const year = date.getFullYear(); //当前年份
            const month = date.getMonth()+1; //当前月份
            const data = date.getDate(); //天
            const hours = date.getHours(); //小时
            const minute = date.getMinutes(); //分
            const second = date.getSeconds(); //秒
            const day = date.getDay(); //获取当前星期几 
            const ampm = hours < 12 ? 'am' : 'pm';
            this.dateVal=`${year}-${month}-${data}`
            this.dateTimeVal=`${this.fnW(hours)}:${this.fnW(minute)}:${this.fnW(second)}`
            this.weekVal=this.getMyDay(date)
        },1000)
    },
    beforeDestroy(){
        if(this.timer){
            clearInterval(this.timer)
            this.timer=null
        }
    },
    methods:{
        fnW(str){
            let num;
            str >= 10 ? num = str : num = "0" + str;
            return num;
        },
        getMyDay(date){
            let week;
            if(date.getDay()==0) week="周日"
            if(date.getDay()==1) week="周一"
            if(date.getDay()==2) week="周二"
            if(date.getDay()==3) week="周三"
            if(date.getDay()==4) week="周四"
            if(date.getDay()==5) week="周五"
            if(date.getDay()==6) week="周六"
            return week;
        },
        homeClick(){
            this.$router.push({ path: '/' })
        }
    }
}
</script>
<template>
    <div class="header-swaper">
        <div class="left-content">
            <img src="~@/assets/hr_logo.png" style="height:38px;"/>
            <div class="line"/>
            <img src="~@/assets/sh_logo.png" style="height:38px;"/>

        </div>
        <div class="center-title">双鹤华利能效管理系统驾驶舱</div>
        <div class="right-centent">
            <div class="dateTimeBox">
                <span>{{  dateVal }}</span>
                <span style="margin-left:0.5rem">{{ dateTimeVal }}</span>
                <span style="margin-left:0.5rem">{{ weekVal }}</span>
            </div>
            <div class="home-btn" @click="homeClick">
                <span>{{'进入系统 >>'}}</span>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
.header-swaper{
    position: relative;
    width: 100%;
    height: 86px;
    display: flex;
    
    justify-content: space-between;
    background-image:url("~@/assets/image/cockpit/top_header-bg.png");
    background-repeat: no-repeat;
    background-size: 100%;
    .left-content{
        flex: 1;
        height: 100%;
        margin-left: 15px;
        height: 50px;
        display: flex;
        align-items: center;
        .line{
            height: 38px;
            width: 1px;
            background: #fff;
            margin-left: 10px;
            margin-right: 10px;
            opacity: 0.4;
        }
    }
    .right-centent{
        flex: 1;
        height: 50px;
        display: flex;
        font-weight: 500;
        color: #DBEAEA;
        font-size: 18px;
        line-height: 25px;
        justify-content: flex-end;
        margin-right:15px;
        align-items: center;
        .dateTimeBox{
            display: flex;
           margin-right: 20px;
        }
    }
    .center-title{
        font-weight: 600;
        color: #5EBCFF;
        line-height: 39px;
        letter-spacing: 10px;
        font-size: 32px;
        align-items: center;
        display: flex;
    }

    .home-btn{
        width: 98px;
        height: 34px;
        background: #F59A23;
        border-radius: 4px;
        overflow: hidden;
        cursor: pointer;
        color: #FFFFFF;
        font-size: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 1;
        transition: all 0.3s;
    }
    .home-btn:hover{
        opacity:0.6;
    }
}
</style>