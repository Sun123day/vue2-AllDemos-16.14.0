<template>
  <div>
      <div class="sub-title-container">
          <span class="title">网格风险</span>
          <img class="btn" src="~@/assets/image/cockpit/more-btn.png" alt="" @click="handleMoreClick">
      </div>
      <div class="table">
        <RlTable
            :is-pagination="false"
            @on-change="loadTbaleData"
            :search="false"
            ref="rltable"
        >
            <template #default>
                <el-table-column prop="communityName" label="社区" :show-overflow-tooltip="true" />
                <el-table-column prop="gridName" label="网格" :show-overflow-tooltip="true" />
                <el-table-column prop="riskNum" label="风险数量" />
                <el-table-column prop="headName" label="网格长" :show-overflow-tooltip="true" />
                <el-table-column label="操作" width="100">
                    <template slot-scope="scope">
                        <Operation :rowData="scope.row"/>
                    </template>
                </el-table-column>
            </template>
        </RlTable>
      </div>
  </div>
</template>

<script>
import Operation from './components/Operation.vue'
import MoreForm from './components/MoreForm.vue'
import { getGridList } from '@/api/cockpitNew'
export default {
    components: {
      Operation,
      MoreForm,
    },
    // mounted() {
    //   // 设置定时器，每10秒调用一次
    //   this.intervalId = setInterval(() => {
    //     this.handleSearch();
    //   }, 10000); // 10000毫秒 = 10秒
    // },
    // beforeDestroy() {
    //   // 清理定时器
    //   if (this.intervalId) {
    //     clearInterval(this.intervalId);
    //   }
    // },
    methods: {
        handleSearch(){
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        loadTbaleData({resolve,params}){
          
          // resolve({
          //             records:[
          //               {communityName: '春熙路街道', special: '1',urgency: '1',normal: '1'},
          //               {communityName: '书院街道', special: '1',urgency: '1',normal: '1'},
          //               {communityName: '东湖街道', special: '1',urgency: '1',normal: '1'},
          //             ],
          //             total:0
          //         })
          getGridList(params).then((res) => {
              if(res.code=='200'){
                  const resData=res.data||{}
                  resolve({
                      records:resData||[],
                      total:0
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
        handleMoreClick() {
          new this.$pageModal(
            MoreForm,
            {
                props:{
                  
                },
            },
            (result)=>{
                
            }
          )
        }
    }


}
</script>

<style lang="scss" scoped>
.sub-title-container {
    margin-bottom: 7px;
    width: 620px;
    height: 30px;
    background-image: url('~@/assets/image/cockpit/sub-title-container.png');
    background-size: 620px 30px;
    background-repeat: no-repeat;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .title {
      height: 26px;
      font-family: YouSheBiaoTiHei, YouSheBiaoTiHei;
      font-weight: 400;
      font-size: 19px;
      color: #CFEAFF;
      line-height: 0;
      letter-spacing: 1px;
      text-align: left;
      font-style: normal;
      text-transform: none;
      padding-left: 43px;
    }
    .btn {
      width: 67px;
      height: 30px;
    }
}
.table {
  height: 240px;
  width: 620px;
  position: relative;
  border: 2px solid #4390DE;
}

::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
::v-deep .el-table--scrollable-y .el-table__body-wrapper {
  overflow: hidden !important;

}
</style>