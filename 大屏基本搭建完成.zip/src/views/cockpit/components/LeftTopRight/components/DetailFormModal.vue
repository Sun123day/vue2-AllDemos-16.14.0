<script>
import DetailOperation from './DetailOperation.vue'
import TableComponent from './tableComponent.vue'
import { getGridDetailRiskPageList } from '@/api/cockpitNew'
export default {
    components:{
        DetailOperation,
        TableComponent
    },
    props:{
      rowData: {
        type: Object,
      },
    },
    data() {
        return {
          userName: '',
          list1: [
              // {key: '网格名称', value: '1001'},
              // {key: '所属社区', value: '总府路社区'},
              // {key: '所属街道', value: '篮球'},
              // {key: '所属区县', value: '锦江区'},
              // {key: '网格长', value: '120.00'},
              // {key: '联系电话', value: '143xxxxxxxx'},
              // 网格员先不做，没确定
              // {key: '网格员', value: '2017-03-01'},
              // {key: '联系电话', value: '143xxxxxxxx'},
          ],
          list2: [
            // {street: '2024-11-7', special: '类型1', urgency: '描述1', addr:'地址1'},
            // {street: '2024-11-7', special: '类型1', urgency: '描述1', addr:'地址1'},
            // {street: '2024-11-7', special: '类型1', urgency: '描述1', addr:'地址1'},
            // {street: '2024-11-7', special: '类型1', urgency: '描述1', addr:'地址1'},
          ],
          gridId: this.$props.rowData?.gridId || '-',
          gridName: this.$props.rowData?.gridName || '-',
          communityName: this.$props.rowData?.communityName || '-',
          streetName: this.$props.rowData?.streetName || '-',
          areaName: this.$props.rowData?.areaName || '-',
          headName: this.$props.rowData?.headName || '-',
          headTel: this.$props.rowData?.headTel || '-',
        }
    },
    created(){
        this.initSetModal()
        // console.log("详情界面", this.rowData);
    },
    computed:{
      computedList1() {
        return [
          {key: '网格名称', value: this.gridName},
          {key: '所属社区', value: this.communityName},
          {key: '所属街道', value: this.streetName},
          {key: '所属区县', value: this.areaName},
          {key: '网格长', value: this.headName},
          {key: '联系电话', value: this.headTel},
        ]
      },
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "网格详情");
            this.$emit("SetPageWidth", 900);
        },
        loadTbaleData({resolve,params}){
          // resolve({
          //             records:this.list2,
          //             total:this.list2.length
          //         })
          params.condition = {
            gridId: this.gridId,
            userName: this.userName,  
          }
          getGridDetailRiskPageList(params).then((res) => {
              if(res.code=='200'){
                  const resData=res.data||[]
                  resolve({
                      records:resData.records||[],
                      total:resData.total
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
        handleSearch()  {
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        handleReset() {
          this.userName = ''
          this.handleSearch()
        },
    }
}
</script>

<template>
    <div class="container">
      <div class="first-header">
        网格信息
      </div>
      <div class="first-table">
        <TableComponent 
          :tableData="computedList1" 
          :tableStyle="{width: '100%',height: '160px'}"
        />
      </div>
      <div class="second-header">
        <div class="searchItem">
          <el-input
              v-model="userName"
              placeholder="请输入用户名称"
              size="small"
              style="width: 160px"
              clearable
              class="searchInput"
          />
          <!-- <img
            src="~@/assets/image/cockpit/grid_detail_search_btn.png"
            alt=""
            class="searchIcon"
            @click="handleSearch"
          /> -->
          <img class="btn" src="~@/assets/image/cockpit/search-btn.png" alt="" @click="handleSearch">
          <img class="btn" src="~@/assets/image/cockpit/reset-btn.png" alt="" @click="handleReset">
          
        </div>
      </div>
      <div class="second-table">
        <RlTable
            :is-pagination="true"
            @on-change="loadTbaleData"
            :search="false"
            ref="rltable"
        >
          <template #default>
                <el-table-column prop="riskCategory" label="风险类别"  width="100" />
                <el-table-column prop="riskDesc" label="风险描述" :show-overflow-tooltip="true" />
                <el-table-column prop="name" label="用户名称" :show-overflow-tooltip="true" />
                <el-table-column prop="address" label="用户地址" :show-overflow-tooltip="true" />
                <el-table-column label="操作" width="100">
                    <template slot-scope="scope">
                        <DetailOperation :rowData="scope.row"/>
                    </template>
                </el-table-column>
          </template>
        </RlTable>
      </div>
    </div>
</template>

<style lang="scss" scoped>
.first-table {
  // height: 160px;
  height: 200px;
  position: relative;
  box-sizing: border-box;
  margin-bottom: 20px;
}
.first-header {
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 500;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  margin-bottom: 10px;
}
// .searchInput ::v-deep .el-input__inner {
//   border: none !important;
// }
.searchIcon {
  width: 18px;
  height: 18px;
  margin: 0 12px;
}
::v-deep .el-input__inner {
  border-radius: 0 !important;
  border: 1px solid #4390DE;
}
.second-header {
  height: 56px;
  display: flex;
  justify-content: flex-end;

  .searchItem {
    height: 36px;
    display: flex;
    align-items: center;
    // border: 1px solid #4390DE;
  }
}
.second-table {
  height: 320px;
  position: relative;
  box-sizing: border-box;
  border: 2px solid #4390DE;
}
::v-deep .el-input--small .el-input__inner {
  height: 36px !important;
  line-height: 36px !important;
}
::v-deep .el-form-item__label {
  line-height: 36px !important;
}
::v-deep .el-form--inline .el-form-item {
  margin: 0 !important;
}
.btn {
  width: 67px;
  height: 36px;
  margin-left: 11px;
}
.container {
  // height: 656px;
  margin: 0 57px;
  margin-top: 27px;
}
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
// ::v-deep .el-table--scrollable-y .el-table__body-wrapper {
//   overflow: hidden !important;

// }
</style>