<template>
  <!-- <div @click="detailClick" style="display: flex; align-items: center; justify-content: flex-start;">
      <img src="~@/assets/image/cockpit/grid_detail_op_btn.png" alt="" style="height: 13.4px; width: 13.4px; user-select: none !important;">
  </div> -->
    <Space>
        <el-tooltip class="item" effect="light" content="定位" placement="bottom-start">
            <img
                src="~@/assets/image/cockpit/grid_detail_op_btn.png"
                style="width: 13.4px; height: 13.4px;"
                @click="detailClick"
            />
        </el-tooltip>
    </Space>
</template>
<script>
  // import DetailFormModal from './DetailFormModal.vue'
  export default {
      name: 'Operation',
      props: {
          rowData: {
              type: Object,
              default: () => {
                  return {}
              },
          },
      },
      inject: ['tableRoot'],
      methods: {
          detailClick() {
              // new this.$pageModal(
              //     DetailFormModal,
              //     {
              //         props: {

              //         },
              //     },
              //     (result) => {

              //     }
              // )
          },
      },
  }
</script>
