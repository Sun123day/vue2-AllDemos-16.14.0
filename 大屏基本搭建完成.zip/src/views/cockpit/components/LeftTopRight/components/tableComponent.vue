<template>
  <table class="mailTable" :style="styleObject" v-if="s_showByRow"  border="0" cellspacing="0" cellpadding="0">
    <tr v-for="index in rowCount">
      <td class="column">{{tableData[index*2-2].key}}</td>
      <td>{{tableData[index*2-2].value}}</td>
      <td class="column">{{tableData[index*2-1] !== undefined ? tableData[index*2-1].key : ''}}</td>
      <td>{{tableData[index*2-1] !== undefined ? tableData[index*2-1].value : ''}}</td>
    </tr>
  </table>
  <table class="mailTable" :style="styleObject" v-else border="0" cellspacing="0" cellpadding="0">
    <tr v-for="index in rowCount">
      <td class="column">{{tableData[index-1].key}}</td>
      <td>{{tableData[index-1].value}}</td>
      <td class="column">{{tableData[rowCount+index-1] !== undefined ? tableData[rowCount+index-1].key : ''}}</td>
      <td>{{tableData[rowCount+index-1] !== undefined ? tableData[rowCount+index-1].value : ''}}</td>
    </tr>
  </table>
</template>

<script>
export default {
  data() {
    return {
      styleObject: {},
      s_showByRow: true,
    };
  },
  props: ['tableData', 'tableStyle', 'showByRow'],
  computed: {
    rowCount: function() {
      return Math.ceil(this.tableData.length/2);
    }
  },
  created() {
    this.styleObject = this.tableStyle;
    if(this.showByRow !== undefined){
      this.s_showByRow = this.showByRow;
    }
  },
}
</script>

<style lang="scss" scoped>
.mailTable, .mailTable tr, .mailTable tr td {
  // border:1px solid #E6EAEE;
  // border: 1px solid #4390DE;
  border-bottom: 1px solid #052f5a;
}
.mailTable {
  // font-size: 12px;
  // color: #71787E;
  // height: 20px;
  height: 48px;
  font-family: PingFang SC, PingFang SC;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
  line-height: 16px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  border: 2px solid #4390DE;
}
.mailTable ::v-deep tr td {
  // border:1px solid #E6EAEE; 
  // border: 1px solid #4390DE;
  border-bottom: 1px solid #052f5a;
  width: 150px; height: 48px; 
  line-height: 48px; 
  box-sizing: border-box; 
  padding: 0 10px;
}
.mailTable ::v-deep tr td{
  // border-bottom: 1px solid rgba(67,144,222,0.2);
  // border-bottom: 1px solid #052f5a;
  // border-top: 1px solid #052f5a;
  // border-right: 1px solid #4390DE;
}
.mailTable ::v-deep tr td.column {
  // background-color: #EFF3F6; 
  // background: linear-gradient( #14569A 0%, #022549 100%);
  background-color: #052f5a;
  // color: #393C3E; 
  height: 20px;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 14px;
  color: #32C5FF;
  line-height: 16px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  border-bottom: 1px solid #052f5a;
  border-top: 1px solid #052f5a;
}
</style>
