<script>
import Operation from './Operation.vue'
import { getGridPageList } from '@/api/cockpitNew'
export default {
    components:{
      Operation,
    },
    data() {
        return {
          name: '',
          // list:[
          //   {street: '2024-11-7', special: '类型1',urgency: '描述1'},
          //   {street: '2024-11-7', special: '类型1',urgency: '描述1'},
          //  ]
        }
    },
    created(){
        this.initSetModal()
    },
    methods:{
        initSetModal() {
            this.$emit("SetTitle", "风险列表");
            this.$emit("SetPageWidth", 900);
        },
        loadTbaleData({resolve,params}){
          // resolve({
          //             records:this.list,
          //             total:this.list.length
          //         })
          params.condition = this.name,
          getGridPageList(params).then((res) => {
              if(res.code=='200'){
                  const resData=res.data||{}
                  resolve({
                      records:resData.records||[],
                      total:resData.total
                  })
              }else{
                  resolve({
                      records:[],
                      total:0
                  })
              }
            });
        },
        handleSearch() {
            this.$nextTick(() => {
              const rltable = this.$refs.rltable
              if(rltable){
                rltable.onSearchChange()
              }
            })
        },
        handleReset() {
          this.name = ''
          this.handleSearch()
        },
    }
}
</script>

<template>
    <div class="container">
      <div class="header">
        <el-form inline class="searchItem">
          <el-form-item label="网格名称：">
              <el-input
                  v-model="name"
                  placeholder="请输入网格名称"
                  size="small"
                  style="width: 160px"
                  clearable
              />
          </el-form-item>
          <el-form-item style="margin-left: 26px !important;">
            <img class="btn" src="~@/assets/image/cockpit/search-btn.png" alt="" @click="handleSearch">
            <img class="btn" src="~@/assets/image/cockpit/reset-btn.png" alt="" @click="handleReset">
          </el-form-item>
        </el-form>
      </div>
      <div class="table">
        <RlTable
            :is-pagination="true"
            @on-change="loadTbaleData"
            :search="false"
            ref="rltable"
        >
            <!-- :resizeH="false" -->
          <template #default>
                <el-table-column type="index" label="序号"  width="80" />
                <el-table-column prop="communityName" label="社区" :show-overflow-tooltip="true" />
                <el-table-column prop="gridName" label="网格" :show-overflow-tooltip="true" />
                <el-table-column prop="riskNum" label="风险数量" :show-overflow-tooltip="true" />
                <el-table-column prop="headName" label="网格长" :show-overflow-tooltip="true" />
                <el-table-column label="操作" width="100">
                    <template slot-scope="scope">
                        <Operation :rowData="scope.row"/>
                    </template>
                </el-table-column>
          </template>
        </RlTable>
      </div>
    </div>
</template>

<style lang="scss" scoped>
::v-deep .el-input__inner {
  border-radius: 0 !important;
  border: 1px solid #4390DE;
}
.header {
  height: 56px;
  .searchItem {
    height: 36px;
  }
}
.table {
  height: 600px;
  position: relative;
  box-sizing: border-box;
}
::v-deep .el-input--small .el-input__inner {
  height: 36px !important;
  line-height: 36px !important;
}
::v-deep .el-form-item__label {
  line-height: 36px !important;
}
::v-deep .el-form--inline .el-form-item {
  margin: 0 !important;
}
.btn {
  width: 67px;
  height: 36px;
  margin-left: 11px;
}
.container {
  // height: 656px;
  margin: 0 57px;
  margin-top: 27px;
}
::v-deep .rltable {
  padding: 0 !important;
  border-radius: 0 !important;
  .rltable-head {
    margin: 0 !important;
  }
}
::v-deep .el-table th.el-table__cell {
  background: linear-gradient(#022549 0%, #14569A 100%) !important;
  height: 24px !important;
}
::v-deep .el-table th.el-table__cell > .cell {
  height: 40px !important;
  font-family: PingFang SC, PingFang SC;
  font-weight: bold;
  font-size: 16px !important;
  color: #32C5FF;
  line-height: 40px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
::v-deep .el-table--small .el-table__cell {
  padding: 0!important;
}
::v-deep .el-table tr {
  height: 40px !important;
}
::v-deep .el-table__body-wrapper.is-scrolling-none table.el-table__body {
  width: 100% !important;
}
// ::v-deep .el-table--scrollable-y .el-table__body-wrapper {
//   overflow: hidden !important;

// }
</style>