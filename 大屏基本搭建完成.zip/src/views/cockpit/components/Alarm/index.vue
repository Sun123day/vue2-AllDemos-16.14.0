<template>
  <div class="alarm-container">
      <div class="alarm-card">
          <img class="alarm-img" src="~@/assets/image/cockpit/alarm.png" alt="">
          <div class="alarm-txt">累计告警</div>
          <div class="alarm-num">{{ total }}</div>
      </div>
      <div class="alarm-card">
          <img class="alarm-img" src="~@/assets/image/cockpit/alarm.png" alt="">
          <div class="alarm-txt">当前告警</div>
          <div class="alarm-num">{{ now }}</div>
      </div>
  </div>
</template>

<script>
export default {
  props: {
    total: {
      type: Number,
      default: 0
    },
    now: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {

    }
  },
  computed:{
    
  }
}
</script>

<style lang="scss" scoped>
.alarm-container {
    z-index: 10;
    height: 58px;
    padding: 7px 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 30px;
    border: 1px solid #F3723B;
    border-radius: 2px;
    background-color: rgba(0, 25, 69, 0.72);
    position: fixed;
    top: 104px;
    left: 52%;
    .alarm-card {
        display: flex;
        align-items: center;
        gap: 6px;
        .alarm-img {
            width: 47px;
            height: 42px;
        }
        .alarm-txt {
            width: 56px;
            height: 19px;
            font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
            font-weight: 500;
            font-size: 14px;
            color: #FFFFFF;
            line-height: 16px;
            text-align: left;
            font-style: normal;
            text-transform: none;
        }
        .alarm-num {
            height: 39px;
            font-family: DINPro, DINPro;
            font-weight: bold;
            font-size: 30px;
            color: #FF0000;
            line-height: 35px;
            text-align: left;
            font-style: normal;
            text-transform: none;
        }
    }
}
</style>