<script>
    import Logo from './logo.vue'
    import LoginForm from './LoginForm.vue'
    export default {
        components: {
            Logo,
            LoginForm,
        },
    }
</script>
<template>
    <div class="login-page">
        <Logo />
        <div class="background_img">
            <img src="~@/assets/image/login/login_back.png" alt />
        </div>
        <div class="login-form-box">
            <LoginForm />
        </div>
        <div class="footerBox">
            <img src="~@/assets/image/login/footer.png" alt />
        </div>
    </div>
</template>
<style lang="scss" scoped>
    .login-page {
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        top: 0;
        overflow: hidden;
        background-image: url('~@/assets/image/login/login-background.png');
        background-size: 100% 100%;
        background-size: cover;

        .footerBox {
            position: absolute;
            width: 100%;
            bottom: 0;
            z-index: 1;
            img {
                width: 100%;
            }
        }

        .background_img {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 8.5%;
            z-index: 10;
            width: calc(100vw * 889 / 1920);
            height: calc(100vw * 680 / 1920);
            min-width: 586px;
            min-height: 458px;
            margin: auto;
            img {
                width: 100%;
            }
        }

        .login-form-box {
            border-radius: 6px;
            background: #ffffff;
            width: calc(100vw * 468 / 1920);
            height: calc(100vh * 520 / 1080);
            min-width: 360px;
            min-height: 454px;
            position: absolute;
            top: 0;
            bottom: 0;
            left: 63%;
            z-index: 10;
            margin: auto;
            padding: 0px calc(100vw * 50 / 1920) 0px calc(100vw * 50 / 1920);
        }
    }

    .background_img {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 8.5%;
        z-index: 10;
        width: calc(100vw * 889 / 1920);
        height: calc(100vw * 680 / 1920);
        min-width: 586px;
        min-height: 458px;
        margin: auto;
        img {
            width: 100%;
        }
    }

    .login-form-box {
        border-radius: 6px;
        background: #ffffff;
        width: calc(100vw * 468 / 1920);
        height: calc(100vh * 520 / 1080);
        min-width: 360px;
        min-height: 454px;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 63%;
        z-index: 10;
        margin: auto;
        padding: 0px calc(100vw * 50 / 1920) 0px calc(100vw * 50 / 1920);
    }
</style>
