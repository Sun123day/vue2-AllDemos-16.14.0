<script>
    export default {}
</script>
<template>
    <div class="logoWrapper">
        <img class="logoImg" src="~@/assets/hr_logo.png" alt />
        <div class="line" />
        <img class="shLogoImg" src="~@/assets/sh_logo.png" alt />
    </div>
</template>

<style lang="scss" scoped>
    .logoWrapper {
        position: absolute;
        top: 50px;
        left: 80px;
        display: inline-flex;
        align-items: center;
        height: 46px;
        z-index: 99;
        .logoImg {
            height: 100%;
        }
        .line {
            width: 1px;
            height: 100%;
            background: #ffffff;
            margin-left: 10px;
            margin-right: 10px;
        }
        .shLogoImg {
            width: 24px;
            width: 107px;
        }
    }
</style>
