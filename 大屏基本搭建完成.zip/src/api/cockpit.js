/***
 * @description 大屏接口
 */

import request from '@/utils/request'

/**
 * @function: 近12个月能耗
 * @param {*} params
 * @return {*}
 */
export function energyMonthsBar(params) {
    return request({
        url: '/screen/months',
        method: 'POST',
        data: params || {},
    })
}

/**
 * @function: 能耗占比
 * @param {*} params
 * @return {*}
 */
export function energyRatePie(params) {
    return request({
        url: '/screen/proportion',
        method: 'POST',
        data: params || {},
    })
}

/**
 * @function: 能耗排名
 * @param {*} params
 * @return {*}
 */
export function energyRankPie(params) {
    return request({
        url: '/screen/rank',
        method: 'POST',
        data: params || {},
    })
}
/**
 * @function: 年度能耗统计
 * @param {*} params
 * @return {*}
 */
export function energyYearStatics(params) {
    return request({
        url: '/screen/statics',
        method: 'POST',
        data: params || {},
    })
}

/**
 * @function: 告警数据统计
 * @param {*} params
 * @return {*}
 */
export function alarmStatics(params) {
    return request({
        url: '/screen/alarm/statics',
        method: 'POST',
        data: params || {},
    })
}

/**
 * @function: 实时负荷
 * @param {*} params
 * @return {*}
 */
export function poewerRequest(params) {
    return request({
        url: '/screen/power',
        method: 'POST',
        data: params || {},
    })
}

/**
 * @function: 关键设备参数
 * @param {*} params
 * @return {*}
 */
export function equipmentRequest(params) {
    return request({
        url: '/screen/key/equipment',
        method: 'POST',
        data: params || {},
    })
}

/**
 * @function: iot设备统计
 * @param {*} projectId
 * @return {*}
 */
export function deviceStatusRequest(projectId) {
    return request({
        url: `/screen/iot-status/${projectId}`,
        method: 'GET',
    })
}

/**
 * @function: 年度能耗统计
 * @param {*} params
 * @return {*}
 */
export function subPointRequest(params) {
    return request({
        url: '/screen/sort/statics',
        method: 'POST',
        data: params || {},
    })
}

/**
 * @function: 根据项目id查询能耗费用
 * @param {*} projectId
 * @return {*}
 */
export function energyAmountRequest(projectId) {
    return request({
        url: `/screen/energy-amount/${projectId}`,
        method: 'GET',
    })
}

export function getComprehensiveProportion(data) {
    return request({
        url: `/screen/comprehensive-proportion`,
        method: 'POST',
        data,
    })
}
