import request from '@/utils/request'

// 右下右-停气通知
export function getStopGasNotice() {
    return request({
        url: '/notice/gas',
        method: 'GET',
    })
}
// 右下右-停气通知列表
export function getStopGasNoticePageList(params) {
    return request({
        url: '/notice/gas/list-page',
        method: 'POST',
        data: params || {},
    })
}

// 右中右-预警类型
export function getAlarmType(start, end) {
    return request({
        url: `/security-check/type?start=${start}&end=${end}`,
        method: 'GET',
    })
}

// 右中左-设备概况
export function getDeviceType(start, end) {
    return request({
        url: `/device?start=${start}&end=${end}`,
        method: 'GET',
    })
}

// 左下右下-三种用户类型统计
export function getRiskUserType() {
    return request({
        url: '/risk/user-type',
        method: 'GET',
    })
}

// 左下右下-三种用户类型统计分页
export function getRiskUserTypePageList(params) {
    return request({
        url: '/risk/user-type',
        method: 'POST',
        data: params || {},
    })
}

// 左下右上-相邻空间根据类别获取名称下拉
export function getSpaceCollectName(category) {
    return request({
        url: `/space/list?category=${category}`,
        method: 'GET',
    })
}

// 左下右上-相邻空间分页
export function getSpaceCollectPageList(params) {
    return request({
        url: '/space/collect/list-page',
        method: 'POST',
        data: params || {},
    })
}
// 左下左上-管线-管线类型
export function getPipelineType() {
    return request({
        url: `/pipeline/type`,
        method: 'GET',
    })
}

// 左下左上-管线-管线年限
export function getPipelineLife(type) {
    return request({
        url: `/pipeline/life?type=${type}`,
        method: 'GET',
    })
}

// 左下左上-管线-管线材质
export function getPipelineMaterial() {
    return request({
        url: `/pipeline/material`,
        method: 'GET',
    })
}


// 左下左上-场站获取场站下拉
export function getStationCollectName() {
    return request({
        url: `/Station/list`,
        method: 'GET',
    })
}

// 左下左上-场站分页
export function getStationCollectPageList(params) {
    return request({
        url: '/Station/collect/list-page',
        method: 'POST',
        data: params || {},
    })
}

// 左下上排燃气风险分类数量
export function getRiskCount(areaId) {
    return request({
        url: `/risk/count?areaId=${areaId}`,
        method: 'GET',
    })
}

// 左下左下-设备类型（设施类、热水器类、灶具类、燃气具连接用软管类）数量
export function getFacilityCount(areaId) {
    return request({
        url: `/hidden_danger/facility?areaId=${areaId}`,
        method: 'GET',
    })
}
// 左下左下-设备类型（设施类、热水器类、灶具类、燃气具连接用软管类）分页
export function getFacilityPageList(params) {
    return request({
        url: '/hidden_danger/list-page',
        method: 'POST',
        data: params || {},
    })
}

// 左下右上-管线包裹占压分页
export function getPipelineDangerPageList(params) {
    return request({
        url: '/pipeline-danger',
        method: 'POST',
        data: params || {},
    })
}

// 左中左-预警数量占比环比统计
export function getSecurityCheckStatistics() {
    return request({
        url: '/security-check/statistics',
        method: 'GET',
    })
}

// 左中右-预警类型显示
export function getSecurityCheckStatus(params) {
    return request({
        url: '/security-check/status',
        method: 'POST',
        data: params || {},
    })
}

// 左中右-预警类型显示更多分页
export function getSecurityCheckStatusPageList(params) {
    return request({
        url: '/security-check/status/more',
        method: 'POST',
        data: params || {},
    })
}

// 左上左-居民/工商业总数
export function getUserCount(category) {
    return request({
        url: `/user/count?category=${category}`,
        method: 'GET',
    })
}

// 左中左-居民/工商业统计
export function getUserStatistics(category) {
    return request({
        url: `/user/statistics?category=${category}`,
        method: 'POST',
    })
}

// 左上右-网格全部
export function getGridList() {
    return request({
        url: '/grid/list',
        method: 'GET',
    })
}

// 左上右-网格更多分页
export function getGridPageList(params) {
    return request({
        url: '/grid/list-page',
        method: 'POST',
        data: params || {},
    })
}

// 左上右-网格详情中的搜索表格【对应风险】
export function getGridDetailRiskPageList(params) {
    return request({
        url: '/grid/risk/list-page',
        method: 'POST',
        data: params || {},
    })
}

// 右上-上门安检
export function getHiddenDangerVisit(params) {
    return request({
        url: "/hidden_danger/check",
        method: 'POST',
        data: params || {},
    })
}

// 右上-其他（隐患来源）
export function getHiddenDangerElse(params) {
    return request({
        url: "/hidden_danger/dangerFrom",
        method: 'POST',
        data: params || {},
    })
}

// 右上-到访不遇
export function getHiddenDangerNoPerson(params) {
    return request({
        url: "/hidden_danger/userType",
        method: 'POST',
        data: params || {},
    })
}

// 应急值守
export function getEmergencyDuty(areaId) {
    return request({
        url: `/emergency/duty?areaId=${areaId}`,
        method: 'GET',
    })
}

// 抢险信息
export function getEmergencyInfo(areaId) {
    return request({
        url: `/emergency/statistics?areaId=${areaId}`,
        method: 'GET',
    })
}

// 抢险信息——应急值班弹窗
export function getEmergencyDutyMore(params) {
    return request({
        url: '/emergency/duty/more',
        method: 'POST',
        data: params || {},
    })
}

// 抢险信息——抢险车辆弹窗
export function getEmergencyCarMore(params) {
    return request({
        url: '/emergency/car/more',
        method: 'POST',
        data: params || {},
    })
}

// 抢险信息——抢险人员弹窗
export function getEmergencyPersonMore(params) {
    return request({
        url: '/emergency/person/more',
        method: 'POST',
        data: params || {},
    })
}
