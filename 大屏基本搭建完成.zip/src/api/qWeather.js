import request from '@/utils/request'
// 天气查询
export function getQWeather() {
  const key= 'eaa681e474d943a19b6313949394a41f'
  // const location = '成都' // 查询城市时
  const location = '101270101' // 查询天气时
  // const location = 'Chengdu' // 查询天气时
  return request({
    // 查询天气
    // url: `https://devapi.qweather.com/v7/weather/now?location=${location}&key=${key}&gzip=n`,
    url: `https://devapi.qweather.com/v7/weather/now?location=${location}&key=${key}`,
    
    // 查询城市
    // url: `https://geoapi.qweather.com/v2/city/lookup?location=${location}&key=${key}`,
    method: 'GET',
  })
}