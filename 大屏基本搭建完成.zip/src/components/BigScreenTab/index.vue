<template>
  <div class="tabs-container">
      <div
          v-for="item in sourceData"
          :key="item.code"
          :class="[
              'item',
              {
                  active: value === item.code,
              },
          ]"
          @click="handleClickItem(item)"
      >
          <span class="text">{{ item.text }}</span>
      </div>
  </div>
</template>

<script>
  export default {
      props: {
          value: String,
          sourceData: {
              type: Array,
              default: () => [],
          },
      },
      methods: {
          handleClickItem({ code }) {
              this.$emit('input', code)
              this.$emit('change', code)
          },
      },
  }
</script>
<style lang="scss" scoped>
  .tabs-container {
      display: inline-flex;
      // border-radius: 4px;
      background: #062E58;
      border: 1px solid #4390DE;
      height: 36px;
      .item {
          color: #fff;
          display: inline-flex;
          justify-content: center;
          align-items: center;
          padding: 8px 10px;
          width: 92px;

          cursor: pointer;
          .text {
              display: inline-block;
              // padding-right: 10px;

              font-family: PingFang SC, PingFang SC;
              font-weight: 400;
              font-size: 16px;
              line-height: 19px;
              text-align: center;
              font-style: normal;
              text-transform: none;
          }
          &.active,
          &:hover {
              background: rgba(255,240,0,0.1);
              box-shadow: inset 0px 0px 9px 3px rgba(255,240,0,0.5);
              border-radius: 0px 0px 0px 0px;
              border: 1px solid #FFF000;

              font-family: PingFang SC, PingFang SC;
              font-weight: bold;
              font-size: 16px;
              color: #FFF000;
              line-height: 19px;
              text-align: center;
              font-style: normal;
              text-transform: none;
          }
      }
  }
</style>
