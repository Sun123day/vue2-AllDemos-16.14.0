module.exports = {
    plugins: {
        autoprefixer: {},
    },
}
